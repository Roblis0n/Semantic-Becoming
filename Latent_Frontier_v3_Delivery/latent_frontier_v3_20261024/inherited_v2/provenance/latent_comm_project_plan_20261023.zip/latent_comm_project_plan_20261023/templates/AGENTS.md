# Repository execution rules

This repository is an experimental latent-communication library, not an autonomous agent platform.

Read the project charter, contracts, relevant ADR, and assigned work package before editing. Respect existing modifications. Work in the assigned paths only.

Frozen backbones must remain frozen. Keep receiver input gradients during bridge training. Do not detach or serialize the trainable message path. Never expose targets to inference. Keep sender and receiver private views separate.

Do not change system settings, drivers, unrelated model deployments, or user data. No unapproved downloads, paid compute, remote push, public releases, or network services. Respect explicit step, memory, and disk limits.

Do not fake benchmark numbers, logs, model compatibility, or test passes. Distinguish toy, random-model, pretrained-model, semantic, and performance evidence. Report skipped tests.

Every change needs positive and negative tests appropriate to the mechanism. API changes require a decision record and updated schema, fixtures, and documentation. Prefer a complete vertical slice over empty abstractions.

Handoff: implemented changes, modified files, contract changes, actual commands and exit codes, pass/fail/skip, evidence paths, unverified claims, remaining risks, next dependency.
