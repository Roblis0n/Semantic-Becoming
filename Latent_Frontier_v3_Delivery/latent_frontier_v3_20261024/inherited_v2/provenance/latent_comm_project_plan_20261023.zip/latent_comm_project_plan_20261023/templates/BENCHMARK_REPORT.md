# 实验报告

实验 ID / code commit / dirty flag / 日期：
本次主假设及预先确定的指标：
状态：planned / completed / partial / failed

## 模型与环境

模型 revisions、tokenizer/templates、backend versions、硬件、dtype、attention、上下文上限、真实通道：

## 数据与权限

生成器/数据版本、组级划分、必要信息对照、输入权限、反事实构造、数据许可：

## 训练与选择

桥架构、参数量、优化器、有效 token 归一、steps、seeds、训练/校准成本、checkpoint 选择规则：

## 结果表

| 条件 | 总样本 | 成功/失败 | 全体准确率 | cf_pair_success | 内容效应 | bytes | latency | memory |
|---|---|---|---|---|---|---|---|---|
| 【真实条件】 | | | | | | | | |

未测量写 NA，不填 0。不填演示分数。

## 内容审计、统计与成本

donor 规则、group bootstrap、各 seed、质量容忍、冷/热/缓存与线上边界、失败分母：

## 结论与限制

分开回答：工程能运行吗？实例信息被使用吗？相对文本是否值得？换条件有效吗？

## 复现

配置、checkpoint hash、input manifest、predictions、audit assignments、成本文件与重算命令：
