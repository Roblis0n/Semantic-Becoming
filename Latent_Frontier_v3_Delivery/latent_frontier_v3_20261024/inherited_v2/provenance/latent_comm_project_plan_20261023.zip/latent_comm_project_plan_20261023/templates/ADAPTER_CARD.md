# Adapter card

状态：【experimental / validated-in-scope】

发送模型 ID/revision/config/tokenizer/template/state spec：
接收模型 ID/revision/config/tokenizer/template/injection spec：
encoder/projector 架构、权重 hash、训练参数量：
消息槽数/潜维度/dtype/semantic profile：
训练数据来源与 split policy、许可：
训练/校准预算与 seed：
检查点选择规则：
已测任务、内容效应、反事实表现与区间：
强文本/结构化基线：
成本测量条件与实际结果：
未测量字段：
适用范围、失败案例、不支持项：
复现配置/环境/逐例结果路径：
隐私与使用限制：

本卡不允许把未知字段补成“通用兼容”。更新任何 revision、模板或精度后重审能力证据。
