# Latent Comm Lab

An experimental toolkit for training, testing, and auditing communication interfaces between frozen open-weight language models.

**Status:** [fill from actual evidence; never infer semantic support from tensor compatibility].

## What it does

Provides a local differentiable hidden-state → latent-message → soft-prefix pipeline, replaceable bridges, synthetic private-evidence tasks, strong text baselines, content-dependence audits, and explicit cost accounting.

## What it does not claim

No claim of universal model interoperability, lossless thought transfer, privacy from unreadable vectors, or general superiority to text. A software release is not proof of a research hypothesis.

## Verification matrix

| Feature | Implemented | Verified configuration | Evidence |
|---|---|---|---|
| CPU contracts | [status] | [environment] | [path] |
| Pretrained-model gradient path | [status] | [revision/config] | [path] |
| Content-dependent communication | [status] | [task/checkpoint] | [path] |
| Heterogeneous pair | [status] | [directed pair] | [path] |

## Quickstart

[Insert only commands executed against this release. Clearly label no-download CPU tests separately from real-model experiments.]

## Results

[Insert a reproducible report or state that results are not yet available. Negative results are valid; fabricated example scores are not.]

## Extending / Limitations / Related work / Contributing / License / Citation

[Fill with actual project decisions, attribution, authorship, and release metadata.]
