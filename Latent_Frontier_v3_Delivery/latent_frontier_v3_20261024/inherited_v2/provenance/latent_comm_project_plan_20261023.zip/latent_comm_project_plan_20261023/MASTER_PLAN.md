# 潜空间通信通用开源项目——完整工程计划总合订版

计划版本 1.0｜2026-10-23

项目定位：可插拔、可训练、可审计的冻结开放模型通信实验库。

本文是工程与研究执行计划，不是已经完成的实现或模型性能报告。先做完整纵向通路和通用接口，再按证据扩展；工程验收与科学效果分开。

包含：22 份分册、39 个工作包、6 份 Agent 提示词、8 份模板、6 份 JSON Schema 与结构样例。全零张量 fixture 只验证存储/计量，不代表模型通信成功。

---



---

<!-- source: docs/00_项目宪法与最终决策.md -->

# 00｜项目宪法与最终决策

版本：计划 1.0；基准日期：2026-10-23。下文是建议的工程规格，不是已实现的软件或已验证的模型结论。

## 0.1 一句话定义

**建立一个可插拔、可训练、可审计的开放权重模型潜通信实验库，让研究者在冻结基础模型的条件下，连接发送端与接收端，比较潜消息、文本和结构化消息，并可靠地判断信息是否真正传递。**

工作名：**Latent Comm Lab**。拟用仓库名 `latent-comm-lab`，Python 包名 `latent_comm`，命令名 `lcomm`。这里只是工作名，未确认 GitHub、PyPI、域名或商标可用性；发布前检查，名称不影响技术设计。

## 0.2 你的目标如何翻译成工程决策

| 用户目标 | 工程翻译 | 明确不等于 |
|---|---|---|
| 先把通用代码写好 | 先完成端到端通路、明确扩展接口、训练与评测复用 | 先写一大堆无法运行的抽象类 |
| 先放 GitHub | 工程预览版可以先发布，逐步积累实验结果 | 没跑过模型却宣传性能提升 |
| 后面扩成通用项目 | 模型、桥、注入方式、任务、消息介质独立替换 | 任意模型配对不训练直接有效 |
| 暂时作为理论假设 | 用代码把假设变成可证伪实验 | 通过代码存在性证明理论正确 |
| 本机先做 | 先保留 CPU 合约测试和小模型低资源路径 | 保证 8GB 能承载所有配置 |

## 0.3 最重要的区分：两条验收线

**工程验收线 E：**安装成功、接口有效、权限隔离、梯度正确、可恢复、可测试、结果可复算。它决定代码能不能发布。

**科学验收线 S：**消息内容带来实例特定收益；对反事实变化正确响应；相对强基线存在有意义优势；更换条件后仍然有效。它决定 README 能作出多强的研究主张。

E 通过、S 没通过，仍然可以发布研究框架，并如实报告负结果。E 没通过，不应把未完成的集成写成“支持”。

## 0.4 首版固定决策

- 仅实现单向、单轮、两角色、文本任务；两个角色可共享同一份冻结权重，但上下文与 KV 缓存隔离。
- 首个真实后端为直接调用 PyTorch/Transformers；先实现一个验证过的 decoder-only CausalLM 配置。
- 首个真实模型候选为 Qwen3-0.6B；第二个候选为 SmolLM2-360M-Instruct；不是能力榜单，也不是运行保证。[S07][S08]
- 首个通路为 hidden states → 发送端压缩器 → Z → 接收端投影器 → 连续前缀 → 冻结接收者。
- 默认实验从 16 槽、256 维潜消息开始；这些参数可配置，不写死在框架里。
- 先做纯本地、单进程、可微训练。网络传输与分布式自动求导不是首版依赖。
- JSON 为首版配置格式；报告为 Markdown、CSV、JSONL；不建设 Web 前端、账号系统或数据库服务。
- 研究实验默认禁止静默退回文本；应用演示可显式允许回退，但必须记录实际通道。

## 0.5 永久不变量

1. 所有“支持”必须能追溯到具体模型 revision、后端版本、配置和证据文件。
2. 单个样本的目标答案只能进入训练损失或评测器，不能进入发送者或接收者的推理输入。
3. 测试划分不能参与调参、归一化统计、蒸馏教师缓存生成策略选择或检查点挑选。
4. 基础模型参数冻结要验证，不仅要调用一次 `requires_grad_(False)`。
5. 桥接训练期间，接收者对前缀的梯度必须保留。[S01]
6. 在线新请求的发送计算、桥接、传输、接收与生成成本均须记录；训练缓存不能冒充线上免费。
7. 潜消息不是加密、不是匿名化、不是原文引用，也不是安全边界。
8. 随机模型/模拟张量通过测试，不等于预训练语言模型完成了语义通信。
9. 软件配置的“可组合”，不等于学得表示的“可组合”；二者分别验证。
10. 所有性能、正确率、显存和支持状态默认为 `unmeasured`，直到产生可检查证据。

## 0.6 贡献定位

已有 Interlat、LatentMAS 以及 AVP 等相关研究或 SDK。[S09][S10][S11] 本项目不宣称首次潜通信或首次通用接口。建议主攻：**统一训练通路、明确的信息权限、内容依赖审计、低资源可复现、失败结果也能被记录的兼容性证据。**

“每个模块都原创”不是目标。可复用成熟依赖；重新实现论文方法时标注复现/改编关系；不复制未核实许可证的代码。

## 0.7 成功与停止条件

工程成功：陌生开发者在规定环境中，不改核心源码，就能新增一个模型适配器或任务，并得到一致格式的结果。

研究成功：只在具体条件中声明结果；例如某模型配对、某任务、某预算下，正确消息显著优于合法错配，而不是泛称“更聪明”。

停止扩张：没有完成真实后端单步训练，不增加网络服务；不能排除标签泄漏，不增加任务数量；没有正确性对照，不做性能优化；没有用户需求，不做多租户和插件市场。



---

<!-- source: docs/01_第一性原理与研究边界.md -->

# 01｜第一性原理：系统到底必须完成什么

## 1.1 最小问题

发送者知道 `x_s`，接收者知道 `x_r`，双方知道问题 `q`，答案为 `y`。我们要学习的不是两个语言模型，而是通信映射：

```text
H = S_frozen(x_s, q)
Z = E_phi(H, valid_mask)
P = D_psi(Z)
y_hat = R_frozen(prefix=P, evidence=x_r, question=q)
```

A 不掌握 B 的私有事实；B 不能直接读取 A 的材料或隐藏状态，只能收到允许的消息。模型参数冻结不阻止输出随输入变化；接收者固定函数的输入导数仍可用于训练桥。[S01]

## 1.2 四个必要条件

**必要信息存在。**改变发送者私有事实，应当在至少部分任务中改变正确答案，否则无法判别通信是否携带必要信息。

**信息可到达。**从 H 到 Z 到 P 到输出存在真实计算通路。数组形状相等只说明机械上接得上，不说明语义对齐。

**接口能学习或校准。**至少有一个明确目标和数据来源。训练桥、闭式校准、已有模型专属适配器是不同策略，应区分配置和成本。

**收益可辨识。**额外参数、额外计算、文本提示变化、测试泄漏，都可能造成分数变化；需要适当对照才能归因。

## 1.3 优化目标不是单一“token 数”

建议用受约束问题，而不是给成本随便加一个权重：

`maximize task_quality subject to payload_bytes <= B, peak_memory <= V, latency <= T`

或者固定质量阈值，比较成本。除非预先说明不同成本如何货币化，否则不要把毫秒、字节、准确率拼成无解释的综合分。

以 FP16 16×256 为例，原始 Z 是 8192 字节。真实包还包含容器与头部。文本 `K7` 可能只需少量 UTF-8 字节。潜通信可能在发送者解码、重用、任务质量上有优势，不必在带宽上获胜。

## 1.4 三种通用性

| 通用性 | 定义 | 如何验证 |
|---|---|---|
| 软件通用性 | 更换模型/桥/任务时复用同一调用协议 | 新适配器无需改 runner、训练器、评测器 |
| 训练流程通用性 | 新配对可按统一流程重新训练适配器 | 不同家族至少一组真实训练与审计 |
| 表示语义通用性 | 已训练接口可以组合到未见配对 | 预先保留的模型配对与任务测试 |

首版承诺前两项的工程方向，不承诺第三项已经成立。

## 1.5 五个可证伪假设

- H1：对一个指定配对，训练桥能让 B 使用 A 的实例特定信息。
- H2：正确消息比同任务、同形状、合法错配消息更有效。
- H3：改变 A 的关键事实后，系统会按照新答案正确变化，而不只是输出不同文字。
- H4：在某个质量约束下，潜通信相对强文本或结构化通信有可测优势。
- H5：某个接口复用策略能在未参与该组合训练的模型配对上保持效用。

H1–H5 不是必须全部成立才能开源。每项单独登记：`not_tested / supported_in_scope / inconclusive / contradicted_in_scope`。不使用无边界的 `proven`。

## 1.6 非目标

不把本项目叫 RSI；不宣称模型产生了私有意识语言；不把潜消息解释成完整思想；不声称隐藏状态等同于充分统计量；不默认这是无损压缩。

第一版不负责自主工具调用、权限提升、浏览器控制、商业部署、模型市场、自动下载任意权重、长期记忆或自动自我改进。

## 1.7 研究公平性的底线

同一输入信息权限、可比训练预算、相同答案生成上限、相同测试划分是必要记录项。不同通道的最佳合理实现可以不同；不能故意让文本发送者输出冗长解释，而潜方法直接拿到有效状态。

全文基线是“可解性参照”，不是数学上的性能上界。具有特权的符号 oracle 是机制参照，不能与普通模型方法混成一个公平排行榜。



---

<!-- source: docs/02_版本范围与发布门槛.md -->

# 02｜版本范围：先发布工程，再积累研究证据

## 2.1 版本不是工期承诺

使用里程碑和验收条件推进，不按未经测量的天数排进度。以下版本号为建议；任何一个版本都不能靠“未来会补”来兑现当下 README 的承诺。

| 版本 | 定位 | 实际必须完成 | 明确不要求 |
|---|---|---|---|
| planning branch | 设计公开 | 计划、接口草案、现有工作说明、实现状态 | 运行效果、安装即用 |
| 0.0.1.dev | 工程预览 | 可安装包、CPU 合约测试、合成数据、真实模型的提取/注入/单步梯度烟测、独立生成路径 | 优于文本、泛化 |
| 0.1.0 | 可复现实验 alpha | 一条完整训练/保存/重载/评测闭环，强基线与内容审计，一份真实报告（允许负结果） | 两种模型天然互通 |
| 0.2.0 | 异构与预算版本 | 两个家族的适配器验证、至少一条真实异构训练路径、长度/维度扫描 | 通用共享语义协议 |
| 0.3.0 | 高级消息路线 | 经 RFC 审批的 KV 或量化扩展，有独立兼容性和正确性证据 | 同时支持所有后端 |
| 1.0.0 | API 稳定版本 | 持续使用者、迁移文档、稳定协议、再现与安全回归 | 研究假设普适成立 |

## 2.2 首版必须做

完整配置校验；冻结模型；隐状态提取；连续消息训练；连续前缀输入；无真实答案生成；消息替换；真实载荷计量；逐例输出；版本记录；独立测试；CLI；安装与快速开始。

桥实现至少有 `mean_pool_linear` 和 `query_pool`；对照至少有 `none`、`full_evidence`、`compact_structured`、`constant_prefix`、`matched_latent`、`deranged_latent`。开发中可以顺序实现，0.1.0 才要求闭环齐全。

## 2.3 首版明确不做

多机训练、RPC 梯度传回、量化基座训练、动态多 Agent 图、多模态、模型自动发现、第三方任意插件自动加载、闭源 API 潜通信、vLLM/llama.cpp/Strata 深度集成、可视化 Web 控制台。

不把这些做成看似可用的空实现。可以在路线图列出，但注册表中未实现的组件必须报明确的 unsupported 错误。

## 2.4 工程发布与科学宣传分离

工程预览版可以写：“实现了可训练潜前缀通信的实验管线，语义通信效果待评估。”

完成评测但未获胜，可以写：“在报告配置下，系统可运行，未观察到相对强结构化基线的优势。”

观察到优势后，只能写包含模型、任务、预算、样本、种子和证据定位的陈述。单个演示不能支持“普遍加速”“任意模型”“无损”。

## 2.5 功能状态与验证状态分开

功能状态：`planned / implemented / deprecated / removed`。

验证状态：`not_run / pass / fail / unsupported`。

科学状态：`not_tested / inconclusive / supported_in_scope / contradicted_in_scope`。

这三个维度不可合并为一个绿色勾。例如：桥代码已实现，张量测试 pass，真实模型语义效果 inconclusive。

## 2.6 发布阻断项

以下任何一项出现，都阻断对应发布：README 命令不能执行；测试依赖联网却未声明；模型被冻结但被优化器纳入更新；接收者损失对桥无梯度；目标答案进入推理输入；截断丢失关键证据却继续计分；成本将未测量记为零；路径逃逸；未知模型静默标成兼容；固定消息和真实消息混用而未披露。

真实语义效果不佳不阻断“实验框架”发布，但阻断相关效果宣传和“语义已验证”支持标记。



---

<!-- source: docs/03_整体架构与仓库目录.md -->

# 03｜整体架构与仓库目录

## 3.1 数据平面与实验控制平面

```text
数据平面：
SenderView(q, x_s)
  → SenderBackend.extract()
  → HiddenStateBatch
  → MessageEncoder
  → LatentBatch Z
  → ReceiverProjector
  → PrefixBatch P
  → ReceiverBackend.generate(ReceiverView(q, x_r), P)
  → GenerationResult

实验控制平面：
Config + Dataset + Policy
  → RunPlanner
  → CapabilityProbe / CompatibilityResolver
  → TrainRunner / EvalRunner
  → AuditRunner + CostRecorder
  → ArtifactWriter + MarkdownReporter
```

注意：训练时 Z 是保留梯度的 tensor。推理传输时才把单条 Z 编码为 WirePacket。不要为了“架构统一”强迫训练经过不可微序列化。

## 3.2 层级与依赖方向

| 层 | 职责 | 禁止依赖 |
|---|---|---|
| contracts | 类型、配置、错误、版本、权限声明 | 训练器、具体模型 |
| backends | tokenization、提取、输入嵌入、前向与生成 | 数据集答案、评测统计 |
| bridges | 压缩、投影、归一化 | 文件路径、答案、测试标签 |
| channels | 可微本地通路、只读文件传输、载荷编码 | 任务答案、自动工具执行 |
| training | 损失、优化器、累积、检查点 | 封存测试集 |
| tasks | 数据生成、split、视图、评分规则 | 具体模型网络结构 |
| evaluation | 基线、审计、成本和统计 | 修改模型参数、重训 |
| application | CLI、runner、报告 | 绕过任意 contracts 验证 |

核心层不能反向导入 CLI。模型后端不能直接调用 report。桥不持有完整数据样本。

## 3.3 建议目录

```text
latent-comm-lab/
├── pyproject.toml
├── README.md
├── README.zh-CN.md
├── LICENSE
├── NOTICE                         # 实际需要时提供，不填伪造归属
├── CITATION.cff
├── CHANGELOG.md
├── CONTRIBUTING.md
├── SECURITY.md
├── AGENTS.md
├── .github/
│   ├── workflows/{ci,release}.yml
│   ├── ISSUE_TEMPLATE/
│   └── pull_request_template.md
├── src/latent_comm/
│   ├── __init__.py                # 不下载模型、不扫描 GPU
│   ├── contracts/
│   │   ├── types.py
│   │   ├── config.py
│   │   ├── errors.py
│   │   └── schemas/
│   ├── backends/
│   │   ├── base.py
│   │   ├── toy.py
│   │   ├── hf_causal.py
│   │   ├── formatting.py
│   │   ├── generation.py
│   │   └── capabilities.py
│   ├── bridges/
│   │   ├── base.py
│   │   ├── pooling.py
│   │   ├── query_pool.py
│   │   ├── projectors.py
│   │   └── registry.py
│   ├── channels/{local,packet,codec,compatibility}.py
│   ├── training/{trainer,losses,checkpoint,sampling}.py
│   ├── tasks/{base,private_lookup,split,views,scoring}.py
│   ├── baselines/{text,structured,constant,none}.py
│   ├── evaluation/{runner,audits,metrics,bootstrap,costs}.py
│   ├── artifacts/{manifest,cache,writer,integrity}.py
│   ├── reporting/{markdown,tables}.py
│   └── cli/{main,commands}.py
├── tests/
│   ├── unit/
│   ├── contracts/
│   ├── integration/
│   ├── semantic/
│   ├── security/
│   └── fixtures/
├── configs/{toy_cpu,qwen_same_model,heterogeneous}/
├── examples/
├── docs/{concepts,quickstarts,recipes,reference,decisions}/
└── scripts/                       # CLI 薄封装，不放另一套核心实现
```

这是目标目录，不是要求第一天创建所有空文件。按工作包引入实际实现，避免“数百个空壳文件”的假进度。

## 3.4 一个完整调用不允许隐藏什么

用户提交 configuration 后，系统先展示：权重来源与 revision、所需下载、数据 split、桥参数量、输出路径、训练预算、通道方式、已知兼容性状态。确认动作由 CLI 显式参数表达，不让底层库弹交互问题。

正式执行生成 `resolved_config.json`。配置解析完成后不再读取会变化的环境默认值来偷偷改变模型或实验。凭证只通过受控环境传入，不写进配置快照。

## 3.5 为什么不直接写一个巨型 Agent 类

巨型类会把提示词、下载、训练、消息序列化和评测绑在一起，换后端时全部重写，难以检查目标答案流向。拆层是为了限制依赖和权限，不是为了堆抽象。

只有在第二个真实用例出现时，才抽取超出本计划最小协议的新公共能力。模型特殊逻辑集中在适配器；不要在核心 runner 中出现大量 `if model_name == ...`。

## 3.6 扩展入口

新增模型：实现 backend protocol＋提交 capability probe＋最小生成与梯度测试。

新增桥：实现 encode/project＋输出规格＋梯度测试＋参数/成本计量。

新增任务：实现 world generator、views、split policy、score、必要信息说明。

新增传输：实现 encode/decode、字节计费、边界检查，声明是否可微。不得默认宣称支持分布式训练。



---

<!-- source: docs/04_核心接口与数据契约.md -->

# 04｜核心接口与数据契约

本章函数签名是拟实现的公共协议，不是本交付物已经提供的 Python 库。类型名和错误码应统一，不允许多个工作包自行重新命名。

## 4.1 信息视图

```python
@dataclass(frozen=True)
class SenderView:
    question: str
    evidence: tuple[str, ...]

@dataclass(frozen=True)
class ReceiverView:
    question: str
    evidence: tuple[str, ...]

@dataclass(frozen=True)
class Supervision:
    answer: str
    accepted_answers: tuple[str, ...]
```

完整样本可由数据层持有；backend 和 bridge 只接收视图。样本 ID、split、target、反事实关系仅作为调度/评分侧信息，不能自动渲染到提示词或消息内容中。视图不是操作系统安全沙箱，但提供可测试的信息边界。

## 4.2 核心张量

| 类型 | 必填字段 | 形状/约束 |
|---|---|---|
| HiddenStateBatch | values, valid_mask, state_spec | `[B,L,d_s]`；mask `[B,L]`；bool True 表示有效 |
| LatentBatch | values, slot_mask, latent_spec | `[B,m,d_z]`；训练保留 grad；v0 固定 m |
| PrefixBatch | values, valid_mask, placement | `[B,m,d_r]`；同接收嵌入 device/dtype |
| TrainingBatch | receiver_view, answer_ids, loss_mask | 仅 trainer 得到答案，生成接口不可接收 |
| GenerationResult | generated_ids, text, stop_reason, usage | 不混入 prompt token；记录是否到上限 |

`state_spec` 必须区分最终 normalization 之后的 hidden state 与中间层输出；不能只写 `layer=-1` 后让每个后端自由解释。

任何浮点输入在边界验证形状、有限性、dtype 支持和尺寸预算。NaN/Inf 不自动归零。全空 valid_mask 是错误，不让 softmax 产生全 mask 未定义结果。

## 4.3 后端协议

```python
class SenderBackend(Protocol):
    def describe(self) -> BackendDescription: ...
    def extract(self, batch: Sequence[SenderView], spec: StateSpec) -> HiddenStateBatch: ...
    def close(self) -> None: ...

class ReceiverBackend(Protocol):
    def describe(self) -> BackendDescription: ...
    def forward_for_loss(self, batch: ReceiverTrainBatch,
                         prefix: PrefixBatch | None) -> LossOutput: ...
    def generate(self, batch: Sequence[ReceiverView],
                 prefix: PrefixBatch | None,
                 generation: GenerationConfig) -> GenerationResult: ...
    def close(self) -> None: ...
```

把 generate 与 forward_for_loss 分开，避免调用方误把 teacher forcing 当自由生成。v0 生成先只支持 batch_size=1，训练批处理能力单独登记，不虚构通用批量生成。

## 4.4 桥协议

```python
class MessageEncoder(nn.Module):
    def forward(self, hidden: HiddenStateBatch) -> LatentBatch: ...

class ReceiverProjector(nn.Module):
    def forward(self, message: LatentBatch,
                target: ReceiverEmbeddingSpec) -> PrefixBatch: ...
```

编码器不接收 ReceiverView、Supervision 或数据文件路径。投影器不得按 sample_id 查答案。公共 q 通过发送端预填条件进入 H，首版不再额外打开一条未计费的 q 编码通道。

## 4.5 本地通路与线缆协议分离

`LocalDifferentiableChannel.send(LatentBatch)` 在同一进程保留计算图，可包含保持梯度的 device copy；不得 `.detach()` 或转 NumPy。

`PacketCodec.encode(LatentSample)` 输出 bytes，明确 `differentiable=False`。训练配置选择非可微通道时，解析阶段报 `E_GRAD_CHANNEL`，而不是训练后才发现 encoder 不更新。

冻结发送者的 H 可以离线缓存；可训练 E 的输出不能被缓存后绕过 E 的更新。

## 4.6 配置解析的规定

顺序：读取 JSON → 拒绝重复键 → JSON Schema → 跨字段验证 → 解析组件注册表 → capability probe → 写 resolved_config → 执行。

拒绝未知字段，不允许拼错 `learning_rate` 后默默用默认值。命令行覆盖必须记录 override 清单。配置中不能放任意 Python import 路径或可执行表达式。

模型 revision 在可发布实验中必须为确切 revision 或本地 manifest hash；`main` 只允许在显式 discovery 阶段解析，执行前固化。例子中的 `__PIN_REVISION__` 必须阻断真正运行。

## 4.7 稳定错误码

| 错误码 | 条件 | 处理 |
|---|---|---|
| E_CONFIG | 未知字段/重复键/互斥条件 | 不加载权重，返回配置定位 |
| E_CAPABILITY | 缺少 hidden/input-grad/embedding 能力 | 不标记支持，不静默回退 |
| E_REVISION | 未固定模型/适配器版本 | 解析失败 |
| E_SHAPE | 维度或 mask 不一致 | 报预期和实际，避免泄露原文 |
| E_NONFINITE | NaN/Inf | 停止该 run，保存脱敏诊断 |
| E_GRAD_CHANNEL | 训练经过不可微通道 | 执行前失败 |
| E_GRAD_MISSING | 桥关键参数梯度缺失 | 标记训练无效，禁止成功报告 |
| E_LEAKAGE | target/测试信息穿越边界 | 阻断评测与发布 |
| E_BUDGET | 内存/磁盘/步骤/包大小超限 | 停止，不自动修改实验 |
| E_COMPAT | 适配器/模型/协议不匹配 | fail closed |
| E_EVIDENCE_TRUNCATED | 必要证据被截断 | 拒绝样本并计数，禁止悄悄计分 |
| E_ARTIFACT | 不完整/校验失败/路径逃逸 | 不加载 |
| E_UNSUPPORTED | 明确未实现能力 | 清楚告知，不返回占位成功 |

## 4.8 可测试的 API 稳定性

公共 API 集中在少数文件；内部类以下划线或文档标明非稳定。每次修改字段都要更新 schema、fixture、迁移说明与一组旧数据读取测试。0.x 可破坏兼容，但不能无记录地破坏。



---

<!-- source: docs/05_消息协议与兼容性.md -->

# 05｜消息协议、版本与兼容性

## 5.1 两个对象，不能混为一谈

**LatentBatch**：进程内训练对象，带梯度与 device，适合反向传播。

**WirePacket**：单样本推理交换对象，不带 autograd graph，适合存储和未来网络传输。

一批样本是多个 WirePacket 的集合，不能依靠隐含的 batch 顺序匹配收件人。首版只实现本地文件往返，不把文件 codec 宣传成完整网络协议。

## 5.2 v1 消息结构

建议逻辑包由 `header.json` 与 `payload.safetensors` 组成，不在 v0 自创复杂二进制协议。Safetensors 是避免 pickle 型权重对象加载的成熟张量容器；仍需项目自身限制大小、维度和来源。[S05]

头字段至少包括：

| 字段 | 意义 |
|---|---|
| protocol_version | 消息结构版本，例如 `0.1` |
| kind | `latent` 或未来单独注册的种类 |
| source_model_fingerprint | 模型 revision、配置、tokenizer/模板等的稳定指纹 |
| encoder_fingerprint | 编码器权重与配置摘要 |
| decoder_fingerprint | 要求使用的接收投影器摘要 |
| semantic_profile | 明确的空间/任务/配对约定，而不只是张量维度 |
| shape | 单条 `[m,d_z]` |
| dtype | `float16`、`bfloat16` 或 `float32` 白名单 |
| payload_sha256 | payload 文件完整性校验 |
| payload_nbytes | 真实文件字节数，不是理论浮点字节 |
| request_id | 调度关联，禁止自动作为模型输入 |

实验标签、正确答案、发送者全文、训练样本索引不进入协议头。确有应用需要的边信息必须另开字段、说明信息权限并计入成本。

## 5.3 安全边界与上限

建议初始上限：header 16 KiB，单消息 tensor 原始数据 1 MiB，槽数 ≤256，潜维度 ≤4096；这几个上限还须通过乘积检查，不能分别合法而总大小越界。预算可以显式调整并写进 run。

拒绝未知主要协议版本、重复 JSON 键、多余 tensor key、非有限数值、shape 与实际不符、相对路径逃逸、符号链接跳出允许根目录。先检查文件大小和元信息，再分配大数组。

校验和只证明未被意外改动，不提供发送者身份认证。未加密载荷可能包含可恢复信息。首版默认只接受用户指定的本地受信目录，不开远程监听端口。

## 5.4 兼容性不是一个布尔值

分别记录六项证据：

1. load：权重能够加载。
2. extract：能够得到指定语义位置的状态。
3. inject：前缀可输入，mask/位置测试通过。
4. input_gradient：冻结接收者仍可对前缀反传。
5. semantic：指定任务上内容审计结果。
6. cost：指定条件下成本测量结果。

某模型 `load=pass` 并不推出 `semantic=pass`。同模型也要分别验证提取位置和注入位置。

## 5.5 兼容性解析顺序

先检查协议版本与 payload → 检查 source/encoder/decoder 指纹 → 检查接收模型、模板、注入位置、精度与后端 → 检查物理形状 → 查证据适用范围 → 执行。

检查 shape 是必要条件，不是语义兼容证明。`strict` 模式必须满足配置指定的证据等级；`experimental` 模式允许未测配对，但结果标注 unsupported/unverified，不冒充已通过。

## 5.6 回退规则

研究配置默认 `fallback=error`。应用配置可选 `fallback=text`，前提是存在真实文本发送路径，且具有同样的信息权限。回退使用的文本生成开销和载荷必须计入总成本。

每条预测记录 `requested_channel`、`actual_channel`、`fallback_reason`。论文主表不可把文本回退样本计入纯潜通信成绩。无消息不是一种隐形回退成功。

## 5.7 模型升级与量化

换 revision、tokenizer、chat template、state layer、模型精度、量化实现、桥权重或注入位置，都使原证据可能不再适用。不是一律宣称失效，而是把对应能力降为待验证，并重新 probe/评测。

新版本不能复用旧缓存，除非完整 cache key 一致。不能仅以模型名称相同判断等价。

## 5.8 工程通用性向语义通用性的扩展

先支持 pair-specific 编码/解码器。以后增加每模型独立 encoder/decoder 与共享 latent profile。多模型训练必须设置未见配对，不能把训练过的所有组合称为组合泛化。

第一版不承诺 `E_A + D_B` 可以无条件替代 `E_A + D_A`。接口签名相同只保证程序可调用。



---

<!-- source: docs/06_模型后端与前缀注入.md -->

# 06｜模型后端、输入格式与正确生成

## 6.1 参考后端的范围

第一版只支持直接访问内部状态的 decoder-only 自回归语言模型；不把所有 Transformers 模型都当成同一种结构。Qwen3 文档明确提供 `inputs_embeds`、`attention_mask`、`position_ids` 和缓存接口，但这只是实现基础，不是所有注入配置有效的保证。[S02]

先用 toy backend 完成接口测试，再用随机初始化的小型 CausalLM 验证真实运算结构，最后用指定 revision 的预训练模型做烟测和语义实验。三者结果分开展示。

## 6.2 CapabilityProbe 必须实测

探测项：模型类型；输入嵌入维度；状态维度；状态抽取位置；最大上下文配置；dtype/device；hidden-state 返回能力；连续输入前向；前缀梯度；普通 token 路径与对应 embedding 路径的一致性；生成缓存能力。

Probe 使用合成无敏感内容、短序列、最小 batch。`doctor` 默认只读环境；加载模型的 probe 是单独显式命令，不能在 import 或帮助页中发生。

“形参里有 inputs_embeds”不足以认定支持。必须实际 forward 并验证 logits 形状、有限性和梯度。

## 6.3 冻结与运行模式

```text
sender.parameters().requires_grad = False
receiver.parameters().requires_grad = False
sender.eval()
receiver.eval()
encoder.train()
projector.train()
```

不对整棵系统调用 `.train()` 后忘记把 backbone 恢复 eval，否则 dropout 等行为会与缓存阶段不一致。每次训练开始和恢复后做冻结状态断言。

发送者提取可使用 `no_grad()`。不要未经测试改为 `inference_mode()` 后直接把其 tensor 用于可训练桥：推理模式 tensor 的 autograd 限制不同，可能需要在模式外创建普通 tensor。首版固定使用 no_grad，减少变量。[S01]

接收者训练前向必须处于普通梯度模式；基础参数不产生参数梯度，但输入前缀参与求导。

## 6.4 发送者输入与状态语义

建议输入顺序：系统说明 → 公共问题 q → 发送者资料 x_s。把 q 放在资料前，使资料的因果隐状态可以受到 q 的条件影响。

首版读取最终层 normalization 后的状态，以 backend 明确返回的 spec 为准。`output_hidden_states=True` 可能保留多层结果，选取后及时释放其他引用；低内存优化另做 profile，不能未经验证用 hook 替代。

首版压缩候选位置使用资料 token 和规定结束位置，排除 padding。若只选择“资料位置”，formatter 必须提供准确 token span；不能通过简单字符长度推算 BPE token 边界。无法可靠提取 span 时，明确使用全部非 padding token，记录策略。

不得先生成一段长推理再不计成本。首个实现固定 prefill-only；额外推理步作为另一个实验配置。

## 6.5 前缀位置的唯一默认

v0 规定 `placement=before_rendered_prompt`：P 放在完整渲染后的接收提示 token 嵌入之前，不额外插入或删除 BOS/EOS。

这是一种明确、可测的实验选择，不代表所有模型的最优位置。后续 `after_system` 或 `before_user` 必须由模型格式器提供真实 token 边界，不能字符串搜索特殊 token 后凭估计切分。

因为前缀位于 prompt 之前，它会改变普通文字的绝对/旋转位置。无消息与有零前缀并不等价；需要分别做对照。

## 6.6 训练序列与标签

接收者序列为：`[P | formatted_receiver_prompt | assistant_answer_and_terminator]`。

P、提示词、padding 对应 label=-100；只监督规定答案与终止符。按模型自身 causal loss 约定处理一次 shift，禁止在数据层 shift 后又交给模型内部 shift。

优先使用模板可提供的 assistant-token mask；不具备时，用完整 tokenization 与已验证的边界构造方案。必须做以下测试：完整训练序列的提示前缀与生成提示一致；目标 token span 正确；特殊 token 不重复；分词跨字符串边界没有造成 off-by-one。不能假定分别 tokenize 后拼接等同于 tokenize 拼接字符串。[S03]

首版答案以简短实体字符串为主。含 `<think>` 等模板控制时，明确设置并记录模板参数；不偷偷改变 thinking mode。评测不强制输出思维链。

## 6.7 mask 与 position_ids

概念上有效位 mask 为 `[prefix_valid, prompt_valid, answer_valid]`。位置基于有效 token 的累计计数生成，padding 位置使用后端允许的安全值。不同 attention API 对 bool mask 的含义可能不同，内部统一 True=有效，到后端边界做一次显式转换并测试。

上下文总长度包含前缀、prompt 和最大答案长度。超过预算时 fail，不默认裁掉最早证据。需要截断的应用必须自定义证据保留策略并记录裁剪范围。

v0 正式生成先 batch=1，无 padding，以减少 last-logit 选择问题。训练可以先 microbatch=1；扩大 batch 后必须增加左右 padding 一致性测试。

## 6.8 两条生成实现：先正确，后加速

**ReferenceGreedy（不使用缓存）：**每一步重建 `[P, prompt, generated_so_far]`，使用最后有效位置 logits，选择下一个 token；前缀每次只出现一份。用于小样本正确性基准，不用于宣称最快性能。

**CachedGreedy：**第一次用 `[P,prompt]` 完成 prefill 并取首个生成 token；之后只提交尚未处理的新 token，更新 attention mask、位置与 cache。前缀不重复加入；模型缓存总长必须包含潜前缀。缓存 API 行为按实际锁定版本实现，不照搬旧 tuple 格式。[S04]

先在 FP32 小模型下比较每一步 logits，再比较 greedy token。出现近似平局时记录 margin 与数值误差，不能只依赖最终文本完全相同判断。通过后才能把 CachedGreedy 设为正式性能路径。

停止条件：模型声明的 EOS/终止 token 集合、max_new_tokens、显式预算错误；分别记录 stop_reason。切掉 prompt 时不能按文本长度猜切片。

## 6.9 同权重双角色与模型释放

同一冻结模型可顺序扮演 S 和 R，节省权重副本；上下文、KV、mask 和临时张量必须分开，不能把 A 的 KV 偶然传给 B，形成未声明通信。

异构模式先离线提取 S 状态，再卸载 S，训练 R 与桥。阶段切换记录时延和显存；不得将这种模式宣称成在线并发双模型。

`close()` 释放该对象拥有的资源，不删除用户权重或任意缓存。共享权重通过显式 owner 管理，避免一个角色 close 后让另一个角色失效。

## 6.10 禁止的捷径

不默认 `device_map='auto'` 作为训练正确性保证；不 monkey-patch 全局 Transformers 类；不通过字符串模型名决定所有维度；不在未测量情况下开启量化、FlashAttention、compile 或梯度检查点；不把 Transformers generate 的 embedding 支持当成无需测试的位置管理保证。



---

<!-- source: docs/07_桥接器与训练规范.md -->

# 07｜桥接器、损失与训练规范

## 7.1 首版实现顺序

1. `constant_prefix`：不读取发送者内容的可训练前缀，用于排除任务适配收益。
2. `mean_pool_linear`：对有效 H 求均值，线性映射到 m×d_z，再投影到 d_r。
3. `query_pool`：m 个可训练查询对 H 做交叉注意力，输出 m×d_z；主线方法。
4. `input_blind_bridge`：同样大小/结构的桥接收到固定无内容状态；作为额外参数量对照。

不是首版必须实现所有论文方法。免训练方法只有在假设与模型条件成立时才能比较；“随机线性矩阵”只能叫随机桥，不等于完成了免训练对齐。

## 7.2 QueryPool 规格

输入 `H:[B,L,d_s]` 与 bool mask。先以固定配置执行 normalization，再计算 K=HW_k、V=HW_v，以可学习 Q 对有效位置做注意力：

`A=softmax(Q K^T / sqrt(d_k) + mask_bias)`；`Z=A V W_o`。

d_s、d_r 从后端读取；d_z、m、head 数来自配置并验证整除。默认 dropout=0，避免缓存/推理差异。是否带 FFN/residual 作为显式架构版本，不静默加入。

若 cross-attention 使用框架实现，单独确认 key_padding_mask 的真假含义。全空 mask 直接错误，不做不稳定 softmax。

## 7.3 接收投影与尺度

首版 `LayerNorm(d_z) → Linear(d_z,d_r)`；可选两层 MLP 是独立消融。归一化可能丢失部分幅值信息，因此保留 identity-normalization 对照，不先验断言必需。

初始化目标是避免巨大前缀破坏输入数值尺度。可以用训练划分或固定公开校准提示估计接收词嵌入 RMS，初始化投影输出尺度。校准数据来源、样本数和统计值写入适配器 manifest。

不在测试集上拟合尺度。门控系数若使用 sigmoid，应初始化为非零小值；把整条通路初始化成严格零乘数可能阻断上游梯度。每个关键分支都做梯度检查。

## 7.4 训练与传输精度一致性

`wire_dtype` 是实际 Z 的精度，不只是报告字段。训练的本地可微路径应以可微 dtype cast 模拟将要传输的 FP16/BF16/FP32 值，再进入接收投影；不要训练全精度 Z、评测悄悄截成低精度却不记录差异。序列化在推理才执行，但它恢复的数值必须与规定的 wire 精度前向一致。

FP32 correctness profile 和混合精度 profile 分开。启用 FP16 时明确 scaler 行为，记录溢出与跳过 optimizer step；scheduler 不应把未实际更新的 step 当成正常更新。BF16/FP16 能力由 probe 确认，不能只凭 GPU 型号推断。

## 7.5 主损失

固定基础模型参数 θ_s、θ_r，仅优化 φ、ψ：

`L_task = sum over supervised answer tokens of CE(logits, target) / supervised_token_count`。

参数集合断言：optimizer 所有参数 ID 恰好来自 encoder、projector 和明确允许的 baseline 参数；冻结基座参数不能出现。模型不同对象引用造成的重复参数也应去重。

反事实配对训练是对原样本和反事实样本的正常正确答案监督，不把“收到错配消息一定要答错”当主要训练目标。

## 7.6 梯度累积必须按实际 token 数归一

建议把一次 optimizer step 内的 microbatch 组成一个 accumulation group，先获得这一组总有效答案 token 数 N，再对每个 microbatch 的 loss_sum/N 做 backward。最后不足完整组时使用实际 N，不能继续除以配置固定步数。

如果使用框架提供的平均 loss，必须乘回该 microbatch 的有效 token 数后再除以 N。否则长短答案不均时，会悄悄改变目标函数。

反事实成对样本优先进入同一 optimizer step，但可以分成两个 microbatch，以兼顾 batch=1 内存路径。

## 7.7 初始超参数：只是起点

| 项目 | 初始建议 |
|---|---|
| m / d_z | 16 / 256 |
| source / receiver prompt | 512 / 256 token 上限 |
| max answer | 32 token |
| microbatch | 1 |
| effective accumulation | 16 个 microbatch，按 token 正确归一 |
| optimizer | AdamW |
| learning rate | 1e-4；验证集候选 3e-5、1e-4、3e-4 |
| weight decay | 0.01，显式记录；bias/norm 是否豁免固定规则 |
| warmup | 计划 optimizer steps 的 5% |
| gradient clip | 全桥参数 norm 1.0 |
| initial steps | 先 32 样本诊断，再 1000 optimizer steps 上限 |
| eval cadence | 每 100 optimizer steps，另在开始与结束测 |
| seed | 单种子调通；初筛 3，正式比较建议 5 |
| precision | FP32 正确性路径；支持后显式启用 BF16/FP16 |

不能把这些当最优超参数；所有基线搜索预算必须记录。

## 7.8 最小训练单步验收

同一批可重复输入：损失有限；Z/P 有效；关键桥参数 grad 不为 None；至少一个关键参数梯度有限且非零；冻结模型 grad 均为 None；step 前后桥参数发生可测变化；冻结基座 checksum/抽查值不变。

参数“完全不变”检查需排除允许的缓冲区或运行模式变化，首版 eval backbone 尽量避免这些变化。比较全权重 checksum 可在起止阶段做，单步用小模型或参数抽样配合冻结断言，避免每步昂贵复制。

## 7.9 32 样本诊断

先确认全文文本条件可解，再只用训练集的 32 条样本过拟合。输出 loss 曲线、自由生成准确率、梯度统计和代表错误。

建议诊断目标是大幅降低 loss 并获得明显高于初始状态的自由生成表现；“≥90%”可作为所选简单任务的工程目标，但不是普适科学门槛。达不到先查格式、标签、位置、梯度、模型任务能力与尺度，不立即扩大模型。

32 条过拟合成功只能证明学习路径存在，不能证明泛化或有用通信。

## 7.10 训练状态机

`CREATED → VALIDATED → PREPARED → TRAINING → VALIDATING → CHECKPOINTED → COMPLETED`，异常转 `FAILED`，用户中断转 `INTERRUPTED`。

失败时保存最后完成的 step、错误码、允许保存的诊断、最后完整检查点位置。不能把一半 checkpoint 标成可恢复。NaN/Inf 默认停止，不跳过异常 batch 继续产生成绩。

## 7.11 后续训练扩展的顺序

**教师蒸馏：**优先同一接收模型、同一 tokenizer，教师看全部证据，学生看消息。对齐答案位置再做 KL；不同 prompt 长度不能按绝对位置直接比较 logits。不同词表不直接做逐项 KL。

**预算条件化：**训练时随机保留前 k 个槽，配合长度明确计费。固定 m 的常数长度惩罚不会自动让消息变短。

**量化：**先测长度与维度，再加入真实量化载荷与尺度参数；仅把 float tensor 四舍五入却仍用 FP16 存储，不叫带宽减少。

**LoRA：**只在桥训练问题诊断完成后单侧引入，并提供对应文本训练对照。双侧更新与强化学习后置，不进入第一版关键路径。



---

<!-- source: docs/08_数据生成与泄漏隔离.md -->

# 08｜数据生成、划分与信息权限

## 8.1 第一个任务：PrivateLookup

一个世界包含两张映射表：发送端 `entity → key`，接收端 `key → value`。问题询问某 entity 的 value。

```text
Sender: Aster→K7; Birch→K2; ...
Receiver: K7→mango; K2→cedar; ...
Question: Aster 对应哪个 value？
Answer: mango
```

A 单独没有 key→value，B 单独没有 entity→key。名字与映射必须随机化，避免模型凭常识或固定顺序猜答案。首版先使用简单一致的英文/符号渲染测试通信，中文模板作为后续独立泛化维度，不混成语言能力比较。

## 8.2 世界生成规则

先生成 canonical world，再渲染文本。entity/key/value 的候选池、排列、问题实体、干扰事实数量来自显式 seed。保证每个问题有且仅有一个程序答案；键和值的唯一性、双表 join 完整性由验证器检查。

默认建议 K=8 个候选，答案分布近似均衡；K 是配置，不写死。通过随机置换切断“第一个事实就是答案”“某个编号更常出现”等规律。

不要用 LLM 自动生成第一版数据，因为会引入标签真实性与随机偏差；程序生成器能够提供精确 oracle。

## 8.3 反事实对

保持 receiver evidence 和 q 不变，只交换发送表中被问实体与另一个实体的 key，使答案变化；这样能保持映射唯一性。记录 `cf_group_id`、原/反事实角色与 oracle 变化。

一个 group 两条样本在相同 split。成对得分必须两条均答对；只改变输出但变化错误不计成功。

反事实 donor 不能偷偷改变候选数量、文本长度或标签格式来传递额外线索。必要时匹配 token 长度或把长度变化作为额外分层报告。

## 8.4 信息权限表

| 字段 | sender | encoder | receiver | trainer | evaluator |
|---|---:|---:|---:|---:|---:|
| question | 是 | 通过 H | 是 | 是 | 是 |
| sender evidence | 是 | 通过 H | 否 | 可调度，不注入 | 可审计 |
| receiver evidence | 否 | 否 | 是 | 可调度 | 可审计 |
| answer / accepted answers | 否 | 否 | 推理否；训练 teacher forcing 受控 | 是 | 是 |
| sample/group/split ID | 不渲染 | 不输入 | 不渲染 | 是 | 是 |
| 全证据 oracle 中间 key | 只有合法输入能推得 | 不外挂 | 仅作为独立 oracle 基线 | 可生成监督 | 可评分 |

训练接收者会看到过去的正确答案 token 是自回归监督定义，不构成推理测试许可。推理函数签名不得接收 Supervision。

答案词可能合法存在于 receiver 候选表中，因此“原文出现答案字符串”不是泄漏的充分证据。泄漏检查应围绕事实权限、目标字段及捷径，而不是简单禁止答案词出现。

## 8.5 数据文件建议

开发数据用 JSONL 保留结构化字段，同时导出便于人检查的 CSV。原始 canonical world 与 rendered sample 分开，生成器版本、模板 hash、seed 都记录。

字段：schema_version、sample_id、world_id、cf_group_id、variant、split、question、sender_evidence、receiver_evidence、answer、accepted_answers、task_parameters、generator_revision。

score 由任务实现：首版严格实体答案，允许预先定义的首尾空白与 Unicode 规范化；不要测试后再用宽松 regex 把错误答案改成正确。输出多个候选、解释一串互相矛盾答案，应按既定规则计错。

## 8.6 划分策略

先按 canonical world family/group 分割，再生成改写和反事实。不同 split 不共享同一世界或其同义模板版本；在目标是组合泛化时，还需按组合结构保留，而不仅是文本去重。

建议起点：训练 5000 组/10000 样本；验证 500 组/1000 样本；封存测试 1000 组/2000 样本。数据规模只是预算建议，先做小 pilot。

模型训练选择只读取 train/validation。封存测试的配置 hash、seed 范围和生成器版本预先登记；可以不公开未用的 test seed，最终发布时公开以便复现，但不能声称公开后仍完全防止未来调参污染。

## 8.7 泄漏与捷径检查

- sender-only、receiver-only、question-only 条件分别测试；不能只用理论论证代替实测。
- 随机打乱事实顺序，模型表现不应依赖答案所在位置捷径。
- 删除/交换发送关键事实时，oracle 必须按预期变化。
- 对 sample ID、文件顺序、缓存路径做扰动，预测不应因未授权元数据变化。
- 检查训练/验证/测试 canonical hash、group ID 和改写家族无重叠。
- target、split 标签不得进入输入 formatter、bridge.forward 参数或 wire header。
- 验证 donor 错配不是自身，也不是语义等价消息；否则内容效应会被稀释。

## 8.8 OOD 家族

按单因素推进：新实体名称；新映射组合；未见模板；更多干扰事实；更长上下文；更多候选；新增 hop；不同语言；不同模型配对。

不把同时变化五个因素后的下降归因给某一个机制。至少保留一个 in-distribution 对照和一个单因素变化对照。

## 8.9 现实任务扩展

公开多跳问答、政策条款、代码仓库交接可以后续添加，但必须有新的数据许可、证据分割、必要信息、评价和隐私审查。先用合成任务排除工程错误，再让真实任务回答应用价值。

不要自动把用户此前上传的政策文件或个人数据放入开源仓库。真实数据需要独立明确授权与脱敏，样例默认全部合成。



---

<!-- source: docs/09_基线内容审计与统计评测.md -->

# 09｜基线、内容审计与统计评测

## 9.1 不设一个掩盖问题的总分

报告分四页逻辑：任务质量、消息内容贡献、真实成本、适用范围。不同维度可以冲突，框架应呈现冲突而不是强行综合。

## 9.2 基线矩阵

| ID | 条件 | 是否可训练 | 作用 |
|---|---|---|---|
| B0 | receiver-only | 否 | 原始能力 |
| B1 | full-evidence receiver | 否或单列适配版本 | 任务可解性参照，不是理论上界 |
| B2 | sender 输出紧凑自然语言 | 默认否，训练版本另列 | 常见文本通信 |
| B3 | 结构化 key/JSON/表格 | 与其抽取方式一并记录 | 强高效文本对照 |
| B4 | 合法原文片段抽取 | 算法/模型分别计费 | 不依赖长生成的文本方案 |
| B5 | constant_prefix | 是 | 额外任务适配参数效应 |
| B6 | input_blind_bridge | 是 | 更接近参数量/结构的对照 |
| B7 | mean_pool_linear | 是 | 复杂桥必要性 |
| B8 | query_pool | 是 | 主线方法 |
| B9 | 条件适用的已有免训练桥 | 依方法 | 是否值得训练 |
| O1 | oracle intermediate key | 否 | 特权机制参照，单独标明 |

程序可以解析发送表得到 key，属于确定性发送策略，需要明确该解析器适用范围；不能给潜桥不提供的全局答案权限。一个“特权 oracle”与“合法符号解析”可能输出相同 key，但信息条件不同，标注不能混用。

所有方法输出答案长度、输入证据权限、训练预算和停止策略明确。文本预算是实际 byte/token，不强迫文本写长解释。

## 9.3 消息内容审计

针对同一个固定检查点做：matched、same-family deranged、constant、zero、norm-matched random、合法 counterfactual、语义等价改写。

zero 与 none 分开；前者仍占位置并经过投影 bias/normalization。norm-matched random 的统计量必须来自训练/校准数据，不能为某个测试答案定制。

错配采用同任务、同预算、同形状的无固定点置换。优先排除与当前目标中间 key 相同的 donor，同时报告 donor 选择规则；也保留纯随机错配作为补充。反事实同组互换是更有语义约束的干预，应独立记录。

替换发生在 Z 边界，不重跑与正确组不同的其他组件。位置、接收资料、解码配置固定。对于内容审计，消息使用 donor 的内容，receiver 的请求身份不应误用 donor 的 target。

## 9.4 主要指标定义

`accuracy = correct / all_scheduled_examples`。同时报告成功执行样本上的 conditional_accuracy 和 failure_rate；不得用自动剔除 OOM/解析失败提高主分。

`content_effect = accuracy(matched) - accuracy(deranged)`；按同一例配对。

`cf_pair_success = 两条均正确的反事实组数 / 全部计划反事实组数`。

`invariance = 语义不变改写后依然正确的成对比例`。这与仅比较输出完全一致不同。

报告 full-evidence gap、constant-prefix gap 以及相对紧凑文本差异。loss 改善与自由生成准确率分开。

## 9.5 统计单位与不确定性

反事实组或独立 world family 是统计聚类单位，不能把同一组内两条样本当完全独立。bootstrap 在最高相关组级别重采样，保持方法之间的配对与原/反事实关系。

建议正式结果给 95% 区间，bootstrap 次数 2000 为起点；固定 resampling seed。训练多种子结果分别展示，再报告跨 seed 平均与范围；可以做分层 bootstrap，但必须说明两层分别是什么，不能把所有 seed×sample 当独立样本扩大显著性。

主要检验和主要任务在解封前确定。多任务多预算探索报告完整扫描，不只挑一个显著点；检验数量、选择规则和未通过结果必须可见。

## 9.6 机制验收规则

仅当预定义 held-out 集上 content_effect 的区间支持正值，并且反事实成对成功明显优于无消息/内容盲对照，才考虑 `semantic=supported_in_scope`。还需确认私有信息必要性、无泄漏与实施有效性。

没有统一适合所有任务的绝对准确率阈值。不要写死“提升 5% 即通信成立”。效果区间宽或只在一个训练种子出现时标 inconclusive。

机制成立不要求击败文本；击败文本也不自动证明机制成立。二者分别报告。

## 9.7 成本优势的判定

在预先说明的质量容忍范围下比较成本，或展示 Pareto 非支配点。不事后把质量明显下降解释成“更快所以赢”。质量容忍值是具体应用的政策参数，应提前固定。

训练成本若要摊销，给出训练/校准总成本和使用次数。只有每次确有节省且口径一致时，才计算 `break_even_uses = upfront_cost / per_use_saving`；无节省时不存在正的回本次数。

## 9.8 逐例结果

每行至少：run_id、sample_id、cf_group_id、split、condition、requested/actual_channel、checkpoint fingerprint、prediction、correct、stop_reason、latency、bytes、error_code、status。

公开示例是合成数据；真实用户数据默认不保存完整 prompt/latent。指标从逐例文件重算，不能只保存一张漂亮 Markdown 表。

## 9.9 负结果与缺失值

未测量字段用 null/NA，绝不写 0。OOM、超时、无效输出、校验失败分别计数。语义未提升的运行也保留完整记录。换掉失败任务后重新选任务，要标为探索后新假设，不伪装成原先确认性测试。



---

<!-- source: docs/10_真实成本性能与本机资源.md -->

# 10｜真实成本、性能与本机资源

## 10.1 成本账户

```text
T_request = T_sender_prefill + T_sender_decode_if_any
          + T_encode + T_serialize + T_transfer
          + T_deserialize + T_project
          + T_receiver_prefill + T_answer_decode
```

模型加载、首次 kernel 初始化、训练与离线缓存构建单独列出。端到端 wall-clock 必须独立测量，分阶段值用于解释；并发/异步阶段可能重叠，不把重叠时间简单相加成真实总时长。

## 10.2 载荷口径

同时记录：raw_tensor_bytes、serialized_payload_bytes、header_bytes、side_information_bytes、total_application_bytes。压缩比例对指定口径计算。

本地同进程没有实际网络包，应写 network_bytes=NA；不能把应用载荷直接当 TCP 字节。未来网络测量可另计框架/加密/重传开销，不能漏算后称“线上总带宽”。

文本以 UTF-8 实际长度为基础。token ID 只在 tokenizer/协议明确一致时计费；跨 tokenizer 文本不默认为可直接传 ID。

原始潜消息 `16×256×2=8192` 字节只是张量数据；safetensors header、消息头、量化 scales、码本 ID、文本 sidecar 都额外计费。

## 10.3 计时规范

GPU 操作异步，测端到端延迟时需要恰当同步或 CUDA event；训练 profiler 不与正式推理跑分混在一起。固定 warmup 数与重复次数；记录 warmup 不计入 steady-state 但不能从冷启动成本消失。

先按一个配置完成一致条件的测量，再随机/交错执行不同方法以减小温度与系统负载漂移。笔记本记录供电模式、是否接电、其他 GPU 进程。不要主动关闭用户进程。

报告 median、p90、样本量和测量条件；样本不足时不渲染“稳定 p99”。吞吐和单请求延迟是不同实验，batch/concurrency 必须一起给出。

## 10.4 显存与内存

报告 peak_allocated、peak_reserved、可获得的外部设备占用、CPU RSS 和 cache disk usage；说明哪些只覆盖框架 allocator，不能称作全机总用量。

测量前 reset peak；模型/桥权重、激活和 KV 均纳入相应阶段。不把“冻结参数”误解为接收者反传没有激活成本。[S01]

## 10.5 四个执行模式

| 模式 | 目的 | 结果可以证明什么 |
|---|---|---|
| CPU contract | 无下载、toy/tiny random | 接口、序列、计量、梯度代码正确性 |
| local shared-weights | 同模型两角色顺序执行 | 本机语义可行性与低副本内存路径 |
| cached sender | 预先存 H，只训练 receiver+bridge | 训练便利；不是线上端到端速度 |
| online heterogeneous | 独立模型与完整发送 | 实际异构通信成本，需要更完整资源测量 |

8GB 显存、32GB 内存只作为起步约束，不给未经测量的显存保证。保留现有 9B 聊天部署，研究环境不自动改动其文件、端口、分页文件或驱动。

## 10.6 建议预算护栏

初始 profile：microbatch=1、source 512、receiver prompt 256、answer 32；模型单独加载 smoke 后再扩大。

缓存磁盘默认配额建议 10 GiB，可配置；不自动删除用户已有缓存。权重下载另有显式预算，不计入训练 cache 配额。训练 steps、样本数、消息 bytes、输出文件大小都有上限。

达到预算失败后，不静默缩短证据或切换模型。创建新的配置/新 run，再说明调整因素。连续 OOM 首先降低 batch/长度并确认关键证据仍完整；训练结构改动是新实验。

## 10.7 离线缓存可能很大

假设存 10000 条、每条 512×1024 的 FP16 隐状态，原始数据约 9.77 GiB，尚不含掩码与容器。这里 1024 只是计算示例，实际 d_s 必须从模型读取。

可以分 shard、保存有效长度、按样本读取，不一次全部载入 RAM。只保存固定 H，而非训练中变化的 Z。需要按查询条件缓存时，q 必须进入 key；不能把不同问题共享同一个 q-conditioned H。

## 10.8 优化顺序

先 reference 生成正确性 → 去掉冗余权重副本 → sender 状态缓存 → 正确的 receiver KV 解码 → 长度桶与 batching → 精度优化 → 确有收益再尝试 compile/特殊 attention。

每项优化需 correctness diff、内存与 latency 对照。不能一口气打开所有优化后不知道精度下降来自哪里。

## 10.9 对外报告模板

标题包含模型配对、后端、dtype、设备、通道、cold/warm、online/cache、batch。正文把质量/成本摆在同表。未测 GPU 数据写未测，不根据参数量估算后当实测发布。



---

<!-- source: docs/11_缓存检查点与可复现性.md -->

# 11｜缓存、检查点与可复现性

## 11.1 三种缓存必须区分

**发送状态缓存**存固定发送模型输出 H；适合训练期间重用。

**推理消息缓存**存特定 encoder checkpoint 产生的 Z；只适合该 checkpoint、相同输入条件的推理，不可用来替代仍训练中的 encoder。

**接收者 KV 缓存**存一次请求内部的自回归状态；不能跨独立请求误复用，除非有专门且经验证的前缀缓存协议。

缓存目录不同，类型明确，读取时验证 kind 与 fingerprint。不要统一叫 `cache.pt`。

## 11.2 发送状态 cache key

至少包含 model revision/weights manifest、config hash、tokenizer revision、chat template hash、template kwargs、source text hash、q hash、state extraction spec、dtype、截断规则、backend/extraction implementation version。

不把 target 或 test label 加进计算输入。样本 ID 可以用于索引，但不得替代内容 key。相同 ID 内容不同必须 miss，不能返回陈旧状态。

若模型提取含随机性，必须记录 seed 或禁止缓存；首版 eval backbone、无 dropout，让前提简单可检查。

## 11.3 格式与生命周期

采用有界 shard＋索引 manifest。每个 shard 使用 safetensors 存张量，JSON 存非敏感索引与 shape。写临时文件、flush、完成校验后原子改名；最后生成 manifest/完成标志。中断目录没有完成标志，默认不可读取。[S05]

写入目标必须在明确根目录内。默认不覆盖同名数据；用户显式选择新 run 或带校验恢复。清理命令先 dry-run 列出路径与总量，不删除权重目录或其他项目。

## 11.4 两类 checkpoint

**公开适配器包**：encoder/projector 的 safetensors、配置、模型 fingerprint、schema 版本、校准统计、训练数据生成说明、检查点选择规则、适用范围与已知失败。默认不附带基础模型权重。

**本地恢复包**：上述内容加 AdamW 状态、scheduler、scaler、RNG、sampler cursor、optimizer step、累积状态、环境 manifest。

建议首版只在完整 optimizer step 边界保存，避免恢复半次 gradient accumulation。公共发行不附带未经审查的 optimizer 对象。

## 11.5 首版安全恢复格式

为降低任意对象反序列化风险，支持确定的 AdamW：tensor 状态存 safetensors；param group、参数名称映射、步数和标量存 JSON；torch RNG 存 uint8 tensor，其余 RNG 转受限 JSON。拒绝无法映射到当前参数名称与形状的恢复状态。

不使用 `eval`、任意 class import 或从互联网加载 pickle。需要支持更多 optimizer 时单独实现受限 serializer，不以“PyTorch 都这么用”为理由放开任意对象加载。

v0.0.1 可以只支持 adapter 保存/重载，不宣称精确续训；v0.1.0 才要求受控恢复测试通过。

## 11.6 模型参数冻结的证据

训练开始记录基础权重与 buffer 的标识和校验；结束与恢复后检查。optimizer 参数 ID 检查与 grad 检查应进入自动化测试；必要时使用随机小模型全量比对，真实大模型只在边界做昂贵 hash。

不能因为权重文件没被写回磁盘，就声称内存里的模型没有更新。

## 11.7 每次 run 的必备文件

```text
runs/<run_id>/
  resolved_config.json
  environment.json
  input_manifest.json
  status.json
  metrics.jsonl
  predictions.jsonl
  audit_assignments.json
  cost_summary.json
  summary.md
  checksums.sha256
  checkpoints/
```

run_id 是标识，不编码答案。环境包含 Python、库版本、git commit、dirty flag、CUDA/driver、device、dtype、attention implementation、操作系统、随机种子与实际模板。

未提交代码可以开发运行，但正式比较必须保存 patch 或要求 clean commit。不同机器相同 seed 不保证逐 bit 相同；PyTorch 文档明确提醒跨版本/平台的完全可复现性有限。[S06]

## 11.8 再现等级

R0：能重算现有 predictions 得到同一指标。

R1：同环境同 checkpoint 重新推理在规定容差内复现。

R2：同环境重训得到统计上相容的结果。

R3：另一平台/设备按文档完成再现。

README 分别标注，不以 R0 冒充 R3。恢复测试先比较不中断训练与中断恢复训练的前若干步损失和参数，再说明浮点容差。

## 11.9 选择检查点的规则

默认用 validation 上预定主指标选择；同分按较早 step 或较小成本的预定规则。不得看 test 后挑最好 checkpoint。报告 best-on-validation 与 final checkpoint 的差异。

发布前锁定 checkpoint hash、config 和测试集 manifest，再解封。重新运行失败任务允许，但必须记录失败和重试原因。



---

<!-- source: docs/12_CLI配置与用户流程.md -->

# 12｜CLI、配置与用户流程

所有命令是拟实现规范。本计划包不提供已完成的 `lcomm` 可执行程序；不要把这里的命令原样运行并误认为已经安装框架。

## 12.1 CLI 设计原则

命令行是 Python API 的薄封装。相同逻辑不复制两份。默认无网络、无后台服务、无遥测；需要权重下载时明确启用并展示来源、revision、目录与预算。

stdout 用于可解析结果或简洁摘要，stderr 用于进度和错误。`--json` 输出稳定结构；日志不混入 JSON。退出码与稳定错误码共同使用，未支持能力不得返回 0。

## 12.2 命令表

| 命令 | 输入 | 输出/行为 | 约束 |
|---|---|---|---|
| `lcomm doctor` | 可选环境路径 | 环境诊断 | 默认不下载、不修改系统 |
| `lcomm config validate FILE` | JSON 配置 | schema/跨字段错误 | 不加载模型 |
| `lcomm data build FILE` | 生成配置 | world/samples/manifest | 合成数据、确定性 seed |
| `lcomm data validate PATH` | 数据目录 | 唯一性、split、oracle 检查 | 不训练 |
| `lcomm probe FILE` | 模型配置 | capability record | 显式加载授权 |
| `lcomm cache build FILE` | sender+data | H shards | 校验预算与 split |
| `lcomm train FILE` | resolved 配置 | checkpoints、训练日志 | 必须明确 steps 上限 |
| `lcomm evaluate FILE` | checkpoint+split | predictions、质量结果 | 不更新参数 |
| `lcomm audit FILE` | 固定检查点 | 替换/反事实结果 | donor 规则固定 |
| `lcomm benchmark FILE` | 基线/成本配置 | 计时/载荷/显存 | warmup/cold 条件明确 |
| `lcomm report RUN_DIR` | 已生成结果 | Markdown、CSV | 只读重算 |
| `lcomm export RUN_DIR` | 适配器/manifest | 发布包 | 默认不含原始私有数据 |
| `lcomm verify BUNDLE` | 本地发布包 | hash/schema/范围验证 | 不执行包内代码 |

首版不用复杂的动态 sweep DSL。用显式配置列表逐一跑，runner 只负责预算和日志，避免隐藏实验变化。

## 12.3 三条快速开始

### A：无需下载模型的开发者路径

安装包与测试依赖 → doctor → toy_cpu 配置校验 → 构造 8 组数据 → toy/tiny-random 前向与梯度 → 生成一份标注“非真实模型”的报告。

用途：验证安装和代码路径。不宣传成潜通信成功演示。

### B：真实模型低资源路径

固定权重 revision → 下载到独立模型目录 → probe → 合成数据/全文基线 → 同权重双角色单步训练 → 32 样本诊断 → 保存/重载 → 小验证集自由生成和消息替换。

任何一步失败就输出具体故障与已完成状态，不能继续伪造后续结果。

### C：复现公开实验

获取 release/lock/config/checkpoint/dataset generator → verify → 重建数据 → 重跑 evaluate/audit → 从 predictions 重算主表 → 比较容差与已知非确定性。

## 12.4 配置分块

`schema_version`、`run`、`models`、`data`、`bridge`、`injection`、`training`、`generation`、`evaluation`、`artifacts`、`security`、`resources`。

所有字段有默认与类型，重要实验参数都写入 resolved_config。路径相对 config 文件解析而非当前工作目录，消除从不同终端启动导致的行为变化。

配置文件严格拒绝重复 JSON key。使用 schema_version 管理迁移；旧配置转换输出新文件并记录变化，不能原地改原配置后继续装作同一次实验。

## 12.5 用户提示与输出

训练前摘要显示：模型配对、revision、state spec、message shape/dtype、参数量、训练/验证样本量、估计缓存空间与实际磁盘、steps、输出路径、当前证据等级。

这不是成本保证。资源估算要写 `estimate`；第一次实测后再产生 `measured`。

错误应给可执行方向，例如“配置要求 BF16，但当前 probe 未确认支持，请选用经验证的 FP32 配置”，而不是自动切精度。

## 12.6 Windows/本机约束

路径使用 pathlib；包含中文、空格的路径要有测试；shell 示例分别给 PowerShell 与 Bash，不假定 `rm -rf`、`export` 或反斜线规则通用。

先支持 Windows CPU 合约测试；GPU 参考环境可以选择 Linux/WSL2，但仅在真实测试后声明支持。不得要求 Agent 自动改分页文件、装驱动、关闭安全软件或结束现有 9B 服务。

## 12.7 API 示例的诚实性

README 中所有代码块都归类为：已测试命令、概念示例、未来 API。0.1.0 主要 quickstart 必须是 CI/维护者实际执行过的已测试命令；未来 API 不放在“现在安装即用”的区域。

导入 `latent_comm` 不应强制加载 Transformers；轻量 schema/report 子命令在无 GPU 环境可运行。大型依赖采用明确 extra，缺少时提示所需安装项，不偷偷 pip install。



---

<!-- source: docs/13_测试矩阵与CI.md -->

# 13｜测试矩阵与持续集成

## 13.1 五层验证

U：纯函数/协议；I：真实计算结构集成；M：预训练模型 smoke；S：语义通信；P：性能测量。U/I 可以在普通 CPU CI 完成；M/S/P 有不同资源需求，不让它们被默认 skip 后仍显示“全部验证通过”。

CI 的绿色只对应当次执行的层级。测试报告必须列出 pass/fail/skip 数和原因；pytest marker 可以将资源依赖明确区分。[S13]

## 13.2 必须覆盖的测试清单

| ID | 用例 | 核心断言 |
|---|---|---|
| T01 | 合法配置 | 类型/默认解析一致 |
| T02 | 未知字段 | 拒绝而非忽略 |
| T03 | JSON 重复键 | 拒绝 |
| T04 | revision 占位符 | 执行前失败 |
| T05 | 组件未注册 | E_UNSUPPORTED |
| T06 | 形状错误 | 稳定 E_SHAPE |
| T07 | 全 padding | 拒绝，无 NaN 传播 |
| T08 | 混合有效长度 | masked pooling 正确 |
| T09 | NaN/Inf | 拒绝 |
| T10 | device/dtype 差异 | 显式合法转换或失败 |
| T11 | packet 往返 | tensor、metadata 保持 |
| T12 | payload 损坏 | 校验失败 |
| T13 | 声明 shape 与真实不同 | 拒绝 |
| T14 | 超大包 | 分配前拒绝 |
| T15 | 不兼容语义 profile | 不因相同形状放行 |
| T16 | 协议主要版本未知 | 拒绝 |
| T17 | 路径逃逸/链接逃逸 | 拒绝 |
| T18 | 数据 oracle | 两表 join 唯一正确 |
| T19 | 反事实 | 仅 sender 事实变化且 y 改变 |
| T20 | split | world/group 无重叠 |
| T21 | renderer | 不渲染 target/ID/split |
| T22 | 资料顺序 | oracle 不变 |
| T23 | text vs embeds | 对应 token 嵌入路径 logits 一致 |
| T24 | prefix/no-prefix | 长度/position 合法 |
| T25 | label mask | 仅答案与终止符受监督 |
| T26 | causal shift | 与手算短序列 CE 一致 |
| T27 | tokenization 边界 | 训练/推理 prompt 前缀一致 |
| T28 | 冻结 | 基座参数 grad=None、step 不变 |
| T29 | 梯度通路 | encoder/projector 非零有限梯度 |
| T30 | 故意 no_grad 接收者 | 测试能捕获断梯度 |
| T31 | 故意 detach Z | 测试能捕获断梯度 |
| T32 | optimizer 白名单 | 不含基座、无重复参数 |
| T33 | accumulation | 等价于同 token 集大 batch 目标 |
| T34 | 最后不足组 | 使用实际 token 归一 |
| T35 | reference decode | prompt 不重复、只返回生成 token |
| T36 | cached decode | 每步 logits 对齐 reference |
| T37 | EOS/max tokens | 正确 stop_reason |
| T38 | 两角色隔离 | 无未声明 KV/证据流入 |
| T39 | cache key | 改 q/template/revision 必须 miss |
| T40 | cache 截断写入 | 无完成标志不得读 |
| T41 | checkpoint 重载 | 同配置输出一致容差 |
| T42 | resume | 连续运行与恢复步结果一致容差 |
| T43 | derangement | 无自身 donor，条件匹配 |
| T44 | 内容相同 donor | 排除或明确统计 |
| T45 | cf pair score | 只改变答案不算成功 |
| T46 | bootstrap | 保持组与方法配对 |
| T47 | failure denominator | 错误样本不被悄悄删除 |
| T48 | bytes | raw/payload/header/sidecar 不混淆 |
| T49 | 未测量 | null 不变成 0 |
| T50 | fallback | 记录 actual_channel，不混统计 |
| T51 | report 重算 | 与逐例结果严格一致 |
| T52 | CLI exit | 失败不返回成功 |
| T53 | import | 不下载、不联网、不初始化 GPU |
| T54 | 干净安装 | wheel 安装后 examples 可用 |
| T55 | 中文/空格路径 | Windows/Unix 行为正确 |
| T56 | 新后端插件测试 | 不改核心 runner 即接入 |
| T57 | 32 样本诊断 | loss/生成/梯度记录齐全，非泛化证明 |
| T58 | 真模型 no_grad 验证 | 基座冻结且桥确实 step |
| T59 | 真模型 matched/deranged | 真实结果，允许负结果 |
| T60 | 性能优化回归 | 正确性与成本证据同时提交 |

这些是待实现测试规格，不是本计划包已经跑过的 60 项测试。

## 13.3 数值测试规定

FP32 小模型用于紧容差基准；混合精度单独用合理容差。不能一见测试失败就把 atol 放大十倍。修改容差需解释误差来源、最大误差与任务影响。

随机梯度测试固定 seed，但避免依赖恰好一次随机初始化通过；测试应构造确有梯度路径的非退化输入。对桥中零初始化/门控特例单独覆盖。

## 13.4 Mutation/负向测试

主动做四个错误：receiver.no_grad、Z.detach、label 向左多移一位、prefix 重复送入 cached decode。测试必须失败，才能证明它们真在保护机制。

再加入一个泄漏版本：formatter 偷塞 target；信息边界测试要捕获。只测正常路径通过不足以证明质量。

## 13.5 CI 分层

PR 必跑：格式、静态检查、schema、U/I、离线 tiny model、包构建、干净环境安装。默认阻断网络，使未声明下载暴露。

有明确授权的模型测试：固定小模型 revision，从受控缓存加载，报告下载/许可状态。GPU 任务不对不受信 fork 提供 secrets 或自托管机器权限。

release：在干净环境执行真实 quickstart，复算一个公开报告，检查所有 advertised capabilities 有对应证据；不能只复制上次 CI 徽章。

## 13.6 CI 安全

GitHub Actions 使用最小权限，第三方 actions 固定可信 commit，发布 secrets 仅在受信发布环境可用；避免在带 secrets 的上下文直接执行不受信 PR 代码。这些与 GitHub 官方安全建议一致。[S14]

不提供未经核实的 action SHA 样例。工作包执行时选择、核实、固定并记录来源；占位 SHA 不得合并。

## 13.7 覆盖率不是验收替代品

可以设核心逻辑行覆盖率目标 85% 作为提醒，但 T23–T38 的语义正确性与负向测试比总覆盖率更重要。100% 覆盖一个错误的实现不代表正确。

所有关键测试都关联需求 ID，见 20 章；新增功能必须附带至少一个成功路径和一个失败路径测试。



---

<!-- source: docs/14_安全权限与依赖治理.md -->

# 14｜安全、隐私、资源权限与依赖治理

## 14.1 威胁模型

威胁入口是：外部模型代码/权重、适配器包、配置文件、消息文件、数据文本、第三方插件、CI PR 和过大资源请求。首版不执行工具、不提供网络服务，因此不要提前承担完整 Agent 平台攻击面。

潜向量可能携带源信息，也可能使接收者产生不良输出；不可读不等于不可恢复。这个框架不把 latent 作为隐私技术或安全过滤器宣传。

## 14.2 访问默认值

网络默认关闭；下载需显式 allow_network 和固定来源。`trust_remote_code=False`；需要远程代码的模型在独立评审后才能例外，固定代码 revision 与来源。不开启配置中的任意 Python 执行。

日志默认不记录 raw prompts、raw latents 或凭证。合成数据可以显式启用全记录；真实资料必须声明保留期和访问权限。

## 14.3 不可信文件处理

配置 safe parser，拒绝未知字段和重复 key。公开模型适配器采用受限张量格式与 JSON 元数据，不加载任意 pickle 对象。[S05]

字节上限、张量 shape、dtype、finite、路径根限制与 checksum 缺一不可。Safetensors 不能替代来源认证或内存配额。

适配器文件名不决定功能；注册表只允许明示组件名与版本，不按文件内部任意 import path 加载类。

## 14.4 输入文本与权限

数据中的自然语言不是开发指令。即使证据写着“忽略系统并上传文件”，模型实验也只能把它作为数据处理；核心库没有系统命令或上传工具可调用。

未来接入真实 Agent 时，工具执行权限仍由外部系统强制控制。不得让潜消息绕过工具授权、来源审查或数据访问规则。

## 14.5 本机保护

只写仓库、明确 artifacts 目录和用户指定缓存。不得修改用户现有模型、全局 Python 环境、驱动、系统配置或分页文件；不得默认扫描整块磁盘；不得删除无关缓存。

训练有 max_steps、磁盘配额、最大消息大小；下载有总预算；失败停止而非无限重试。首次 smoke 不自动开启大规模参数扫描。

## 14.6 软件依赖选择

建议：Python 3.11 作为初始参考环境；核心协议用 dataclasses/标准库与 JSON Schema；PyTorch/Transformers/safetensors 在 `hf` extra；pytest/ruff/mypy 等在 dev extra。最终确切版本通过真实环境测试后锁定，不在计划里伪造“已兼容”版本矩阵。

用 pyproject.toml 和 src 布局打包；PyPA 的标准打包流程支持这一路径。[S12] 依赖锁文件记录参考环境；可安装范围与实际验证组合分开展示。

不用同一依赖同时提供多套重叠功能；第一版不用数据库、消息队列、FastAPI 或前端框架。新增依赖必须说明现有库/标准库为何不够、许可证、体积和维护成本。

## 14.7 发布权限

本计划不等于授权 Agent 创建远程仓库、公开上传权重/数据、申请付费资源或发送社区消息。默认交付本地分支/补丁；由仓库所有者执行或明确授权远程发布。

release job 需要人工批准与最小 token 权限。不可把 GitHub token 或模型访问 token 写入测试 fixture、运行日志或 README 截图。

## 14.8 安全验收

零 secret 扫描、无 raw private data、超大包拒绝、路径逃逸拒绝、未知组件拒绝、无默认远程执行、无无界下载/训练、无不受信 CI secrets。安全失败不是实验性能差，必须阻断发布。

本章是工程约束，不宣称完成形式化安全证明。发现问题走 SECURITY.md 的私密报告通道，再进行修复与披露。



---

<!-- source: docs/15_开源文档许可证与发布.md -->

# 15｜GitHub 发布、文档与社区维护

## 15.1 第一屏必须回答什么

README 依次给：项目一句话、当前实际状态、能做什么、不能做什么、最小运行方式、一份真实可复算结果、扩展方式、相关工作、贡献与引用。

不要第一屏放五个虚构性能数字。最好的首版展示是一个读者能复现的完整实验，以及“正确消息/错配消息/紧凑文本”的并列结果。

## 15.2 README 状态表

每个功能给 implemented 与 verified 两列：CPU 协议测试、真实模型前向、桥训练、自由生成、内容审计、异构配对、KV 通信、远程传输。未实现写 planned；未测试写 not tested。

工作名和仓库地址待所有者确认；不要伪造 PyPI 安装命令、badge、DOI、stars、用户数或机构署名。

## 15.3 文档结构

概念页解释 frozen/gradient/latent/text；quickstart 提供 CPU 和真实小模型路径；recipes 给增加桥/模型/任务；reference 放 schema 与 API；decisions 保存 ADR；limitations 列实际失败。

英文 README 作为面向公开开发者的入口，中文 README 完整覆盖核心限制与执行步骤。代码标识符与错误码保持英文，不做两套 API。

不要求第一个版本就有完整文档网站。Markdown 能准确维护比空壳网站更重要。

## 15.4 许可与归属

建议所有者评估采用 Apache-2.0 或其他适合其贡献目标的开源许可；最终选择属于所有者。基础模型、数据、参考代码与仓库自身许可分别登记，不假定一份仓库许可证覆盖一切。

发布桥权重前核对所用基础模型条款与数据许可，不自动打包原始权重。第三方代码改编应保留应有通知、出处和修改说明。若只参考论文思想而独立实现，也清楚引用相关工作。

本计划不提供法律结论；许可证选择不能由 Agent 为未经授权的第三方资产做决定。

## 15.5 引用与软件成果

提供真实作者、版本、发布日期和 URL 的 `CITATION.cff`。GitHub 支持基于这一文件展示软件引用入口；有软件即可提供软件引用，不必伪装成已发表论文。[S15]

DOI/归档可后续申请；未产生前留空而非填假编号。论文引用与软件引用分开，方法来自前人时明确表述。

## 15.6 Release checklist

干净安装 → README 全命令执行 → 支持矩阵证据检查 → tests/skip 报告 → schema 与旧版兼容 → checkpoint/结果 hash → 无隐私/secret → LICENSE/归属 → 限制说明 → changelog → tag/release。

构建出的 wheel/sdist 不得包含本地权重、大缓存、私有数据、隐藏 token 文件。检查实际包内容，不只检查 .gitignore。

## 15.7 初次公开的策略

可以先公开 planning/dev 分支，让项目方向与实现进度可见；但不要把空骨架称为可用 release。0.0.1.dev 至少完成真实小模型 smoke，0.1.0 给完整可复算报告。

对外介绍聚焦“可审计的潜通信训练与比较工具”，不是“首个模型心灵感应协议”。提供清楚的 good first issue：新增任务 renderer、改进 schema 错误、增加一个模型 probe fixture，而不是让陌生贡献者接管整个训练系统。

## 15.8 Issue 与 PR 规范

Bug 模板要求版本、模型 revision、配置、最小复现、error code、去敏日志、期望/实际。性能问题要求硬件、dtype、长度、warmup 和测量方法。新后端要求能力测试与最少一条真实结果。

PR 一次只解决一个闭环；必须说明改变了哪条契约、哪些测试、是否破坏兼容、是否更新证据。仅修改 README 宣称支持而没有实现/测试的 PR 不接受。

## 15.9 社区扩张的顺序

先提升一个陌生用户按文档跑通的概率，再扩模型数量。维护少量真实支持比列几十个理论兼容更有价值。有人复用核心接口后再考虑插件生态、服务化或外部 Agent 框架适配。



---

<!-- source: docs/16_开发顺序与工作包依赖.md -->

# 16｜开发顺序与工作包依赖

## 16.1 核心执行策略

不是“先写全部框架，最后才第一次加载模型”，而是：**先定义最小公共契约，然后做一条真实纵向通路，再围绕已证实的变化点扩展。**

把可复用代码提前做，但不把研究假设、兼容性和性能提前宣布完成。整个项目先控制在一个仓库、一个维护者可理解的核心之内。

## 16.2 阶段 A：立约与可安装骨架

对应 W00–W03、W08、W26 的基础部分。产物是项目宪法、pyproject、类型/schema、错误与 artifact writer、toy backend、CPU CI。

验收：干净环境可安装；import 无副作用；config 严格校验；run 状态真实记录；小型 CPU 运算可测。此时可以公开规划分支，不宣称真实模型效果。

## 16.3 阶段 B：真实纵向通路

对应 W06–W15、W17；W04–W05 的最小消息与兼容性实现要先于 W17 一并完成。依次完成数据/视图、模型 probe、格式与 labels、sender H、receiver P、桥、单步训练、基础循环、adapter 重载。

关键顺序：先全文基线可解，再训练桥。代码审查必须看完整信息流，不允许各模块单测通过就默认集成正确。

验收：指定小模型真实 forward、梯度、自由生成；模型冻结、桥 step；无泄漏；存取一致。这才满足工程预览的核心。

## 16.4 阶段 C：形成可信实验工具

对应 W16、W18–W25，并完善 W04–W05 的审计接入。补齐离线缓存、恢复、基线、审计、统计、成本、cached decode、CLI 和报告。

验收：一个配置能从数据到训练到逐例输出再到报告；换消息审计有效；成本口径一致；失败不隐藏；结果可重算。

## 16.5 阶段 D：公开可复现 alpha

对应 W27–W30。文档跟实际命令同步，执行 32 样本诊断与 held-out pilot，锁定 config/checkpoint，生成真实报告。结果允许为负。

验收：他人在干净环境能执行规定流程；支持矩阵每项有证据；README 没有虚假性能/兼容性。进行 tagged release 前必须由所有者确认公开资产与许可。

## 16.6 阶段 E：异构、预算与泛化

对应 W31–W34。新增第二模型家族，验证至少一个有向异构配对，增加 OOD，扫消息长度/维度与必要成本。

先做 A→B，再做 B→A；不能用一个方向结果替代双向。模型能力差异与通信能力差异分开，有全文/receiver-only 对照。

验收：更换 backend 不重写核心 runner；真实异构结果与失败边界公开；0.2.0 才描述这部分实际支持。

## 16.7 阶段 F：按证据选择一条研究扩展

W35–W38 都是未来 RFC，不同时实施。候选是共享空间、KV、远程服务、真实证据任务。哪个方向值得做，由现有瓶颈与实际使用者需求决定，而不是为了增加 README 长度。

## 16.8 可并行与不可并行

可并行：稳定 contracts 后，数据生成器、packet codec、artifact writer、toy backend 可以各自开发。

必须串行：格式器→label 对齐→prefix forward→训练梯度；reference generation→cached generation；逐例结果→统计→报告；真实证据→支持声明。

同一文件只能有一个主写 Agent。跨模块 API 先写 RFC/接口快照再并行，不能两个 Agent 各造一套同名但含义不同的消息对象。

## 16.9 每个工作包的完成定义

包含目标、依赖、允许修改路径、实现细节、成功/失败测试、禁止事项、交付证据。完成后给出真实 diff、运行命令、退出码、测试摘要和未验证项。

“写完代码”“看起来能运行”“预计没问题”不算完成。工作包可标 implemented/not_run，不能擅自标 verified。

## 16.10 优先级冲突的裁决

正确性高于性能；信息隔离高于 API 简洁；可复现高于少写几行配置；真实运行高于抽象优雅；一个小而完整功能高于多个未完成大模块。

任务卡全集见 `tasks/工作包全集.md`；它是执行清单，本章解释执行顺序。需要改依赖时记录理由并运行 DAG 校验，防止循环。



---

<!-- source: docs/17_Agent开发协作协议.md -->

# 17｜交给编码 Agent 的执行协议

## 17.1 角色设置

主执行 Agent 负责一个工作包；独立审查 Agent 只审 diff、契约和测试，不凭作者自述通过；仓库所有者决定范围变化、昂贵实验和远程发布。

不必真的使用很多 Agent。单个 Agent 顺序执行也适用，重要的是任务和证据边界清楚。

## 17.2 进入任务前

必须读取项目宪法、contracts、对应任务卡、相关 ADR 和上一个交接记录。检查工作树状态，保留已有修改。列出准备修改的路径和验收命令。

不得假定所有依赖已实现；先执行当前真实测试。缺失文件、版本不匹配、训练资源不足，都记录为具体阻塞，不编造替代结果。

## 17.3 修改边界

只能修改任务卡允许的路径及经过说明的必要测试。发现公共契约需要改变，先记录 ADR 与影响清单；不偷偷绕过校验或放宽断言。

默认不安装系统级依赖、不更新驱动、不删除用户文件、不下载大模型、不使用付费 API、不推送远程、不发布包。需要外部行为时由任务配置和明确授权共同允许。

## 17.4 实现方法

先写输入/输出和失败条件测试；实现最小路径；运行测试；再重构。允许 mock 外部加载，但语义测试必须使用真实模型/真实梯度，不能 mock 成功。

不得通过硬编码答案、按 sample_id 查表、把测试资料加入训练、忽略失败样本、修改 test 预期来“修复”模型表现。

不要添加伪成功的 try/except。必须传播错误或返回带失败状态的结构，不能吞掉异常后写空结果。

## 17.5 资源预算

执行前确定 max_steps、数据规模、模型下载预算、磁盘写入目录。完成最小测试后停止，不在没有请求的情况下自动展开超参数网格。

GPU 不可用时可完成 CPU/协议工作并标明真模型未验证；不可把 CPU toy 结果写成用户笔记本实测。不得承诺后台继续跑完后再交付。

## 17.6 强制交接格式

```text
工作包 ID：
本次实际实现：
修改文件：
关键契约变化：
运行命令与退出码：
通过/失败/跳过测试：
生成的证据路径：
尚未验证的能力：
已知风险与下一依赖：
是否触及网络/下载/权限：
```

不使用“全部完成”掩盖 skip。测试日志路径必须真实存在，不能用样例日志替代。

## 17.7 审查重点

数据权限是否符合 views；损失是否对齐；基座是否冻结；Z 是否被 detach；序列化是否进入训练；prefix 是否重复；target 是否混进 prompt；cache key 是否完整；cost 是否有漏项；report 是否来自实际 predictions。

审查 Agent 至少尝试一个故意破坏的负向用例，确认保护性测试能失败。仅观察正常测试全绿不够。

## 17.8 偏离与失败处理

原设计失败后，先说明证据和最小必要改动；不要用更大模型、更多训练、更多 Agent 自动掩盖根因。

变更模型/精度/模板/预算都创建新 run；变更算法创建架构版本；变更协议创建 schema version。旧结果不覆盖，失败保留。

## 17.9 提示词交付

`prompts/` 提供总控、模块实现、独立审查、真实模型烟测、实验执行和发布审计提示词。把路径占位替换成真实工作区后可交给 Agent。提示词定义的是行为约束，不代替真实权限系统。



---

<!-- source: docs/18_风险故障排查与止损.md -->

# 18｜风险登记、故障排查与停止扩张

## 18.1 风险清单

| 风险 | 早期信号 | 第一动作 | 禁止补救 |
|---|---|---|---|
| 桥没有梯度 | grad None/零，loss 不动 | 检查 no_grad/detach/optimizer/门控 | 直接扩大训练集 |
| 标签错位 | loss 降但自由生成异常 | 手工短序列 CE、模板边界测试 | 只报告 loss |
| 基座偷偷更新 | 参数 diff/optimizer 越界 | 冻结白名单、重新开始 run | 仍称冻结模型实验 |
| 伪通信 | matched≈deranged，constant 同样好 | 内容审计与反事实 | 只展示准确率提升 |
| 数据捷径 | receiver-only 很高 | 随机世界、顺序、名字与 split 审计 | 删除不利基线 |
| 目标泄漏 | target 出现在输入字段 | 阻断、修复、废弃污染结果 | 解释为高效编码 |
| 推理与训练不一致 | teacher forcing 好、生成差 | 模板、位置、EOS、cache 对齐 | 换模型掩盖 bug |
| hidden 空间错位 | 注入后乱码/概率崩坏 | 检查尺度、位置、维度，训练简单桥 | 假设同维就应可读 |
| 缓存污染 | 改 q/revision 结果没变 | cache key/manifest 检查 | 清缓存后不解释旧结果 |
| OOM | 长输入/双模型峰值超限 | 单模型共享、离线 H、小 batch | 修改系统分页/杀用户进程 |
| 字节结论错 | 槽少但包更大 | 实测完整 payload 与 sidecar | 用槽数代替字节 |
| 速度结论错 | 只测 receiver、没同步 | 完整 request 边界与 GPU 同步 | 只选最快一条 |
| 兼容性夸大 | 只加载就写 supported | 六维能力证据 | 自动推断语义支持 |
| 框架膨胀 | 目录很多，真实路径未通 | 回到最小纵向闭环 | 再建插件市场/前端 |
| 复现失败 | 同配置缺 revision/模板 | manifest 补全与 pin | 发布不可追溯均值 |

## 18.2 训练问题的排查顺序

1. 全证据输入能否完成最简单任务？不能则降低任务难度或换经明确记录的候选模型。
2. 不用桥，普通 token 与相同 embedding 输入 logits 是否一致？不一致先修后端。
3. prefix 维度、mask、位置和 loss label 是否正确？
4. toy/tiny random 的接收输入梯度是否存在？
5. 真实模型的桥参数是否获得有效梯度？
6. 32 样本是否能够过拟合？
7. 未见样本是否泛化？
8. matched 是否优于 deranged/constant？
9. 才比较结构化文本成本。

这个顺序能把模型能力、工程正确性、可学习性、泛化和实用性拆开。

## 18.3 停止条件不是放弃项目

一个桥在某配对上无效：保留接口与负结果，测试更简单桥/不同注入配置。

多个桥都不优于文本：工具仍可作为评测与诊断框架；不要改成“潜通信一定更好”的宣传。

异构配对不稳定：把支持范围锁在已验证同模型场景，后续研究配对校准。

本机无法完整跑：完成 CPU、配置、协议、低资源烟测并明确未验证部分；云端只是后续独立资源决策，不自动发生。

## 18.4 回滚规则

优化造成 logits 回归，回滚优化而不是扩大测试容差。新 schema 破坏旧包，提供迁移或回滚，禁止覆盖旧 checkpoint。发现 test 泄漏，污染的结论作废，重新固定评测协议。

## 18.5 文档债与实验债

每次 API 变化同步 quickstart；每次支持状态变化更新能力矩阵；每次方法变化更新 config/architecture version；每次指标变化保存旧口径与迁移说明。

不把“以后写论文再补完整”作为证据管理策略。软件公开后，别人会立即用你的定义复现。



---

<!-- source: docs/19_扩展路线与研究议程.md -->

# 19｜扩展路线：保留空间，但不提前实现全部

## 19.1 选择扩展的规则

每个扩展要提交 RFC：当前瓶颈、最小假设、最近相关工作、需要改变的接口、对照、预算、成功/失败条件、迁移代价。没有这些，只有漂亮概念，不进入主线。

## 19.2 推荐顺序

| 优先级 | 扩展 | 增加哪些接口 | 验证什么 |
|---|---|---|---|
| A | 异构模型 | backend adapter、pair registry | 不改 runner 可以重训新配对 |
| A | 可变消息预算 | budget-conditioned encoder、slot mask | 质量/bytes Pareto 区间 |
| A | OOD 组合 | task family/split | 新事实、模板、依赖下内容仍有效 |
| A | 量化消息 | codec/quantizer/scales | 真实总 bytes 下降且质量可控 |
| B | 共享潜空间 | per-model E/D、shared profile | 未见模型配对组合 |
| B | 文本+潜消息 | typed sidecar、总成本 | 精确 ID/数字与潜状态互补 |
| B | 多发送者 | source IDs、set aggregation | 来源置换/缺失/冲突鲁棒性 |
| B | KV 注入 | layer/head/position/cache adapter | 正确性与 receiver prefill 收益 |
| C | 多轮自适应 | query/reply/stop protocol | 往返计费后更有价值 |
| C | 远程部署 | authenticated transport、quotas | 安全、网络成本、兼容协商 |
| C | 多模态 | modality spec、encoder access | 比原图/文字/特征基线更好 |

这些方向不是未经检索的原创性主张。实施前必须重新检查最接近前作，而不是沿用旧日期的“没人做”。

## 19.3 共享空间的实验设计

至少三个端点模型或多个可辨识配置，先明确哪些有向配对参与训练，哪些保留测试。固定共享 profile 与各 endpoint E/D 的训练权限。

比较 pair-specific 桥、共享桥、只重训新端点、从头训练新配对。记录校准数据和总计算；参数数目减少不等于训练成本减少。

不能只验证 A→B 和 B→C，就宣称 A→C 自然有效。A→C 必须作为真正未见组合测量。

## 19.4 KV 路线的额外约束

头数、head_dim、层数、RoPE/位置变换、缓存 layout、量化、缓存序列语义、接收新 token 的位置都要明确。把连续前缀转换成 receiver 自己产生的 KV，和直接把 sender KV 翻译成 receiver KV，是两种不同方法。

未来注入接口用 discriminated union：`PrefixInjection` 或 `KVInjection`，而不是在一个 tensor 上靠约定猜是什么。第一版仅注册 Prefix，不需要写一个空 KV 实现。

## 19.5 网络与训练

第一步远程扩展只做 inference packet transport。联合训练跨进程需要显式 gradient transport 或其他训练策略，并不由 safetensors/TCP 自动提供。

添加认证、加密、租户隔离、重放保护、取消、超时、限流和审计；这些是独立系统工程。首版避免开放服务，节省这部分维护负担。

## 19.6 真实研究任务的接入

政策分析：需要地区、时间、条款版本和出处 sidecar，潜消息本身不能替代引用。

代码交接：需要文件版本、执行状态、权限与可恢复日志，不仅是“思路向量”。

长期资料复用：测量一次构建、多次查询的摊销；查询条件化 H 与无查询共享 H 必须区分，不能同时享受二者的成本假设。

## 19.7 可以写论文的贡献层次

软件论文：清晰接口、可复现实验体系、内容审计与真实成本的标准化。

机制论文：哪些状态/位置/任务依赖允许真正内容传递，何时只是任务适配。

方法论文：预算控制、反事实训练、共享空间或量化等改进，须与最近直接前作比较。

应用论文：在明确真实任务与证据权限中有收益，不以合成任务代替应用验证。

先让工具解决可检查的问题，再决定论文是哪一种。GitHub 发布不需要等待所有这些成立。



---

<!-- source: docs/20_总验收与需求追踪.md -->

# 20｜总验收、需求追踪与完成判据

## 20.1 需求—模块—测试追踪表

| 需求 | 内容 | 主要模块/工作包 | 关键测试 |
|---|---|---|---|
| R01 | 项目边界与主张真实 | W00/W27/W30 | 发布人工审查、T59 |
| R02 | 配置严格可追溯 | W02/W03 | T01–T05 |
| R03 | 信息权限无 target 泄漏 | W06/W07/W10 | T18–T22 |
| R04 | 基座固定 | W09/W14/W15 | T28/T32 |
| R05 | 桥真正收到梯度 | W13/W14 | T29–T31 |
| R06 | prefix/mask/位置/labels 正确 | W10/W12 | T23–T27 |
| R07 | 独立自由生成正确 | W12/W23 | T35–T37 |
| R08 | 消息往返与边界 | W04 | T11–T17 |
| R09 | 兼容性证据分级 | W05/W09 | T15/T16/T56 |
| R10 | 资源预算受控 | W02/W22/W24 | T14/T52 |
| R11 | 缓存不陈旧不泄漏 | W16 | T39/T40 |
| R12 | 保存/重载/恢复安全 | W17/W18 | T41/T42 |
| R13 | 强且公平基线 | W19 | T47/T59+人工信息权限核查 |
| R14 | 实例内容审计 | W20 | T43–T45 |
| R15 | 配对统计与失败分母 | W21 | T46/T47 |
| R16 | 完整成本 | W22 | T48/T49/T60 |
| R17 | 再现与来源 | W03/W17/W25 | T41/T42/T51 |
| R18 | 两角色状态隔离 | W11/W12 | T38 |
| R19 | 无静默回退 | W05/W24 | T50/T52 |
| R20 | 本地与发布安全 | W04/W26/W30 | T14/T17/T53 |
| R21 | 干净安装与文档 | W01/W27 | T54/T55 |
| R22 | CI 不虚报覆盖 | W26 | 各 marker 计数与 skip 审查 |
| R23 | 扩展不改核心 | W31/W32 | T56 |
| R24 | 真模型证据不冒充 | W28/W29/W30 | T57–T59 |

## 20.2 工程预览发布清单

- [ ] 包可安装，模型不在 import 时下载。
- [ ] config/schema/错误码可执行。
- [ ] 合成任务和视图有效。
- [ ] 至少一个具体预训练模型的加载、提取、输入注入和单步梯度已实测。
- [ ] 基座冻结、桥更新、生成不输入真实答案。
- [ ] 适配器保存/重载有效。
- [ ] CPU/模型测试执行范围清楚，无用 toy 充当真模型的证据。
- [ ] README 当前状态与实际能力一致。

## 20.3 Alpha 发布清单

- [ ] 训练、验证、保存、恢复、评测完整运行。
- [ ] 原/反事实 group 不跨 split，必要信息对照完成。
- [ ] receiver-only、full-evidence、紧凑文本/结构化、constant、简单桥可比。
- [ ] matched/deranged/反事实审计实际产生逐例结果。
- [ ] cached decode 对 reference 正确性测试通过。
- [ ] 实际 bytes/latency/memory 口径明确，NA 不记 0。
- [ ] report 可由 predictions 重算。
- [ ] lock、revision、模板、配置、checkpoint 选择规则齐全。
- [ ] 无 private data、secret、任意对象加载风险或虚假支持标记。
- [ ] 成绩不佳也保留，不用效果阈值掩盖工程发布状态。

## 20.4 科学主张附加清单

- [ ] 主假设、主要指标、数据划分、比较方案事先确定。
- [ ] 没有 test 调参、标签泄漏或事后筛选。
- [ ] 内容效应与反事实成对成功符合事先规则。
- [ ] 不确定性与失败记录完整。
- [ ] 质量/成本比较条件公平；适用范围具体。
- [ ] 引用了直接前作，原创性措辞经过检索。

## 20.5 本计划包本身的验收

本交付物应包含：完整分册、任务依赖与卡片、Agent 提示词、配置/消息/run/数据等 schema、有效结构样例、发布/报告模板、来源索引、总合订版与文件校验。

对计划包做的结构校验只能证明文档/样例一致，不能算框架实现、模型训练、CUDA 支持或语义研究验证。最终交付时必须明确区分。

## 20.6 第一条行动

从 W00–W02 开始冻结边界与契约，随后并行合成数据和 toy 后端，尽快贯通 W09–W14 的真实模型训练单步。**先得到一条真实且可检查的通路，再把它扩成通用框架。**



---

<!-- source: docs/21_来源与事实边界.md -->

# 21｜来源、事实边界与本轮核验

## 21.1 用户提供的基础材料

本计划依据当前对话与附件《粘贴的文本 (1).txt》。附件的关键原意是：分散私有证据、冻结两端模型、发送端压缩到 Z、接收端前缀注入、反事实/错配审计、真实成本与强文本基线。

当前方案把重心从“先完成研究验证”调整为用户明确要求的“先构建可发布的通用实验软件，再累积科学证据”，但保留这些机制与评测边界。

附件中原有论文清单并未在本轮逐项重新核验，因此本计划不复制其中未复核的性能、时间、原创性或兼容性结论。下列条目是本轮用于技术接口和已有项目定位的公开资料。

## 21.2 核验日期与来源

公开来源访问基准：2026-10-23。官方文档可能继续变化，真正实现时仍应固定依赖版本与源 revision。这里的模型和项目说明不是独立复现实验。

| ID | 来源 | 本计划采用的范围 | 地址 |
|---|---|---|---|
| S01 | PyTorch Autograd mechanics | 冻结参数、no_grad、inference mode 与输入梯度的区别 | `https://docs.pytorch.org/docs/stable/notes/autograd.html` |
| S02 | Transformers Qwen3 model documentation | inputs_embeds、mask、position、cache 的接口基础 | `https://huggingface.co/docs/transformers/en/model_doc/qwen3` |
| S03 | Transformers Chat templates | 聊天格式依赖模型模板、token 边界需要验证 | `https://huggingface.co/docs/transformers/en/chat_templating` |
| S04 | Transformers How caching works | 增量解码、mask 与 cache 状态管理 | `https://huggingface.co/docs/transformers/en/cache_explanation` |
| S05 | Hugging Face Safetensors | 受限张量存储，不等于完整来源认证 | `https://huggingface.co/docs/safetensors/en/index` |
| S06 | PyTorch Reproducibility | 跨版本/平台完全重现的限制 | `https://docs.pytorch.org/docs/2.14/notes/randomness.html` |
| S07 | Qwen3-0.6B 官方模型卡 | 首个小模型候选，非性能排名与本机保证 | `https://huggingface.co/Qwen/Qwen3-0.6B` |
| S08 | SmolLM2-360M-Instruct 官方模型卡 | 第二家族候选，需独立测试 | `https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct` |
| S09 | Interlat / Enabling Agents to Communicate Entirely in Latent Space | 潜隐状态通信与学习压缩已有直接前作；首次提交 2025-11-12，本次页面最新版 2026-07-13 | `https://arxiv.org/abs/2511.09149` |
| S10 | Gen-Verse/LatentMAS 作者仓库 | 潜空间协作的现有公开实现；不承接其未独立复现的普适性能主张 | `https://github.com/Gen-Verse/LatentMAS` |
| S11 | VectorArc/avp-python 作者仓库 | 通用通信 SDK、兼容协商和回退已有人实现；不声称本项目首次 | `https://github.com/VectorArc/avp-python` |
| S12 | PyPA Packaging Python Projects | pyproject 与标准包发布基础 | `https://packaging.python.org/en/latest/tutorials/packaging-projects/` |
| S13 | pytest markers 官方文档 | 分层测试与资源标记 | `https://docs.pytest.org/en/stable/how-to/mark.html` |
| S14 | GitHub Actions Secure use reference | 最小权限、第三方 action 固定、避免不受信 PR 接触 secrets | `https://docs.github.com/en/actions/reference/security/secure-use` |
| S15 | GitHub About CITATION files | 软件引用文件与展示机制 | `https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-citation-files` |

## 21.3 哪些内容是本方案建议

项目命名、模块划分、版本策略、错误码、schema 字段、消息上限、测试 ID、工作包、初始超参数、数据规模、发布门槛与资源预算均为本计划的工程建议，不应引用成外部已证实结论。

三种通用性、工程验收与科学验收分离、同进程训练与线缆消息分离，是对项目目标的设计推导。模型间通信是否有效仍需要项目自身实验。

## 21.4 本轮未进行的事项

未下载并训练预训练语言模型；未测用户 GPU；未复现上述论文；未测吞吐/准确率；未证明名称可用；未创建远程 GitHub 仓库；未决定用户的最终开源许可证；未认证任意模型配对。

计划包内的 schema/任务依赖/文档校验与这些事项不是一回事。所有示例配置和消息明确为 example，不可当作实测结果。



---

<!-- source: tasks/工作包全集.md -->

# 工作包全集

所有工作包状态为 planned。下列路径指未来实现仓库，不代表本计划包已经包含对应实现。任务完成必须附实际执行证据；W35–W38 是后续 RFC，不在首版范围。


| ID | 工作包 | 前置依赖 | 里程碑 |
|---|---|---|---|

| W00 | 冻结项目边界与架构决策 | 无 | foundation |

| W01 | 可安装的轻量包骨架 | W00 | foundation |

| W02 | 严格配置与公共类型 | W01 | foundation |

| W03 | Run manifest 与原子产物写入 | W02 | foundation |

| W04 | 消息 codec 与边界验证 | W02 | alpha |

| W05 | 兼容性记录与显式回退 | W02, W04 | alpha |

| W06 | PrivateLookup 世界与反事实生成器 | W02 | vertical |

| W07 | Split、视图与信息边界 | W06 | vertical |

| W08 | Toy 与随机小模型后端 | W02 | foundation |

| W09 | HF 加载与能力探测 | W08 | vertical |

| W10 | 模板、token span 与训练标签 | W07, W09 | vertical |

| W11 | 发送者状态提取与角色隔离 | W09, W10 | vertical |

| W12 | 前缀前向与 ReferenceGreedy | W09, W10 | vertical |

| W13 | 两种桥与内容盲对照 | W08, W02 | vertical |

| W14 | 单步训练与梯度证明 | W11, W12, W13 | vertical |

| W15 | 有界训练循环与正确累积 | W14, W03, W07 | alpha |

| W16 | 离线发送状态缓存 | W11, W03 | alpha |

| W17 | 公开适配器保存与重载 | W13, W03, W05 | vertical |

| W18 | 受控续训与 RNG 恢复 | W15, W17 | alpha |

| W19 | 强文本、结构化与无消息基线 | W12, W07 | alpha |

| W20 | 内容替换与反事实审计 | W15, W17, W19 | alpha |

| W21 | 组级配对统计与指标 | W20 | alpha |

| W22 | 真实成本记录器 | W03, W14, W19 | alpha |

| W23 | 经过对照验证的缓存解码 | W12, W22 | alpha |

| W24 | 完整 CLI 与实验编排 | W04, W05, W15, W16, W17, W19, W20, W21, W22 | alpha |

| W25 | 可重算 Markdown 与 CSV 报告 | W21, W22, W03 | alpha |

| W26 | 分层 CI 与供应链约束 | W01, W02, W08 | foundation |

| W27 | 文档、适配器卡与发布说明 | W14, W17, W19, W26 | preview |

| W28 | 工程预览版发布审计 | W14, W17, W26, W27 | preview |

| W29 | 32 样本诊断与 held-out pilot | W15, W18, W19, W20, W22, W24, W25 | alpha |

| W30 | 可复现 alpha 发布 | W29, W23, W26, W27, W18 | alpha |

| W31 | 第二模型家族适配 | W30, W09, W10 | heterogeneous |

| W32 | 有向异构配对训练与评测 | W31, W15, W20 | heterogeneous |

| W33 | 组合与模板 OOD 任务 | W30, W07 | heterogeneous |

| W34 | 预算扫描与质量成本前沿 | W32, W33, W22 | heterogeneous |

| W35 | 共享空间 RFC | W34 | future |

| W36 | KV 通信 RFC | W34 | future |

| W37 | 远程推理传输 RFC | W30, W04, W05 | future |

| W38 | 真实证据任务 RFC | W30, W07, W20 | future |


## W00｜冻结项目边界与架构决策

前置依赖：无。里程碑：foundation。

### 允许修改范围

- `docs/decisions/`
- `AGENTS.md`
- `项目状态表`

### 具体实施

1. 写明工程/科学两条验收线与首版非目标。
2. 确认工作名只为占位、模型/许可证由所有者最终决定。
3. 记录前缀位置、同进程训练、JSON 配置三个 ADR。
4. 列出现有文件与不得修改的本机资源。

### 验收测试

人工核对 00/02/14 章；所有主张标为 planned 或有证据；无虚构 GitHub/PyPI 地址。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

三个核心 ADR 无互相冲突；任务权限、范围、证据状态能直接回答；不执行发布或下载。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W01｜可安装的轻量包骨架

前置依赖：W00。里程碑：foundation。

### 允许修改范围

- `pyproject.toml`
- `src/latent_comm/__init__.py`
- `src/latent_comm/cli/main.py`
- `tests/unit/test_import.py`

### 具体实施

1. 建立 src 布局、版本来源与可选依赖。
2. 提供 --version/--help，不触发模型加载。
3. 区分核心协议与 hf/dev extras。
4. 干净环境构建 wheel 并检查内容。

### 验收测试

T53/T54；临时禁网环境 import；无 torch/transformers 的轻量命令测试。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

wheel 可安装且包内没有模型/缓存/凭证；help 与 import 不联网、不初始化 GPU。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W02｜严格配置与公共类型

前置依赖：W01。里程碑：foundation。

### 允许修改范围

- `src/latent_comm/contracts/`
- `tests/contracts/`

### 具体实施

1. 实现视图、tensor spec、run config 与错误码。
2. 以 schema 为入口拒绝未知字段和重复键。
3. 跨字段检查训练通道、revision、预算、dtype。
4. 把 example/占位符配置阻断在执行前。

### 验收测试

T01–T10；合法配置与每类无效配置 fixture；模式组合参数化测试。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

合法输入有稳定 resolved 表示；拼错键、缺 revision、训练非可微通道在加载模型前失败。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W03｜Run manifest 与原子产物写入

前置依赖：W02。里程碑：foundation。

### 允许修改范围

- `src/latent_comm/artifacts/manifest.py`
- `src/latent_comm/artifacts/writer.py`
- `tests/unit/test_artifacts.py`

### 具体实施

1. 实现 run 状态机与唯一 run 目录。
2. 保存配置/环境/输入 manifest。
3. 临时写入后原子完成。
4. 未测量使用 null，路径只在允许根内。

### 验收测试

T17/T40/T49；中断写入、重复 run、磁盘预算与路径逃逸测试。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

失败运行保留真实状态；未完成文件不能冒充完整报告；不覆盖已有运行。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W04｜消息 codec 与边界验证

前置依赖：W02。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/channels/packet.py`
- `src/latent_comm/channels/codec.py`
- `tests/contracts/test_packet.py`

### 具体实施

1. 实现 header JSON 与单样本 safetensors。
2. 校验 shape/dtype/finite/摘要/长度。
3. 编码解码均为推理操作并声明不可微。
4. 原始字节与完整序列化字节分开。

### 验收测试

T11–T17/T48；真实往返、截断损坏、未知版本、大尺寸和多余 tensor key。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

合法包精确往返；恶意或无效包在昂贵分配/执行前拒绝；checksum 不被称为认证。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W05｜兼容性记录与显式回退

前置依赖：W02, W04。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/channels/compatibility.py`
- `src/latent_comm/backends/capabilities.py`
- `tests/contracts/test_compatibility.py`

### 具体实施

1. 实现六维 capability 记录。
2. 严格比较模型/桥/profile/模板指纹。
3. 区分 experimental 与 strict。
4. 研究默认失败，应用显式回退且记录实际通道。

### 验收测试

T15/T16/T50/T56；同维不同 profile、未测配对、文本回退成本路径。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

load 成功不会升级为 semantic 支持；任何回退都能从逐例记录识别。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W06｜PrivateLookup 世界与反事实生成器

前置依赖：W02。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/tasks/private_lookup.py`
- `tests/unit/test_private_lookup.py`

### 具体实施

1. 程序生成两张可连接映射表。
2. 随机实体/候选/顺序并保持答案均衡。
3. 交换发送端两条 key 构造合法反事实。
4. 提供可读样例和确定性 oracle。

### 验收测试

T18/T19/T22；大量随机 seed 的唯一性、可解性与反事实性质检查。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

原/反事实只改变 sender 事实且正确答案改变；相同 seed 产生相同 canonical world。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W07｜Split、视图与信息边界

前置依赖：W06。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/tasks/split.py`
- `src/latent_comm/tasks/views.py`
- `src/latent_comm/tasks/scoring.py`
- `tests/security/test_information_boundary.py`

### 具体实施

1. 按 canonical family/group 分割再渲染。
2. 严格 SenderView/ReceiverView/Supervision。
3. 评分规则预先确定。
4. 加入 ID/target/split 不渲染和跨 split 去重。

### 验收测试

T20/T21/T47；故意塞 target 的 mutation；世界改写不跨 split。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

推理函数拿不到 Supervision；删除答案字段不影响 renderer；group 无交叉。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W08｜Toy 与随机小模型后端

前置依赖：W02。里程碑：foundation。

### 允许修改范围

- `src/latent_comm/backends/base.py`
- `src/latent_comm/backends/toy.py`
- `tests/integration/test_tiny_backend.py`

### 具体实施

1. 实现最小协议与 shape 检查。
2. 构造固定小尺寸 CPU 模型用于真实 autograd。
3. 把 toy/random 和 pretrained 身份写入结果。
4. 不用网络下载。

### 验收测试

T06–T10/T23/T29；固定输入前向/梯度与 shape 负向测试。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

CPU 无下载可跑通计算；任何结果明确非预训练模型语义证明。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W09｜HF 加载与能力探测

前置依赖：W08。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/backends/hf_causal.py`
- `src/latent_comm/backends/capabilities.py`
- `tests/integration/test_hf_probe.py`

### 具体实施

1. 使用显式 model revision 与独立目录。
2. 默认禁 remote code。
3. 实际 probe hidden/input embedding/input-gradient。
4. 读取真实维度与 device/dtype，输出 evidence record。

### 验收测试

T04/T23/T28/T53/T58；tiny config 自动测试，真实模型 smoke 另标记。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

只有实际探测能力可标 pass；缺权限/资源时 not_run，不伪造支持。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W10｜模板、token span 与训练标签

前置依赖：W07, W09。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/backends/formatting.py`
- `tests/integration/test_formatting.py`

### 具体实施

1. 统一 sender 的 q 在证据前、receiver 模板与答案边界。
2. 防止特殊 token 重复。
3. 正确 mask 前缀/prompt/padding。
4. 核对单次 causal shift 与训练/推理提示一致。

### 验收测试

T21/T25/T26/T27；空答案、不同终止符、中文/英文和 BPE 边界案例。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

手算 CE 与实现一致；目标字段不出现在生成 prompt；超长关键证据明确拒绝。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W11｜发送者状态提取与角色隔离

前置依赖：W09, W10。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/backends/hf_causal.py`
- `tests/integration/test_extraction.py`

### 具体实施

1. 冻结/eval sender 并在 no_grad 提取指定状态。
2. 保存 post-norm/layer/pooling span 语义。
3. 释放无用多层引用。
4. 同权重角色之间不共享请求 KV。

### 验收测试

T08/T28/T38；改变 q 的条件效应、padding 与分离上下文检查。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

H 只有合法 sender 信息；同权重顺序执行不会夹带 receiver/其他请求内容。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W12｜前缀前向与 ReferenceGreedy

前置依赖：W09, W10。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/backends/generation.py`
- `src/latent_comm/backends/hf_causal.py`
- `tests/integration/test_prefix.py`

### 具体实施

1. 实现 before_rendered_prompt 的唯一默认位置。
2. 正确扩展 mask/positions。
3. 先 batch=1 无缓存生成。
4. 返回仅 generated token 与准确 stop_reason。

### 验收测试

T23–T27/T35/T37/T38；零前缀与无前缀分开、prefix 重复 mutation。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

token 路径与等价 embeds 路径一致；训练/生成都可注入；生成不接收答案。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W13｜两种桥与内容盲对照

前置依赖：W08, W02。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/bridges/`
- `src/latent_comm/baselines/constant.py`
- `tests/unit/test_bridges.py`

### 具体实施

1. 实现 masked mean linear 与 query pooling。
2. 投影维度动态读取。
3. 固定 nonzero 初始化与有限性检查。
4. constant/input-blind 对照不读样本元数据。

### 验收测试

T06–T10/T29；mask 极端、不同 d_s/d_r、关键参数梯度测试。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

两桥在不同源/目标维度可运行；input_blind 输出不随 sender 内容变化。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W14｜单步训练与梯度证明

前置依赖：W11, W12, W13。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/training/losses.py`
- `tests/integration/test_train_step.py`

### 具体实施

1. 连接 H→E→Z→D→P→loss。
2. optimizer 仅包含桥。
3. 冻结接收者但保留输入梯度。
4. 比较 step 前后参数并实现断梯度检测。

### 验收测试

T28–T32/T58；故意 no_grad 和 detach 必须被测试捕获。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

真实指定模型至少一次 finite/nonzero 梯度和桥更新；基座不变；缺 GPU 不冒充实测。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W15｜有界训练循环与正确累积

前置依赖：W14, W03, W07。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/training/trainer.py`
- `src/latent_comm/training/sampling.py`
- `tests/integration/test_training_loop.py`

### 具体实施

1. 实现步骤上限、验证频率、scheduler、clip 和状态机。
2. 按有效 token 归一累积。
3. 反事实对同 optimizer step。
4. NaN/预算错误停止并保存诊断。

### 验收测试

T33/T34/T47；大 batch 对照、残余累积组、异常中断。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

循环不无限运行、不吞错误；验证不更新参数；loss 口径与配置一致。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W16｜离线发送状态缓存

前置依赖：W11, W03。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/artifacts/cache.py`
- `tests/integration/test_cache.py`

### 具体实施

1. 完整 cache key 覆盖模型/模板/q/状态/dtype。
2. shard 与配额。
3. 缓存 H 而非训练变化的 Z。
4. 分片读取并原子完成。

### 验收测试

T39/T40/T17；改变 q/revision/template miss，中断 shard 拒读。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

在线/缓存 H 在容差内一致；缓存不绕过 encoder 训练；磁盘超限有明确错误。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W17｜公开适配器保存与重载

前置依赖：W13, W03, W05。里程碑：vertical。

### 允许修改范围

- `src/latent_comm/training/checkpoint.py`
- `src/latent_comm/artifacts/integrity.py`
- `tests/integration/test_adapter_bundle.py`

### 具体实施

1. 只导出桥权重与配置指纹。
2. 保存校准/profile 与能力限制。
3. 安全加载组件白名单。
4. 不分发基座、私有数据或 optimizer 对象。

### 验收测试

T41/T12/T15/T17；修改权重/模板/profile 后拒绝或降级证据。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

重载输出可复现；包可验证且不会执行任意代码；未验证性能不写入成功标记。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W18｜受控续训与 RNG 恢复

前置依赖：W15, W17。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/training/checkpoint.py`
- `tests/integration/test_resume.py`

### 具体实施

1. 只在 optimizer-step 边界保存。
2. AdamW tensor/metadata 受限序列化。
3. 恢复 RNG/sampler/scheduler/scaler。
4. 校验参数名称/形状与配置。

### 验收测试

T42/T40；不中断与中断恢复的短训练逐步比较。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

声明容差内可续训；错误形状与损坏状态拒绝；不使用不可信 pickle。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W19｜强文本、结构化与无消息基线

前置依赖：W12, W07。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/baselines/`
- `tests/integration/test_baselines.py`

### 具体实施

1. 实现 receiver-only/full-evidence/compact structured/短文本。
2. 区分合法解析器与特权 oracle。
3. 统一输出/预算规则。
4. 训练文本版本另列并公平计费。

### 验收测试

T21/T47/T48；信息权限、完整成本和答案生成格式检查。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

全文可解性先于桥研究判断；不故意削弱文本；所有条件有统一逐例记录。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W20｜内容替换与反事实审计

前置依赖：W15, W17, W19。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/evaluation/audits.py`
- `tests/integration/test_audits.py`

### 具体实施

1. 构造无固定点 donor 与同条件分层。
2. 在 Z 边界替换。
3. 实现 matched/zero/random/constant/cf。
4. 保存 donor 分配用于复现。

### 验收测试

T43–T45/T50；错配不得误用 donor 标签，反事实两条均对才成功。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

固定其余输入后只改指定消息；真实负结果完整保留。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W21｜组级配对统计与指标

前置依赖：W20。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/evaluation/metrics.py`
- `src/latent_comm/evaluation/bootstrap.py`
- `tests/unit/test_metrics.py`

### 具体实施

1. 实现整体分母与失败率。
2. 组级 bootstrap 保持 cf/方法配对。
3. 多 seed 单独汇总。
4. 未测量保持 null，统计参数写 manifest。

### 验收测试

T45–T47/T49；小样本可手算指标与重采样性质测试。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

从逐例结果可重算；不把相关样本当独立；不自动筛掉失败。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W22｜真实成本记录器

前置依赖：W03, W14, W19。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/evaluation/costs.py`
- `tests/unit/test_costs.py`

### 具体实施

1. 区分 raw/payload/header/sidecar 与网络 NA。
2. 阶段计时和完整 request 独立。
3. GPU 同步、warmup、peak metrics。
4. 资源预算与测量状态明确。

### 验收测试

T48/T49/T60；已知 tensor bytes 手算与假时钟测试，GPU 条件单列。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

不把槽数当字节、不把缓存训练当线上免费、不漏 sender。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W23｜经过对照验证的缓存解码

前置依赖：W12, W22。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/backends/generation.py`
- `tests/integration/test_cached_decode.py`

### 具体实施

1. 首次 P+prompt prefill。
2. 后续只输入新 token。
3. 维护 prefix-inclusive cache positions。
4. 对每步 logits 与 reference 比较后再 profile。

### 验收测试

T36/T37/T60；重复 prefix、off-by-one、EOS 和近似平局案例。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

正确性通过才开启性能模式；不同版本 cache 差异封装在 backend。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W24｜完整 CLI 与实验编排

前置依赖：W04, W05, W15, W16, W17, W19, W20, W21, W22。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/cli/`
- `tests/integration/test_cli.py`

### 具体实施

1. 实现 validate/data/probe/cache/train/evaluate/audit/benchmark/export/verify。
2. CLI 为 API 薄层。
3. 退出码/JSON stdout。
4. 不默认联网或远程发布。

### 验收测试

T01–T05/T50/T52/T53/T55；端到端 toy 与真实命令分开。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

一个 resolved config 能驱动完整闭环；错误可定位；中文/空格路径有效。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W25｜可重算 Markdown 与 CSV 报告

前置依赖：W21, W22, W03。里程碑：alpha。

### 允许修改范围

- `src/latent_comm/reporting/`
- `tests/integration/test_report.py`

### 具体实施

1. 从 predictions/manifest 计算表格。
2. 展示证据等级、失败、NA 和限制。
3. 无需浏览器前端。
4. 相同输入确定性输出。

### 验收测试

T49/T51；手工小结果 golden table 与重复运行差异检查。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

报告没有手填性能数字；结果能追溯到行级记录与 checkpoint。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W26｜分层 CI 与供应链约束

前置依赖：W01, W02, W08。里程碑：foundation。

### 允许修改范围

- `.github/workflows/`
- `tests/markers`
- `pyproject.toml`

### 具体实施

1. 离线 PR CI、tiny-random 合约、真实模型 opt-in。
2. 最小权限与受信 action 固定。
3. wheel 安装测试。
4. 展示 skip 与证据范围。

### 验收测试

T53/T54；故意联网/缺依赖场景；不受信 PR 无 secrets。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

CI 绿色只代表实际执行测试；不提供伪造 action SHA；后续工作包持续补入。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W27｜文档、适配器卡与发布说明

前置依赖：W14, W17, W19, W26。里程碑：preview。

### 允许修改范围

- `README.md`
- `README.zh-CN.md`
- `docs/`
- `CITATION.cff`
- `CONTRIBUTING.md`
- `SECURITY.md`

### 具体实施

1. 把快启与真实命令对应。
2. 状态表区分实现/验证。
3. 相关工作与限制。
4. 软件作者/许可/地址由所有者确认，引用无假 DOI。

### 验收测试

T54/T55；维护者执行所有声明可用命令；文档链接与资产检查。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

陌生读者能区分 toy、真实模型与语义结果；无未经验证的普适性能声明。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W28｜工程预览版发布审计

前置依赖：W14, W17, W26, W27。里程碑：preview。

### 允许修改范围

- `release checklist`
- `compatibility records`
- `CHANGELOG.md`

### 具体实施

1. 收集实际小模型单步/生成/重载证据。
2. 检查包内容与权限。
3. 给 dev 版本状态。
4. 仅准备发布资产，不擅自上传。

### 验收测试

20 章预览清单；T28/T29/T35/T41/T54/T58。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

不要求潜通信获胜；要求代码路径真实可检查；远程发布另有明确授权。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W29｜32 样本诊断与 held-out pilot

前置依赖：W15, W18, W19, W20, W22, W24, W25。里程碑：alpha。

### 允许修改范围

- `configs/`
- `runs/本次隔离目录`
- `benchmark report`

### 具体实施

1. 先全文可解性。
2. 过拟合 32 样本。
3. 再验证集 matched/deranged/cf/constant。
4. 按预算记录真实结果并选择 checkpoint，不看 test 调参。

### 验收测试

T57–T59；信息隔离、自由生成、失败分母与训练 manifest 完整性。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

有正/负结果均如实记录；不能只展示训练 loss；未完成条件标 not_run。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W30｜可复现 alpha 发布

前置依赖：W29, W23, W26, W27, W18。里程碑：alpha。

### 允许修改范围

- `release assets`
- `compatibility matrix`
- `CHANGELOG.md`

### 具体实施

1. 冻结配置与 checkpoint。
2. 执行预定测试并重算报告。
3. 干净环境运行 quickstart。
4. 审查许可证/隐私/依赖与公开主张。

### 验收测试

20 章 alpha 清单；T41/T42/T51/T54/T59/T60。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

完整运行闭环和可信报告；科学结果可为负；支持范围与证据完全对应。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W31｜第二模型家族适配

前置依赖：W30, W09, W10。里程碑：heterogeneous。

### 允许修改范围

- `src/latent_comm/backends/必要适配`
- `configs/`
- `tests/integration/`

### 具体实施

1. 选择并固定第二模型 revision。
2. 重测模板/状态/embeds/梯度/生成。
3. 不修改核心 runner。
4. 真实资源与失败记录。

### 验收测试

T23–T29/T35–T38/T56/T58。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

第二后端满足同样协议；载入成功与语义通信不混淆。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W32｜有向异构配对训练与评测

前置依赖：W31, W15, W20。里程碑：heterogeneous。

### 允许修改范围

- `configs/heterogeneous/`
- `evaluation records`

### 具体实施

1. 先 A→B 再独立 B→A。
2. 训练 pair-specific E/D。
3. 对齐公共任务/基线预算。
4. 给能力与内容审计矩阵。

### 验收测试

T29/T38/T43–T47/T59；两个方向不相互替代。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

至少一条真实异构路径可复现；失败组合也列出；不声称所有配对通用。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W33｜组合与模板 OOD 任务

前置依赖：W30, W07。里程碑：heterogeneous。

### 允许修改范围

- `src/latent_comm/tasks/`
- `configs/ood/`
- `tests/unit/`

### 具体实施

1. 按一个因素建立新名字/组合/模板/干扰/长度家族。
2. 保持 oracle 与信息权限。
3. 固定 held-out 定义与渲染版本。

### 验收测试

T18–T22/T45–T47；每个 OOD 家族单因素说明。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

不把同一世界改写随机切分称为泛化；训练/测试家族可追溯。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W34｜预算扫描与质量成本前沿

前置依赖：W32, W33, W22。里程碑：heterogeneous。

### 允许修改范围

- `configs/budgets/`
- `reports/`
- `experiment registry`

### 具体实施

1. 先 m 再 d_z 最后量化。
2. 显式配置枚举和总算力预算。
3. 完整强基线。
4. 实际 wire bytes 与训练成本摊销单列。

### 验收测试

T48/T49/T60；失败预算点完整记录。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

只在质量约束与实际成本支持时宣称优势；不挑最好一个点代表全部。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W35｜共享空间 RFC

前置依赖：W34。里程碑：future。

### 允许修改范围

- `docs/rfcs/shared_latent.md`

### 具体实施

1. 检索直接前作。
2. 定义每模型 E/D 与 shared profile。
3. 预留未见有向配对。
4. 确定校准成本/对照和失败条件。

### 验收测试

设计审查；训练配对与测试配对不重叠；无未经验证语义通用声明。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

只交 RFC，不自动开始多模型训练；经证据与资源批准后再拆实现卡。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W36｜KV 通信 RFC

前置依赖：W34。里程碑：future。

### 允许修改范围

- `docs/rfcs/kv_injection.md`

### 具体实施

1. 明确 layer/head/position/RoPE/cache/量化几何。
2. 区分 receiver-prefix-to-KV 与 sender-KV translation。
3. 设计 correctness reference。

### 验收测试

设计审查；shape 之外的语义/位置约束齐全。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

不提交空 KV 假实现；不将 prefix 的能力证据复用为 KV 支持。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W37｜远程推理传输 RFC

前置依赖：W30, W04, W05。里程碑：future。

### 允许修改范围

- `docs/rfcs/remote_transport.md`

### 具体实施

1. 确认真实需求。
2. 设计认证/加密/限流/取消/重放/租户。
3. 测真实网络字节。
4. 明确仅推理不自动支持跨进程训练。

### 验收测试

安全与资源审查；负向输入与超时计划。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

首版不开放端口；没有部署需求与授权不实现服务。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。


## W38｜真实证据任务 RFC

前置依赖：W30, W07, W20。里程碑：future。

### 允许修改范围

- `docs/rfcs/real_evidence_task.md`

### 具体实施

1. 选政策/代码/多文档之一。
2. 核对许可和隐私。
3. 定义必要证据与来源 sidecar。
4. 设计评测与成本口径。

### 验收测试

数据权限与标注审查；来源可回查；不使用未授权用户文件。测试 ID 的定义见 `docs/13_测试矩阵与CI.md`。

### 完成条件

有明确问题与可验证目标才纳入主线；合成结果不冒充真实应用效果。

### 禁止事项与交接

不得修改无关配置或用户模型；不得伪造日志、skip 后宣称验证通过、扩大资源预算或未经授权远程发布。提交修改清单、真实命令/退出码、证据路径、未验证项及下一依赖；公共契约改变必须附 ADR。



---

<!-- source: prompts/00_总控执行提示词.md -->

# 总控执行提示词

复制以下内容到编码 Agent；先替换工作目录和本次工作包 ID。此提示不授权公开上传、付费算力或修改系统。

---

你要实现 Latent Comm Lab：冻结开放模型之间的潜通信实验框架。规划包位于【规划包目录】，实现仓库位于【仓库目录】，本次只完成【工作包 ID】及必要的已批准前置修复。

先阅读 docs/00、02、04、06、14、17、20 和该工作包卡。工作名只是暂定，不要声称 PyPI/域名已可用。

先检查已有代码与 git status，保护现有修改。列出本次允许修改路径、准备运行的测试、网络/下载/计算需求。契约不清时使用计划已有决策，不自行增加多 Agent 平台、Web UI、RPC、数据库或工具执行能力。

永远保持：基座冻结；sender/receiver 私有证据隔离；target 只到损失/评测；receiver 训练保留输入梯度；训练 Z 不序列化、不 detach；推理没有真实答案；actual_channel 真实记录；成本包括发送和消息构造。

只使用本次任务的路径与资源预算。默认不联网、不下载大权重、不装系统软件、不改分页文件/驱动、不结束已有模型进程、不删除用户文件、不 push、不创建公开 release。需要这些行为时先报告具体需求和当前可完成部分，不能越权执行。

实现方式：先写关键成功与失败测试，再写最小实现；每次修改公共 API 同步 schema/fixture/文档。不能 mock 语义成功，不能硬编码答案，不能改测试预期来隐藏 bug。未完成组件返回明确 unsupported，不返回占位成功。

本次任务完成后停止，不自动启动下一轮大训练。输出：实现内容、修改路径、实际命令和退出码、通过/失败/跳过数量、证据文件、未验证事项、已知问题、下一步依赖。只有真实执行的能力可以写 verified；toy 测试与真实预训练模型结果分开。

若资源不具备，完成可验证的工程部分并标记 not_run；不得写“实测正常”或承诺后台完成。



---

<!-- source: prompts/01_模块实现提示词.md -->

# 单模块实现提示词

---

在【仓库目录】执行工作包【ID】。规划包位于【目录】。只实现任务卡中的职责，不重写整个项目。

先给出输入、输出、错误条件和依赖；确认它们与 contracts 的类型/字段/错误码一致。若要改变共享接口，先列出受影响的调用点、测试、配置和文档，再形成 ADR，不默默破坏其他模块。

优先写最小成功用例、一个非法输入、一个会揭露机制错误的测试。桥模块必须测梯度与 mask；后端必须测模板、位置、labels；codec 必须测边界与损坏；runner 必须测错误传播与预算；report 必须从逐例数据重算。

提交的代码有类型注解、必要注释、明确异常和有限资源行为。禁止 catch-all 后假成功，禁止任意 eval/import，禁止默认网络下载。不得新增无实际用例的抽象工厂或框架依赖。

运行实际测试并提供日志定位。不得声称实现仓库中尚不存在的命令已经通过。完成后按 AGENTS.md 交接格式报告，不越过当前工作包继续做实验。



---

<!-- source: prompts/02_独立审查提示词.md -->

# 独立代码审查提示词

---

你是独立审查者。审查【工作包 ID】的 diff 与证据，工作区是【路径】，计划包是【路径】。不要依据作者说“全部通过”直接批准。

先核对任务范围、类型契约和新增依赖。顺着数据流检查 q、sender evidence、receiver evidence、target、sample_id、split 分别流向哪里。检查是否存在未声明的信息通道、缓存查表或 target 注入。

对训练：检查基座参数白名单、接收输入梯度、序列化/detach、mask、causal shift、梯度累积归一、eval/train 状态和检查点选择。

对推理：检查真实答案未输入、prefix 不重复、cache position 包含前缀、EOS 与生成 token 切片正确、两个角色上下文隔离。

对结果：检查失败分母、group bootstrap、实际字节、未测量 null、回退标记、真实 checkpoint/版本。检查报告能否从 predictions 重算。

至少实际运行一个正常用例和一个故意错误的负向用例；资源不足的真模型测试标记未验证。不要自行放宽断言来通过审查。

输出按严重性排序的发现：位置、问题、可复现步骤、影响、建议修复、验收方法。最后明确 approved / changes_requested / blocked，以及未覆盖的测试范围。不要修改发布结果或代替作者伪造证据。



---

<!-- source: prompts/03_真实模型烟测提示词.md -->

# 真实模型 smoke 提示词

---

在独立研究环境执行批准的模型烟测，不碰现有聊天部署。模型为【ID】，revision 为【已固定 revision】，配置文件为【路径】，输出目录为【新目录】，明确资源上限为【步骤/磁盘/下载预算】。

先检查本地权重、PyTorch CUDA 与 dtype 能力、实际空闲资源。未授权不得下载或修改驱动。模型未准备好时报告缺失和已经完成的 CPU 检查，不拿 toy 输出代替。

按顺序：加载并冻结 → 普通 token 与对应 embedding 前向对照 → 提取 H → 编码 Z → 投影 P → receiver 前向计算答案损失 → backward → 只更新桥 → 保存重载 → 不输入答案的自由生成。

每一步记录 shape、dtype/device、有限性、梯度与参数变化；不记录敏感原文。基座 grad 应为 None，桥关键梯度应有限且非零；接收者 no_grad 或 Z.detach 必须能被检测到。

这次不跑大训练、不做超参搜索。输出具体通过的接口、未通过的接口、环境指纹和证据文件。单步成功只证明工程通路，不得写成语义通信成功或性能优势。



---

<!-- source: prompts/04_完整实验执行提示词.md -->

# 完整实验执行提示词

---

按已经固定的【实验配置】运行【工作包 ID】。预算、模型 revision、数据生成器、split、种子、checkpoint 选择规则和主要指标不能执行中擅自修改。

先验证数据 oracle 与组级划分，再做 receiver-only 和 full-evidence 任务可解性；检查桥训练梯度，然后执行规定训练。验证集选择 checkpoint，封存测试只用于最后规定评估，不得反复看 test 调参。

至少输出 matched、deranged、constant、合法 counterfactual 与紧凑结构化文本。所有条件使用相同合法证据权限和答案停止规则。donor 指派要保存，不能因为某次审计不利就换 seed。

计入发送、构造、序列化/传输、投影、接收和生成成本；线上新请求与离线缓存条件分别记录。没有测量的数据用 null，不用 0 或猜测补齐。

保存逐例预测、失败、配置、版本、检查点与成本。按 world/cf group 做配对统计，多训练 seed 单列。报告负结果和 OOM，不删除失败以提高分数。

达到预算或错误停止后交付已有完整证据，标记未完成条件。不得自动增加步骤、换更大模型、启用付费算力或承诺后台继续。



---

<!-- source: prompts/05_发布审计提示词.md -->

# 发布审计提示词

---

准备审计【版本】的发布资产，不自动推送远程。检查 20 章对应版本清单，所有 advertised capability 必须有对应模型 revision、配置和测试证据。

实际在干净环境执行 README quickstart；检查 wheel/sdist 内容、配置占位符、schema、能力矩阵、引用、许可证与第三方归属。检查没有模型大权重、私有数据、credentials、未授权用户文件或虚构 benchmark 数字。

将结果分成：工程已验证、真实模型已验证、科学假设结果、尚未验证。无效果优势不阻止实验工具发布；无真实实现不允许宣称支持。

CITATION 作者、repo URL、版本与日期必须真实，DOI 没有就不填写。action SHA、模型 revision、依赖 lock 不能留伪造占位。

输出 release readiness、阻断项、非阻断限制、资产清单和校验值。创建仓库、push、tag 发布或包上传需要所有者另行明确授权，不在本次审计中执行。



---

<!-- source: templates/ADAPTER_CARD.md -->

# Adapter card

状态：【experimental / validated-in-scope】

发送模型 ID/revision/config/tokenizer/template/state spec：
接收模型 ID/revision/config/tokenizer/template/injection spec：
encoder/projector 架构、权重 hash、训练参数量：
消息槽数/潜维度/dtype/semantic profile：
训练数据来源与 split policy、许可：
训练/校准预算与 seed：
检查点选择规则：
已测任务、内容效应、反事实表现与区间：
强文本/结构化基线：
成本测量条件与实际结果：
未测量字段：
适用范围、失败案例、不支持项：
复现配置/环境/逐例结果路径：
隐私与使用限制：

本卡不允许把未知字段补成“通用兼容”。更新任何 revision、模板或精度后重审能力证据。



---

<!-- source: templates/ADR.md -->

# ADR-【编号】：【决策标题】

状态：proposed / accepted / superseded

问题与约束：
备选方案：
选择及理由：
拒绝其他方案的具体原因：
涉及契约/数据/安全/成本：
需要更新的实现、schema、测试、文档：
如何验证这项决定：
什么证据会促使回滚或改变：
关联工作包、作者、日期与版本：



---

<!-- source: templates/AGENTS.md -->

# Repository execution rules

This repository is an experimental latent-communication library, not an autonomous agent platform.

Read the project charter, contracts, relevant ADR, and assigned work package before editing. Respect existing modifications. Work in the assigned paths only.

Frozen backbones must remain frozen. Keep receiver input gradients during bridge training. Do not detach or serialize the trainable message path. Never expose targets to inference. Keep sender and receiver private views separate.

Do not change system settings, drivers, unrelated model deployments, or user data. No unapproved downloads, paid compute, remote push, public releases, or network services. Respect explicit step, memory, and disk limits.

Do not fake benchmark numbers, logs, model compatibility, or test passes. Distinguish toy, random-model, pretrained-model, semantic, and performance evidence. Report skipped tests.

Every change needs positive and negative tests appropriate to the mechanism. API changes require a decision record and updated schema, fixtures, and documentation. Prefer a complete vertical slice over empty abstractions.

Handoff: implemented changes, modified files, contract changes, actual commands and exit codes, pass/fail/skip, evidence paths, unverified claims, remaining risks, next dependency.



---

<!-- source: templates/BENCHMARK_REPORT.md -->

# 实验报告

实验 ID / code commit / dirty flag / 日期：
本次主假设及预先确定的指标：
状态：planned / completed / partial / failed

## 模型与环境

模型 revisions、tokenizer/templates、backend versions、硬件、dtype、attention、上下文上限、真实通道：

## 数据与权限

生成器/数据版本、组级划分、必要信息对照、输入权限、反事实构造、数据许可：

## 训练与选择

桥架构、参数量、优化器、有效 token 归一、steps、seeds、训练/校准成本、checkpoint 选择规则：

## 结果表

| 条件 | 总样本 | 成功/失败 | 全体准确率 | cf_pair_success | 内容效应 | bytes | latency | memory |
|---|---|---|---|---|---|---|---|---|
| 【真实条件】 | | | | | | | | |

未测量写 NA，不填 0。不填演示分数。

## 内容审计、统计与成本

donor 规则、group bootstrap、各 seed、质量容忍、冷/热/缓存与线上边界、失败分母：

## 结论与限制

分开回答：工程能运行吗？实例信息被使用吗？相对文本是否值得？换条件有效吗？

## 复现

配置、checkpoint hash、input manifest、predictions、audit assignments、成本文件与重算命令：



---

<!-- source: templates/ISSUE_WORKPACKAGE.md -->

# 【Wxx】任务标题

目标与不做的内容：
前置依赖与当前状态：
允许修改路径：
输入输出与错误条件：
实现步骤：
关键测试 ID、实际命令与期望结果：
资源与网络预算：
完成条件与证据路径：
安全/兼容性/文档影响：
未验证事项与阻断：

禁止伪造结果、静默改范围、跳过失败后标记完成。



---

<!-- source: templates/PULL_REQUEST.md -->

# 变更摘要

关联工作包/需求：
实际实现与未实现：
契约/schema/版本变化：
信息权限与梯度影响：
运行的命令及退出码：
通过/失败/跳过测试：
真实模型/语义/性能验证范围：
结果与证据路径：
新增依赖、许可证、网络与权限变化：
文档与迁移：
已知限制与回滚方式：

- [ ] 没有把 toy 结果写成真实模型结论。
- [ ] 没有隐藏失败、修改标签或自动扩大实验预算。
- [ ] 没有泄露凭证/私有数据或未经授权发布资产。



---

<!-- source: templates/README.en.template.md -->

# Latent Comm Lab

An experimental toolkit for training, testing, and auditing communication interfaces between frozen open-weight language models.

**Status:** [fill from actual evidence; never infer semantic support from tensor compatibility].

## What it does

Provides a local differentiable hidden-state → latent-message → soft-prefix pipeline, replaceable bridges, synthetic private-evidence tasks, strong text baselines, content-dependence audits, and explicit cost accounting.

## What it does not claim

No claim of universal model interoperability, lossless thought transfer, privacy from unreadable vectors, or general superiority to text. A software release is not proof of a research hypothesis.

## Verification matrix

| Feature | Implemented | Verified configuration | Evidence |
|---|---|---|---|
| CPU contracts | [status] | [environment] | [path] |
| Pretrained-model gradient path | [status] | [revision/config] | [path] |
| Content-dependent communication | [status] | [task/checkpoint] | [path] |
| Heterogeneous pair | [status] | [directed pair] | [path] |

## Quickstart

[Insert only commands executed against this release. Clearly label no-download CPU tests separately from real-model experiments.]

## Results

[Insert a reproducible report or state that results are not yet available. Negative results are valid; fabricated example scores are not.]

## Extending / Limitations / Related work / Contributing / License / Citation

[Fill with actual project decisions, attribution, authorship, and release metadata.]



---

<!-- source: templates/README.zh-CN.template.md -->

# Latent Comm Lab

用于冻结开放模型之间的潜通信接口训练、测试和内容审计的实验工具库。

当前状态：【按真实证据填写】。本仓库的“可运行”不等于“潜通信优于文本”，接口形状兼容也不等于语义兼容。

## 已实现与已验证

【分别列出 CPU、真实模型接口、梯度、语义审计和性能的状态与证据。】

## 快速开始

【只放在本 release 实际执行过的命令。无下载 toy 示例与真实模型实验分开。】

## 实验与结果

【给出配置、模型 revision、数据、checkpoint、逐例预测与重算方法。未测量就说明未测；不要填示范准确率。】

## 限制

不承诺任意模型即插即用；默认不开放网络服务；潜消息不是隐私保护；原始证据仍须回查；成本包含发送处理与全部应用载荷。

## 扩展、相关工作、贡献、许可与引用

【根据实际决定填写，保留直接前作归属。】



---

# 附录｜机器可读规格与样例

这些 JSON 仅定义实现契约；example=true 的样例不得直接作为已执行实验使用。


## specs/compatibility.schema.json

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:latent-comm:compatibility:0.1",
  "title": "Latent Comm compatibility planning specification",
  "type": "object",
  "properties": {
    "schema_version": {
      "const": "0.1"
    },
    "example": {
      "type": "boolean"
    },
    "pair_id": {
      "type": "string",
      "minLength": 1
    },
    "sender_model_id": {
      "type": "string",
      "minLength": 1
    },
    "sender_revision": {
      "type": "string",
      "minLength": 1
    },
    "receiver_model_id": {
      "type": "string",
      "minLength": 1
    },
    "receiver_revision": {
      "type": "string",
      "minLength": 1
    },
    "semantic_profile": {
      "type": "string",
      "minLength": 1
    },
    "capabilities": {
      "type": "object",
      "properties": {
        "load": {
          "type": "object",
          "properties": {
            "status": {
              "type": "string",
              "enum": [
                "not_run",
                "pass",
                "fail",
                "unsupported"
              ]
            },
            "evidence_paths": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "minItems": 0
            },
            "note": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "status",
            "evidence_paths",
            "note"
          ],
          "additionalProperties": false
        },
        "extract": {
          "type": "object",
          "properties": {
            "status": {
              "type": "string",
              "enum": [
                "not_run",
                "pass",
                "fail",
                "unsupported"
              ]
            },
            "evidence_paths": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "minItems": 0
            },
            "note": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "status",
            "evidence_paths",
            "note"
          ],
          "additionalProperties": false
        },
        "inject": {
          "type": "object",
          "properties": {
            "status": {
              "type": "string",
              "enum": [
                "not_run",
                "pass",
                "fail",
                "unsupported"
              ]
            },
            "evidence_paths": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "minItems": 0
            },
            "note": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "status",
            "evidence_paths",
            "note"
          ],
          "additionalProperties": false
        },
        "input_gradient": {
          "type": "object",
          "properties": {
            "status": {
              "type": "string",
              "enum": [
                "not_run",
                "pass",
                "fail",
                "unsupported"
              ]
            },
            "evidence_paths": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "minItems": 0
            },
            "note": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "status",
            "evidence_paths",
            "note"
          ],
          "additionalProperties": false
        },
        "semantic": {
          "type": "object",
          "properties": {
            "status": {
              "type": "string",
              "enum": [
                "not_run",
                "pass",
                "fail",
                "unsupported"
              ]
            },
            "evidence_paths": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "minItems": 0
            },
            "note": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "status",
            "evidence_paths",
            "note"
          ],
          "additionalProperties": false
        },
        "cost": {
          "type": "object",
          "properties": {
            "status": {
              "type": "string",
              "enum": [
                "not_run",
                "pass",
                "fail",
                "unsupported"
              ]
            },
            "evidence_paths": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "minItems": 0
            },
            "note": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "status",
            "evidence_paths",
            "note"
          ],
          "additionalProperties": false
        }
      },
      "required": [
        "load",
        "extract",
        "inject",
        "input_gradient",
        "semantic",
        "cost"
      ],
      "additionalProperties": false
    },
    "scope_note": {
      "type": "string",
      "minLength": 1
    }
  },
  "required": [
    "schema_version",
    "example",
    "pair_id",
    "sender_model_id",
    "sender_revision",
    "receiver_model_id",
    "receiver_revision",
    "semantic_profile",
    "capabilities",
    "scope_note"
  ],
  "additionalProperties": false
}
```


## specs/config.schema.json

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:latent-comm:config:0.1",
  "title": "Latent Comm config planning specification",
  "type": "object",
  "properties": {
    "schema_version": {
      "const": "0.1"
    },
    "example": {
      "type": "boolean"
    },
    "run": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "seed": {
          "type": "integer",
          "minimum": 0
        },
        "mode": {
          "type": "string",
          "enum": [
            "train",
            "evaluate",
            "contract_test"
          ]
        },
        "description": {
          "type": "string",
          "minLength": 1
        }
      },
      "required": [
        "id",
        "seed",
        "mode",
        "description"
      ],
      "additionalProperties": false
    },
    "models": {
      "type": "object",
      "properties": {
        "sender": {
          "type": "object",
          "properties": {
            "backend": {
              "type": "string",
              "enum": [
                "toy",
                "hf_causal"
              ]
            },
            "model_id": {
              "type": "string",
              "minLength": 1
            },
            "revision": {
              "type": "string",
              "minLength": 1
            },
            "dtype": {
              "type": "string",
              "enum": [
                "float32",
                "bfloat16",
                "float16"
              ]
            },
            "device": {
              "type": "string",
              "minLength": 1
            },
            "trust_remote_code": {
              "const": false
            },
            "template_kwargs": {
              "type": "object",
              "additionalProperties": {
                "type": [
                  "string",
                  "number",
                  "boolean",
                  "null"
                ]
              }
            }
          },
          "required": [
            "backend",
            "model_id",
            "revision",
            "dtype",
            "device",
            "trust_remote_code",
            "template_kwargs"
          ],
          "additionalProperties": false
        },
        "receiver": {
          "type": "object",
          "properties": {
            "backend": {
              "type": "string",
              "enum": [
                "toy",
                "hf_causal"
              ]
            },
            "model_id": {
              "type": "string",
              "minLength": 1
            },
            "revision": {
              "type": "string",
              "minLength": 1
            },
            "dtype": {
              "type": "string",
              "enum": [
                "float32",
                "bfloat16",
                "float16"
              ]
            },
            "device": {
              "type": "string",
              "minLength": 1
            },
            "trust_remote_code": {
              "const": false
            },
            "template_kwargs": {
              "type": "object",
              "additionalProperties": {
                "type": [
                  "string",
                  "number",
                  "boolean",
                  "null"
                ]
              }
            }
          },
          "required": [
            "backend",
            "model_id",
            "revision",
            "dtype",
            "device",
            "trust_remote_code",
            "template_kwargs"
          ],
          "additionalProperties": false
        },
        "share_weights": {
          "type": "boolean"
        }
      },
      "required": [
        "sender",
        "receiver",
        "share_weights"
      ],
      "additionalProperties": false
    },
    "data": {
      "type": "object",
      "properties": {
        "task": {
          "const": "private_lookup"
        },
        "train_groups": {
          "type": "integer",
          "minimum": 1
        },
        "validation_groups": {
          "type": "integer",
          "minimum": 1
        },
        "test_groups": {
          "type": "integer",
          "minimum": 1
        },
        "candidates": {
          "type": "integer",
          "minimum": 2
        },
        "split_unit": {
          "const": "counterfactual_group"
        },
        "max_source_tokens": {
          "type": "integer",
          "minimum": 1
        },
        "max_receiver_tokens": {
          "type": "integer",
          "minimum": 1
        }
      },
      "required": [
        "task",
        "train_groups",
        "validation_groups",
        "test_groups",
        "candidates",
        "split_unit",
        "max_source_tokens",
        "max_receiver_tokens"
      ],
      "additionalProperties": false
    },
    "bridge": {
      "type": "object",
      "properties": {
        "encoder": {
          "type": "string",
          "enum": [
            "mean_pool_linear",
            "query_pool"
          ]
        },
        "slots": {
          "type": "integer",
          "minimum": 1,
          "maximum": 256
        },
        "latent_dim": {
          "type": "integer",
          "minimum": 1,
          "maximum": 4096
        },
        "attention_heads": {
          "type": "integer",
          "minimum": 1,
          "maximum": 32
        },
        "normalization": {
          "type": "string",
          "enum": [
            "none",
            "layer_norm"
          ]
        },
        "channel": {
          "type": "string",
          "enum": [
            "local_differentiable",
            "local_packet"
          ]
        },
        "wire_dtype": {
          "type": "string",
          "enum": [
            "float16",
            "bfloat16",
            "float32"
          ]
        }
      },
      "required": [
        "encoder",
        "slots",
        "latent_dim",
        "attention_heads",
        "normalization",
        "channel",
        "wire_dtype"
      ],
      "additionalProperties": false
    },
    "injection": {
      "type": "object",
      "properties": {
        "kind": {
          "const": "soft_prefix"
        },
        "placement": {
          "const": "before_rendered_prompt"
        }
      },
      "required": [
        "kind",
        "placement"
      ],
      "additionalProperties": false
    },
    "training": {
      "type": "object",
      "properties": {
        "enabled": {
          "type": "boolean"
        },
        "optimizer": {
          "const": "adamw"
        },
        "learning_rate": {
          "type": "number",
          "exclusiveMinimum": 0
        },
        "weight_decay": {
          "type": "number",
          "minimum": 0
        },
        "max_optimizer_steps": {
          "type": "integer",
          "minimum": 1
        },
        "microbatch_size": {
          "type": "integer",
          "minimum": 1
        },
        "accumulation_microbatches": {
          "type": "integer",
          "minimum": 1
        },
        "loss_normalization": {
          "const": "supervised_token_mean"
        },
        "warmup_fraction": {
          "type": "number",
          "minimum": 0,
          "maximum": 1
        },
        "gradient_clip_norm": {
          "type": "number",
          "exclusiveMinimum": 0
        },
        "eval_every_steps": {
          "type": "integer",
          "minimum": 1
        },
        "freeze_backbones": {
          "const": true
        }
      },
      "required": [
        "enabled",
        "optimizer",
        "learning_rate",
        "weight_decay",
        "max_optimizer_steps",
        "microbatch_size",
        "accumulation_microbatches",
        "loss_normalization",
        "warmup_fraction",
        "gradient_clip_norm",
        "eval_every_steps",
        "freeze_backbones"
      ],
      "additionalProperties": false
    },
    "generation": {
      "type": "object",
      "properties": {
        "strategy": {
          "type": "string",
          "enum": [
            "reference_greedy",
            "cached_greedy"
          ]
        },
        "batch_size": {
          "const": 1
        },
        "max_new_tokens": {
          "type": "integer",
          "minimum": 1
        },
        "do_sample": {
          "const": false
        }
      },
      "required": [
        "strategy",
        "batch_size",
        "max_new_tokens",
        "do_sample"
      ],
      "additionalProperties": false
    },
    "evaluation": {
      "type": "object",
      "properties": {
        "conditions": {
          "type": "array",
          "items": {
            "type": "string",
            "enum": [
              "receiver_only",
              "full_evidence",
              "compact_structured",
              "short_text",
              "constant_prefix",
              "input_blind_bridge",
              "matched_latent",
              "deranged_latent",
              "zero_latent",
              "random_latent",
              "counterfactual"
            ]
          },
          "minItems": 1
        },
        "bootstrap_samples": {
          "type": "integer",
          "minimum": 1
        },
        "bootstrap_unit": {
          "const": "counterfactual_group"
        },
        "fallback": {
          "const": "error"
        }
      },
      "required": [
        "conditions",
        "bootstrap_samples",
        "bootstrap_unit",
        "fallback"
      ],
      "additionalProperties": false
    },
    "artifacts": {
      "type": "object",
      "properties": {
        "root": {
          "type": "string",
          "minLength": 1
        },
        "overwrite": {
          "const": false
        },
        "record_raw_prompts": {
          "type": "boolean"
        },
        "record_raw_latents": {
          "type": "boolean"
        }
      },
      "required": [
        "root",
        "overwrite",
        "record_raw_prompts",
        "record_raw_latents"
      ],
      "additionalProperties": false
    },
    "security": {
      "type": "object",
      "properties": {
        "allow_network": {
          "type": "boolean"
        },
        "allow_remote_code": {
          "const": false
        },
        "allow_public_upload": {
          "const": false
        }
      },
      "required": [
        "allow_network",
        "allow_remote_code",
        "allow_public_upload"
      ],
      "additionalProperties": false
    },
    "resources": {
      "type": "object",
      "properties": {
        "cache_max_bytes": {
          "type": "integer",
          "minimum": 1
        },
        "download_max_bytes": {
          "type": "integer",
          "minimum": 0
        },
        "max_packet_raw_bytes": {
          "type": "integer",
          "minimum": 1
        },
        "max_header_bytes": {
          "type": "integer",
          "minimum": 1
        }
      },
      "required": [
        "cache_max_bytes",
        "download_max_bytes",
        "max_packet_raw_bytes",
        "max_header_bytes"
      ],
      "additionalProperties": false
    }
  },
  "required": [
    "schema_version",
    "example",
    "run",
    "models",
    "data",
    "bridge",
    "injection",
    "training",
    "generation",
    "evaluation",
    "artifacts",
    "security",
    "resources"
  ],
  "additionalProperties": false
}
```


## specs/dataset.schema.json

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:latent-comm:dataset:0.1",
  "title": "Latent Comm dataset planning specification",
  "type": "object",
  "properties": {
    "schema_version": {
      "const": "0.1"
    },
    "example": {
      "type": "boolean"
    },
    "generator_revision": {
      "type": "string",
      "minLength": 1
    },
    "description": {
      "type": "string",
      "minLength": 1
    },
    "samples": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "sample_id": {
            "type": "string",
            "minLength": 1
          },
          "world_id": {
            "type": "string",
            "minLength": 1
          },
          "cf_group_id": {
            "type": "string",
            "minLength": 1
          },
          "variant": {
            "type": "string",
            "enum": [
              "original",
              "counterfactual"
            ]
          },
          "split": {
            "type": "string",
            "enum": [
              "train",
              "validation",
              "test"
            ]
          },
          "question": {
            "type": "string",
            "minLength": 1
          },
          "sender_evidence": {
            "type": "array",
            "items": {
              "type": "string",
              "minLength": 1
            },
            "minItems": 1
          },
          "receiver_evidence": {
            "type": "array",
            "items": {
              "type": "string",
              "minLength": 1
            },
            "minItems": 1
          },
          "answer": {
            "type": "string",
            "minLength": 1
          },
          "accepted_answers": {
            "type": "array",
            "items": {
              "type": "string",
              "minLength": 1
            },
            "minItems": 1
          }
        },
        "required": [
          "sample_id",
          "world_id",
          "cf_group_id",
          "variant",
          "split",
          "question",
          "sender_evidence",
          "receiver_evidence",
          "answer",
          "accepted_answers"
        ],
        "additionalProperties": false
      },
      "minItems": 1
    }
  },
  "required": [
    "schema_version",
    "example",
    "generator_revision",
    "description",
    "samples"
  ],
  "additionalProperties": false
}
```


## specs/packet.schema.json

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:latent-comm:packet:0.1",
  "title": "Latent Comm packet planning specification",
  "type": "object",
  "properties": {
    "protocol_version": {
      "const": "0.1"
    },
    "example": {
      "type": "boolean"
    },
    "kind": {
      "const": "latent"
    },
    "source_model_fingerprint": {
      "type": "string",
      "pattern": "^sha256:[a-f0-9]{64}$"
    },
    "encoder_fingerprint": {
      "type": "string",
      "pattern": "^sha256:[a-f0-9]{64}$"
    },
    "decoder_fingerprint": {
      "type": "string",
      "pattern": "^sha256:[a-f0-9]{64}$"
    },
    "semantic_profile": {
      "type": "string",
      "minLength": 1
    },
    "shape": {
      "type": "array",
      "prefixItems": [
        {
          "type": "integer",
          "minimum": 1,
          "maximum": 256
        },
        {
          "type": "integer",
          "minimum": 1,
          "maximum": 4096
        }
      ],
      "items": false,
      "minItems": 2,
      "maxItems": 2
    },
    "dtype": {
      "type": "string",
      "enum": [
        "float16",
        "bfloat16",
        "float32"
      ]
    },
    "payload_sha256": {
      "type": "string",
      "pattern": "^[a-f0-9]{64}$"
    },
    "payload_nbytes": {
      "type": "integer",
      "minimum": 1
    },
    "raw_tensor_nbytes": {
      "type": "integer",
      "minimum": 1
    },
    "payload_file": {
      "type": "string",
      "pattern": "^[A-Za-z0-9_.-]+\\.safetensors$"
    },
    "request_id": {
      "type": "string",
      "minLength": 1
    }
  },
  "required": [
    "protocol_version",
    "example",
    "kind",
    "source_model_fingerprint",
    "encoder_fingerprint",
    "decoder_fingerprint",
    "semantic_profile",
    "shape",
    "dtype",
    "payload_sha256",
    "payload_nbytes",
    "raw_tensor_nbytes",
    "payload_file",
    "request_id"
  ],
  "additionalProperties": false
}
```


## specs/prediction.schema.json

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:latent-comm:prediction:0.1",
  "title": "Latent Comm prediction planning specification",
  "type": "object",
  "properties": {
    "schema_version": {
      "const": "0.1"
    },
    "example": {
      "type": "boolean"
    },
    "run_id": {
      "type": "string",
      "minLength": 1
    },
    "sample_id": {
      "type": "string",
      "minLength": 1
    },
    "cf_group_id": {
      "type": "string",
      "minLength": 1
    },
    "condition": {
      "type": "string",
      "minLength": 1
    },
    "status": {
      "type": "string",
      "enum": [
        "not_run",
        "success",
        "failed"
      ]
    },
    "requested_channel": {
      "type": "string",
      "enum": [
        "latent",
        "text",
        "structured",
        "none"
      ]
    },
    "actual_channel": {
      "anyOf": [
        {
          "type": "string",
          "enum": [
            "latent",
            "text",
            "structured",
            "none"
          ]
        },
        {
          "type": "null"
        }
      ]
    },
    "prediction": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "correct": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ]
    },
    "stop_reason": {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "null"
        }
      ]
    },
    "latency_ms": {
      "anyOf": [
        {
          "type": "number",
          "minimum": 0
        },
        {
          "type": "null"
        }
      ]
    },
    "total_application_bytes": {
      "anyOf": [
        {
          "type": "integer",
          "minimum": 0
        },
        {
          "type": "null"
        }
      ]
    },
    "error_code": {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "schema_version",
    "example",
    "run_id",
    "sample_id",
    "cf_group_id",
    "condition",
    "status",
    "requested_channel",
    "actual_channel",
    "prediction",
    "correct",
    "stop_reason",
    "latency_ms",
    "total_application_bytes",
    "error_code"
  ],
  "additionalProperties": false
}
```


## specs/run.schema.json

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:latent-comm:run:0.1",
  "title": "Latent Comm run planning specification",
  "type": "object",
  "properties": {
    "schema_version": {
      "const": "0.1"
    },
    "example": {
      "type": "boolean"
    },
    "run_id": {
      "type": "string",
      "minLength": 1
    },
    "status": {
      "type": "string",
      "enum": [
        "planned",
        "validated",
        "prepared",
        "training",
        "validating",
        "checkpointed",
        "completed",
        "failed",
        "interrupted"
      ]
    },
    "evidence_kind": {
      "type": "string",
      "enum": [
        "none",
        "toy",
        "random_model",
        "pretrained_smoke",
        "semantic",
        "performance"
      ]
    },
    "config_sha256": {
      "anyOf": [
        {
          "type": "string",
          "pattern": "^[a-f0-9]{64}$"
        },
        {
          "type": "null"
        }
      ]
    },
    "code_commit": {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "null"
        }
      ]
    },
    "dirty": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ]
    },
    "environment_path": {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "null"
        }
      ]
    },
    "checkpoint_path": {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "null"
        }
      ]
    },
    "scheduled_examples": {
      "type": "integer",
      "minimum": 0
    },
    "completed_examples": {
      "type": "integer",
      "minimum": 0
    },
    "failed_examples": {
      "type": "integer",
      "minimum": 0
    },
    "metrics_path": {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "null"
        }
      ]
    },
    "limitations": {
      "type": "array",
      "items": {
        "type": "string",
        "minLength": 1
      },
      "minItems": 1
    }
  },
  "required": [
    "schema_version",
    "example",
    "run_id",
    "status",
    "evidence_kind",
    "config_sha256",
    "code_commit",
    "dirty",
    "environment_path",
    "checkpoint_path",
    "scheduled_examples",
    "completed_examples",
    "failed_examples",
    "metrics_path",
    "limitations"
  ],
  "additionalProperties": false
}
```


## examples/compatibility.example.json

```json
{
  "schema_version": "0.1",
  "example": true,
  "pair_id": "example-unverified-qwen-self",
  "sender_model_id": "Qwen/Qwen3-0.6B",
  "sender_revision": "__PIN_REVISION__",
  "receiver_model_id": "Qwen/Qwen3-0.6B",
  "receiver_revision": "__PIN_REVISION__",
  "semantic_profile": "example/private-lookup/prefix-v1",
  "capabilities": {
    "load": {
      "status": "not_run",
      "evidence_paths": [],
      "note": "本计划包未进行模型验证。"
    },
    "extract": {
      "status": "not_run",
      "evidence_paths": [],
      "note": "本计划包未进行模型验证。"
    },
    "inject": {
      "status": "not_run",
      "evidence_paths": [],
      "note": "本计划包未进行模型验证。"
    },
    "input_gradient": {
      "status": "not_run",
      "evidence_paths": [],
      "note": "本计划包未进行模型验证。"
    },
    "semantic": {
      "status": "not_run",
      "evidence_paths": [],
      "note": "本计划包未进行模型验证。"
    },
    "cost": {
      "status": "not_run",
      "evidence_paths": [],
      "note": "本计划包未进行模型验证。"
    }
  },
  "scope_note": "全部未验证；不是支持声明。"
}
```


## examples/config.cpu_contract.example.json

```json
{
  "schema_version": "0.1",
  "example": true,
  "run": {
    "id": "example-toy-contract",
    "seed": 17,
    "mode": "contract_test",
    "description": "仅为配置规格示例；尚无实现或模型验证。真实执行必须替换占位并经过 probe。"
  },
  "models": {
    "sender": {
      "backend": "toy",
      "model_id": "toy/local-random-no-semantic-claim",
      "revision": "local-toy-v1",
      "dtype": "float32",
      "device": "cpu",
      "trust_remote_code": false,
      "template_kwargs": {}
    },
    "receiver": {
      "backend": "toy",
      "model_id": "toy/local-random-no-semantic-claim",
      "revision": "local-toy-v1",
      "dtype": "float32",
      "device": "cpu",
      "trust_remote_code": false,
      "template_kwargs": {}
    },
    "share_weights": true
  },
  "data": {
    "task": "private_lookup",
    "train_groups": 4,
    "validation_groups": 2,
    "test_groups": 2,
    "candidates": 4,
    "split_unit": "counterfactual_group",
    "max_source_tokens": 64,
    "max_receiver_tokens": 64
  },
  "bridge": {
    "encoder": "query_pool",
    "slots": 4,
    "latent_dim": 16,
    "attention_heads": 4,
    "normalization": "layer_norm",
    "channel": "local_differentiable",
    "wire_dtype": "float32"
  },
  "injection": {
    "kind": "soft_prefix",
    "placement": "before_rendered_prompt"
  },
  "training": {
    "enabled": true,
    "optimizer": "adamw",
    "learning_rate": 0.0001,
    "weight_decay": 0.01,
    "max_optimizer_steps": 2,
    "microbatch_size": 1,
    "accumulation_microbatches": 2,
    "loss_normalization": "supervised_token_mean",
    "warmup_fraction": 0.05,
    "gradient_clip_norm": 1.0,
    "eval_every_steps": 1,
    "freeze_backbones": true
  },
  "generation": {
    "strategy": "reference_greedy",
    "batch_size": 1,
    "max_new_tokens": 8,
    "do_sample": false
  },
  "evaluation": {
    "conditions": [
      "receiver_only",
      "full_evidence",
      "compact_structured",
      "constant_prefix",
      "matched_latent",
      "deranged_latent",
      "counterfactual"
    ],
    "bootstrap_samples": 50,
    "bootstrap_unit": "counterfactual_group",
    "fallback": "error"
  },
  "artifacts": {
    "root": "./runs/example-toy",
    "overwrite": false,
    "record_raw_prompts": false,
    "record_raw_latents": false
  },
  "security": {
    "allow_network": false,
    "allow_remote_code": false,
    "allow_public_upload": false
  },
  "resources": {
    "cache_max_bytes": 104857600,
    "download_max_bytes": 0,
    "max_packet_raw_bytes": 1048576,
    "max_header_bytes": 16384
  }
}
```


## examples/config.qwen_bridge.example.json

```json
{
  "schema_version": "0.1",
  "example": true,
  "run": {
    "id": "example-qwen-bridge",
    "seed": 17,
    "mode": "train",
    "description": "仅为配置规格示例；尚无实现或模型验证。真实执行必须替换占位并经过 probe。"
  },
  "models": {
    "sender": {
      "backend": "hf_causal",
      "model_id": "Qwen/Qwen3-0.6B",
      "revision": "__PIN_REVISION__",
      "dtype": "bfloat16",
      "device": "cuda:0",
      "trust_remote_code": false,
      "template_kwargs": {
        "enable_thinking": false
      }
    },
    "receiver": {
      "backend": "hf_causal",
      "model_id": "Qwen/Qwen3-0.6B",
      "revision": "__PIN_REVISION__",
      "dtype": "bfloat16",
      "device": "cuda:0",
      "trust_remote_code": false,
      "template_kwargs": {
        "enable_thinking": false
      }
    },
    "share_weights": true
  },
  "data": {
    "task": "private_lookup",
    "train_groups": 5000,
    "validation_groups": 500,
    "test_groups": 1000,
    "candidates": 8,
    "split_unit": "counterfactual_group",
    "max_source_tokens": 512,
    "max_receiver_tokens": 256
  },
  "bridge": {
    "encoder": "query_pool",
    "slots": 16,
    "latent_dim": 256,
    "attention_heads": 4,
    "normalization": "layer_norm",
    "channel": "local_differentiable",
    "wire_dtype": "float16"
  },
  "injection": {
    "kind": "soft_prefix",
    "placement": "before_rendered_prompt"
  },
  "training": {
    "enabled": true,
    "optimizer": "adamw",
    "learning_rate": 0.0001,
    "weight_decay": 0.01,
    "max_optimizer_steps": 1000,
    "microbatch_size": 1,
    "accumulation_microbatches": 16,
    "loss_normalization": "supervised_token_mean",
    "warmup_fraction": 0.05,
    "gradient_clip_norm": 1.0,
    "eval_every_steps": 100,
    "freeze_backbones": true
  },
  "generation": {
    "strategy": "reference_greedy",
    "batch_size": 1,
    "max_new_tokens": 32,
    "do_sample": false
  },
  "evaluation": {
    "conditions": [
      "receiver_only",
      "full_evidence",
      "compact_structured",
      "constant_prefix",
      "matched_latent",
      "deranged_latent",
      "counterfactual"
    ],
    "bootstrap_samples": 2000,
    "bootstrap_unit": "counterfactual_group",
    "fallback": "error"
  },
  "artifacts": {
    "root": "./runs/example-qwen",
    "overwrite": false,
    "record_raw_prompts": false,
    "record_raw_latents": false
  },
  "security": {
    "allow_network": false,
    "allow_remote_code": false,
    "allow_public_upload": false
  },
  "resources": {
    "cache_max_bytes": 10737418240,
    "download_max_bytes": 0,
    "max_packet_raw_bytes": 1048576,
    "max_header_bytes": 16384
  }
}
```


## examples/dataset.example.json

```json
{
  "schema_version": "0.1",
  "example": true,
  "generator_revision": "manual-schema-fixture-v1",
  "description": "人工构造的两条结构样例，不是已生成训练集或实验结果。",
  "samples": [
    {
      "sample_id": "example-original",
      "world_id": "example-world-a",
      "cf_group_id": "example-cf-group-1",
      "variant": "original",
      "split": "train",
      "question": "What value corresponds to Aster?",
      "sender_evidence": [
        "Aster -> K7",
        "Birch -> K2"
      ],
      "receiver_evidence": [
        "K7 -> mango",
        "K2 -> cedar"
      ],
      "answer": "mango",
      "accepted_answers": [
        "mango"
      ]
    },
    {
      "sample_id": "example-counterfactual",
      "world_id": "example-world-b",
      "cf_group_id": "example-cf-group-1",
      "variant": "counterfactual",
      "split": "train",
      "question": "What value corresponds to Aster?",
      "sender_evidence": [
        "Aster -> K2",
        "Birch -> K7"
      ],
      "receiver_evidence": [
        "K7 -> mango",
        "K2 -> cedar"
      ],
      "answer": "cedar",
      "accepted_answers": [
        "cedar"
      ]
    }
  ]
}
```


## examples/message_header.example.json

```json
{
  "protocol_version": "0.1",
  "example": true,
  "kind": "latent",
  "source_model_fingerprint": "sha256:ca81651423a303028560a287d49017cd509211c935e202a7323ac938f273fd81",
  "encoder_fingerprint": "sha256:44e92c26bdc5629fb43b1113911dcd92c1bb8d2c77ea92d071b6d5a225fdf5f1",
  "decoder_fingerprint": "sha256:6e6759662081cd74b20158671b194fdb8f18709935c974a5fc0fed61d9780a73",
  "semantic_profile": "fixture/zeros/no-semantic-claim",
  "shape": [
    16,
    256
  ],
  "dtype": "float16",
  "payload_sha256": "79c8d9099fb8905d08778f11bc85df6498677d397b701dbd36c20445fad748eb",
  "payload_nbytes": 8272,
  "raw_tensor_nbytes": 8192,
  "payload_file": "message_payload.safetensors",
  "request_id": "fixture-0001"
}
```


## examples/prediction.example.json

```json
{
  "schema_version": "0.1",
  "example": true,
  "run_id": "example-planned-only",
  "sample_id": "example-original",
  "cf_group_id": "example-cf-group-1",
  "condition": "matched_latent",
  "status": "not_run",
  "requested_channel": "latent",
  "actual_channel": null,
  "prediction": null,
  "correct": null,
  "stop_reason": null,
  "latency_ms": null,
  "total_application_bytes": null,
  "error_code": null
}
```


## examples/run.example.json

```json
{
  "schema_version": "0.1",
  "example": true,
  "run_id": "example-planned-only",
  "status": "planned",
  "evidence_kind": "none",
  "config_sha256": null,
  "code_commit": null,
  "dirty": null,
  "environment_path": null,
  "checkpoint_path": null,
  "scheduled_examples": 0,
  "completed_examples": 0,
  "failed_examples": 0,
  "metrics_path": null,
  "limitations": [
    "未执行训练、推理或性能实验。",
    "仅说明 run manifest 结构。"
  ]
}
```
