# 12｜CLI、配置与用户流程

所有命令是拟实现规范。本计划包不提供已完成的 `lcomm` 可执行程序；不要把这里的命令原样运行并误认为已经安装框架。

## 12.1 CLI 设计原则

命令行是 Python API 的薄封装。相同逻辑不复制两份。默认无网络、无后台服务、无遥测；需要权重下载时明确启用并展示来源、revision、目录与预算。

stdout 用于可解析结果或简洁摘要，stderr 用于进度和错误。`--json` 输出稳定结构；日志不混入 JSON。退出码与稳定错误码共同使用，未支持能力不得返回 0。

## 12.2 命令表

| 命令 | 输入 | 输出/行为 | 约束 |
|---|---|---|---|
| `lcomm doctor` | 可选环境路径 | 环境诊断 | 默认不下载、不修改系统 |
| `lcomm config validate FILE` | JSON 配置 | schema/跨字段错误 | 不加载模型 |
| `lcomm data build FILE` | 生成配置 | world/samples/manifest | 合成数据、确定性 seed |
| `lcomm data validate PATH` | 数据目录 | 唯一性、split、oracle 检查 | 不训练 |
| `lcomm probe FILE` | 模型配置 | capability record | 显式加载授权 |
| `lcomm cache build FILE` | sender+data | H shards | 校验预算与 split |
| `lcomm train FILE` | resolved 配置 | checkpoints、训练日志 | 必须明确 steps 上限 |
| `lcomm evaluate FILE` | checkpoint+split | predictions、质量结果 | 不更新参数 |
| `lcomm audit FILE` | 固定检查点 | 替换/反事实结果 | donor 规则固定 |
| `lcomm benchmark FILE` | 基线/成本配置 | 计时/载荷/显存 | warmup/cold 条件明确 |
| `lcomm report RUN_DIR` | 已生成结果 | Markdown、CSV | 只读重算 |
| `lcomm export RUN_DIR` | 适配器/manifest | 发布包 | 默认不含原始私有数据 |
| `lcomm verify BUNDLE` | 本地发布包 | hash/schema/范围验证 | 不执行包内代码 |

首版不用复杂的动态 sweep DSL。用显式配置列表逐一跑，runner 只负责预算和日志，避免隐藏实验变化。

## 12.3 三条快速开始

### A：无需下载模型的开发者路径

安装包与测试依赖 → doctor → toy_cpu 配置校验 → 构造 8 组数据 → toy/tiny-random 前向与梯度 → 生成一份标注“非真实模型”的报告。

用途：验证安装和代码路径。不宣传成潜通信成功演示。

### B：真实模型低资源路径

固定权重 revision → 下载到独立模型目录 → probe → 合成数据/全文基线 → 同权重双角色单步训练 → 32 样本诊断 → 保存/重载 → 小验证集自由生成和消息替换。

任何一步失败就输出具体故障与已完成状态，不能继续伪造后续结果。

### C：复现公开实验

获取 release/lock/config/checkpoint/dataset generator → verify → 重建数据 → 重跑 evaluate/audit → 从 predictions 重算主表 → 比较容差与已知非确定性。

## 12.4 配置分块

`schema_version`、`run`、`models`、`data`、`bridge`、`injection`、`training`、`generation`、`evaluation`、`artifacts`、`security`、`resources`。

所有字段有默认与类型，重要实验参数都写入 resolved_config。路径相对 config 文件解析而非当前工作目录，消除从不同终端启动导致的行为变化。

配置文件严格拒绝重复 JSON key。使用 schema_version 管理迁移；旧配置转换输出新文件并记录变化，不能原地改原配置后继续装作同一次实验。

## 12.5 用户提示与输出

训练前摘要显示：模型配对、revision、state spec、message shape/dtype、参数量、训练/验证样本量、估计缓存空间与实际磁盘、steps、输出路径、当前证据等级。

这不是成本保证。资源估算要写 `estimate`；第一次实测后再产生 `measured`。

错误应给可执行方向，例如“配置要求 BF16，但当前 probe 未确认支持，请选用经验证的 FP32 配置”，而不是自动切精度。

## 12.6 Windows/本机约束

路径使用 pathlib；包含中文、空格的路径要有测试；shell 示例分别给 PowerShell 与 Bash，不假定 `rm -rf`、`export` 或反斜线规则通用。

先支持 Windows CPU 合约测试；GPU 参考环境可以选择 Linux/WSL2，但仅在真实测试后声明支持。不得要求 Agent 自动改分页文件、装驱动、关闭安全软件或结束现有 9B 服务。

## 12.7 API 示例的诚实性

README 中所有代码块都归类为：已测试命令、概念示例、未来 API。0.1.0 主要 quickstart 必须是 CI/维护者实际执行过的已测试命令；未来 API 不放在“现在安装即用”的区域。

导入 `latent_comm` 不应强制加载 Transformers；轻量 schema/report 子命令在无 GPU 环境可运行。大型依赖采用明确 extra，缺少时提示所需安装项，不偷偷 pip install。
