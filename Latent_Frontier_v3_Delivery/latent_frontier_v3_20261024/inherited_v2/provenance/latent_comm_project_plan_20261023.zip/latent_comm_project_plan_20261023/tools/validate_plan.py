"""Validate this planning package, not the proposed ML framework.

Offline dependencies: jsonschema, numpy, safetensors. No model download,
training, GPU benchmark, or external network request is performed.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.metadata
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parents[1]
try:
    import numpy as np
    from jsonschema import Draft202012Validator, ValidationError
    from safetensors.numpy import load_file
except ImportError as exc:
    print(f"Missing optional plan-validation dependency: {exc}", file=sys.stderr)
    raise SystemExit(2)

checks: list[dict[str, Any]] = []

def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)

def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result

def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=unique_object)

def check(name: str, fn: Callable[[], None]) -> None:
    try:
        fn()
        checks.append({'name': name, 'status': 'pass'})
    except Exception as exc:
        checks.append({'name': name, 'status': 'fail', 'error': str(exc)})

def must_reject(fn: Callable[[], None]) -> None:
    try:
        fn()
    except (ValidationError, ValueError):
        return
    raise AssertionError('Invalid fixture was not rejected')

schemas = {p.stem.replace('.schema',''): read_json(p) for p in (ROOT/'specs').glob('*.schema.json')}
for name, schema in schemas.items():
    check(f'schema_valid:{name}', lambda s=schema: Draft202012Validator.check_schema(s))

mapping = {
    'config.cpu_contract.example.json': 'config',
    'config.qwen_bridge.example.json': 'config',
    'message_header.example.json': 'packet',
    'compatibility.example.json': 'compatibility',
    'dataset.example.json': 'dataset',
    'run.example.json': 'run',
    'prediction.example.json': 'prediction',
}
examples = {name: read_json(ROOT/'examples'/name) for name in mapping}
for name, kind in mapping.items():
    check(f'example_schema:{name}', lambda n=name,k=kind: Draft202012Validator(schemas[k]).validate(examples[n]))


def config_semantics(config: dict[str, Any], for_execution: bool = False) -> None:
    bridge = config['bridge']
    if bridge['latent_dim'] % bridge['attention_heads'] != 0:
        raise ValueError('latent_dim must be divisible by attention_heads')
    if config['training']['enabled'] and bridge['channel'] != 'local_differentiable':
        raise ValueError('Training requires a differentiable local message path')
    itemsize = {'float16': 2, 'bfloat16': 2, 'float32': 4}[bridge['wire_dtype']]
    if bridge['slots'] * bridge['latent_dim'] * itemsize > config['resources']['max_packet_raw_bytes']:
        raise ValueError('Raw packet budget exceeded')
    if config['models']['share_weights'] and config['models']['sender'] != config['models']['receiver']:
        raise ValueError('Shared weights require matching endpoint specifications')
    if for_execution:
        if config['example']:
            raise ValueError('Example configurations are not executable experiments')
        for endpoint in ('sender','receiver'):
            if '__PIN_' in config['models'][endpoint]['revision']:
                raise ValueError('Unresolved model revision')

for name in ('config.cpu_contract.example.json','config.qwen_bridge.example.json'):
    check(f'example_semantics:{name}',lambda n=name: config_semantics(examples[n]))
    check(f'example_execution_blocked:{name}',lambda n=name:must_reject(lambda:config_semantics(examples[n],True)))

mutations: list[tuple[str,str,Callable[[dict[str,Any]],None]]] = [
    ('config_unknown_field','config',lambda x:x.update({'invented_success':True})),
    ('negative_slots','config',lambda x:x['bridge'].update({'slots':-1})),
    ('wrong_lr_type','config',lambda x:x['training'].update({'learning_rate':'fast'})),
    ('missing_receiver','config',lambda x:x['models'].pop('receiver')),
    ('unknown_protocol','packet',lambda x:x.update({'protocol_version':'9.9'})),
    ('packet_three_dimensions','packet',lambda x:x.update({'shape':[1,16,256]})),
    ('unregistered_dtype','packet',lambda x:x.update({'dtype':'python-object'})),
    ('target_in_packet','packet',lambda x:x.update({'target':'mango'})),
    ('path_traversal_payload','packet',lambda x:x.update({'payload_file':'../outside.safetensors'})),
]
for name,kind,mutation in mutations:
    original = examples['config.qwen_bridge.example.json' if kind=='config' else 'message_header.example.json']
    modified = copy.deepcopy(original); mutation(modified)
    check(f'reject:{name}',lambda x=modified,k=kind:must_reject(lambda:Draft202012Validator(schemas[k]).validate(x)))

for name,modify in [
    ('training_serialized_channel',lambda x:x['bridge'].update({'channel':'local_packet'})),
    ('incompatible_shared_weights',lambda x:x['models']['receiver'].update({'model_id':'different-model'})),
    ('packet_budget',lambda x:x['resources'].update({'max_packet_raw_bytes':1})),
]:
    bad=copy.deepcopy(examples['config.qwen_bridge.example.json']);modify(bad)
    check(f'reject:{name}',lambda x=bad:must_reject(lambda:config_semantics(x)))

check('reject:duplicate_json_keys',lambda:must_reject(lambda:json.loads('{"x":1,"x":2}',object_pairs_hook=unique_object)))

def validate_payload() -> None:
    h=examples['message_header.example.json']
    p=ROOT/'examples'/h['payload_file']
    data=p.read_bytes()
    require(len(data)==h['payload_nbytes'],'payload byte count mismatch')
    require(hashlib.sha256(data).hexdigest()==h['payload_sha256'],'payload hash mismatch')
    loaded=load_file(str(p))
    require(set(loaded)=={'latent'},'unexpected payload tensor keys')
    v=loaded['latent']
    require(list(v.shape)==h['shape'],'payload shape mismatch')
    require(v.dtype==np.float16,'payload dtype mismatch')
    require(v.nbytes==h['raw_tensor_nbytes'],'raw byte count mismatch')
    require(bool(np.isfinite(v).all()),'payload contains nonfinite values')
    require(bool((v==0).all()),'fixture must remain all-zero, not a trained-message claim')
check('packet_fixture_actual_roundtrip',validate_payload)

backlog=read_json(ROOT/'tasks/backlog.json')
tasks=backlog['tasks']

def validate_tasks() -> None:
    ids=[t['id'] for t in tasks]
    require(len(ids)==len(set(ids))==39,'expected 39 unique work packages')
    graph={t['id']:t['depends_on'] for t in tasks}
    active:set[str]=set();done:set[str]=set()
    def visit(node:str) -> None:
        require(node in graph,f'missing dependency: {node}')
        require(node not in active,f'cycle at {node}')
        if node in done:return
        active.add(node)
        for dep in graph[node]:visit(dep)
        active.remove(node);done.add(node)
    for t in tasks:
        require(t['status']=='planned','planning package must not claim task completion')
        require(bool(t['allowed_paths']) and bool(t['steps']) and bool(t['acceptance']),'incomplete task card')
        visit(t['id'])
check('work_packages_complete_acyclic',validate_tasks)


def validate_dataset() -> None:
    a,b=examples['dataset.example.json']['samples']
    require(a['question']==b['question'] and a['receiver_evidence']==b['receiver_evidence'],'counterfactual must preserve question and receiver evidence')
    require(a['answer']!=b['answer'],'counterfactual answer must change')
    require(a['split']==b['split'] and a['cf_group_id']==b['cf_group_id'],'counterfactual group must remain in one split')
    for x in (a,b):
        send=dict(line.split(' -> ') for line in x['sender_evidence'])
        recv=dict(line.split(' -> ') for line in x['receiver_evidence'])
        require(recv[send['Aster']]==x['answer'],'example oracle mismatch')
check('dataset_fixture_oracle_and_counterfactual',validate_dataset)

def validate_honesty() -> None:
    record=examples['compatibility.example.json']
    require(all(x['status']=='not_run' and x['evidence_paths']==[] for x in record['capabilities'].values()),'unverified model capabilities must remain not_run')
    pred=examples['prediction.example.json']
    require(pred['status']=='not_run' and all(pred[k] is None for k in ('prediction','correct','latency_ms','total_application_bytes','actual_channel')),'unmeasured predictions must stay null')
    run=examples['run.example.json']
    require(run['status']=='planned' and run['evidence_kind']=='none','run example must not imply executed experiment')
check('examples_do_not_claim_model_results',validate_honesty)

def validate_documents() -> None:
    docs=list((ROOT/'docs').glob('*.md'))
    require(len(docs)==22,'expected 22 specification chapters')
    body=(ROOT/'docs/13_测试矩阵与CI.md').read_text()
    test_ids=set(re.findall(r'^\| T(\d{2})\s*\|',body,re.M))
    require(test_ids=={f'{i:02d}' for i in range(1,61)},'test IDs must be exactly T01..T60')
    valid_tasks={t['id'] for t in tasks}
    valid_sources={f'S{i:02d}' for i in range(1,16)}
    for p in ROOT.rglob('*.md'):
        text=p.read_text(encoding='utf-8')
        require(len(re.findall(r'^```',text,re.M))%2==0,f'unbalanced fenced code: {p.relative_to(ROOT)}')
        for source in re.findall(r'\[(S\d{2})\]',text):
            require(source in valid_sources,f'unknown source {source}')
        for task in re.findall(r'\bW\d{2}\b',text):
            require(task in valid_tasks,f'unknown task {task}')
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',target) or target.startswith('#'):
                continue
            filename=target.split('#',1)[0]
            if filename:
                require((p.parent/filename).exists(),f'broken local link {p.relative_to(ROOT)} -> {filename}')
check('documents_references_fences_and_links',validate_documents)

report={'kind':'planning_package_validation_only','checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'not_performed':['framework implementation tests','pretrained-model training','GPU performance tests','semantic-communication experiments','GitHub publication'],
        'dependencies':{name:importlib.metadata.version(name) for name in ['jsonschema','numpy','safetensors']},
        'checks':checks,'passed':sum(c['status']=='pass' for c in checks),'failed':sum(c['status']=='fail' for c in checks)}
(ROOT/'VALIDATION_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ('kind','passed','failed')},ensure_ascii=False))
for c in checks:
    if c['status']=='fail': print(c,file=sys.stderr)
raise SystemExit(1 if report['failed'] else 0)
