"""Validate THIS execution-plan package, not a model or the future target repository."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import struct
from urllib.parse import unquote
from typing import Any
from planlib import PlanError, read_json, sha256_file, topological_order, inside, validate_metric_evidence
from no_model_gate import validate_policy


def verify_manifest(root: Path) -> int:
    manifest = read_json(root / "MANIFEST.json")
    listed = set()
    for item in manifest["files"]:
        name = item["path"]
        if name in listed:
            raise PlanError("Duplicate manifest path")
        listed.add(name)
        path = inside(root, name)
        if not path.is_file() or path.is_symlink():
            raise PlanError(f"Missing/unsafe manifest file {name}")
        if path.stat().st_size != item["bytes"] or sha256_file(path) != item["sha256"]:
            raise PlanError(f"Integrity mismatch: {name}")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()
              and "__pycache__" not in p.parts and p.name not in {"MANIFEST.json"}}
    if actual != listed:
        raise PlanError(f"Manifest coverage mismatch: missing={actual-listed}, extra={listed-actual}")
    return len(listed)


def validate(root: Path, integrity: bool = False) -> dict[str, Any]:
    root = root.resolve()
    checks: list[dict[str, Any]] = []
    def ok(name: str, detail: Any) -> None:
        checks.append({"check": name, "status": "passed", "detail": detail})
    # Every JSON is parsed strictly, except historical source archives.
    parsed = []
    for path in root.rglob("*.json"):
        if "source_archives" in path.parts:
            continue
        read_json(path)
        parsed.append(path.relative_to(root).as_posix())
    ok("strict_json", len(parsed))
    validate_policy(read_json(root / "configs/execution_policy.json"))
    ok("policy_frozen", "all model actions, public writes and new spend disabled")
    graph = read_json(root / "specs/task_graph.json")
    order = topological_order(graph["tasks"])
    task_by = {x["id"]: x for x in graph["tasks"]}
    ok("task_graph_acyclic", len(order))
    tests = read_json(root / "specs/test_catalog.json")["tests"]
    tids = [t["id"] for t in tests]
    if len(tids) != len(set(tids)):
        raise PlanError("Duplicate planned test ID")
    test_by = {t["id"]: t for t in tests}
    reqs = read_json(root / "specs/requirements.json")["requirements"]
    req_by = {r["id"]: r for r in reqs}
    if len(req_by) != len(reqs):
        raise PlanError("Duplicate requirement")
    for task in graph["tasks"]:
        if task["model_execution_allowed"] is not False or task["status"] != "planned":
            raise PlanError("Plan task implies actual execution or model permission")
        for file in task["documents"] + [task["prompt"], task["card"]]:
            if not inside(root, file).is_file():
                raise PlanError(f"Missing task document {file}")
        for tid in task["test_ids"]:
            if tid not in test_by or test_by[tid]["task_id"] != task["id"]:
                raise PlanError(f"Broken test mapping: {tid}")
        for req in task["requirements"]:
            if req not in req_by or task["id"] not in req_by[req]["tasks"]:
                raise PlanError("Broken requirement back-reference")
    for test in tests:
        if test["task_id"] not in task_by or test["id"] not in task_by[test["task_id"]]["test_ids"]:
            raise PlanError("Orphan planned test")
        if test["status"] != "planned" or test["model_execution_allowed"] is not False:
            raise PlanError("Planned tests cannot be reported as passed")
    for req in reqs:
        if not req["tasks"]:
            raise PlanError("Uncovered requirement")
        for task in req["tasks"]:
            if task not in task_by or req["id"] not in task_by[task]["requirements"]:
                raise PlanError("Requirement mapping is not reciprocal")
    ok("traceability", {"requirements":len(reqs), "tasks":len(order), "planned_checks":len(tests)})
    cross = read_json(root / "specs/source_wbs_crosswalk.json")["mappings"]
    if len(cross) != 39 or len({x["old_id"] for x in cross}) != 39:
        raise PlanError("Original 39 tasks not fully mapped")
    for item in cross:
        if any(x not in task_by for x in item["new_tasks"]):
            raise PlanError("Invalid source WBS mapping")
    ok("historical_task_mapping",len(cross))
    # Full standard schema validation, with explicit dependency failure rather than skip.
    try:
        from jsonschema import Draft202012Validator
    except ImportError as exc:
        raise PlanError("Install the plan-tools jsonschema dependency; schema checks were NOT run") from exc
    for s in (root / "specs").glob("*.schema.json"):
        Draft202012Validator.check_schema(read_json(s))
    pairs = read_json(root / "specs/schema_examples.json")["pairs"]
    for pair in pairs:
        validator = Draft202012Validator(read_json(inside(root,pair["schema"])))
        validator.validate(read_json(inside(root,pair["example"])))
    media = read_json(root / "media/content_manifest.json")
    mv = Draft202012Validator(read_json(root / "specs/media_asset.schema.json"))
    for asset in media["assets"]:
        mv.validate(asset)
        if asset["rendered"] or asset["status"] != "planned":
            raise PlanError("This plan must not claim media rendering already happened")
    ok("schemas_and_examples",{"schemas":len(list((root/'specs').glob('*.schema.json'))),"examples":len(pairs),"planned_media":len(media['assets'])})
    fixture = read_json(root / "configs/fixture_pipeline.json")
    future = read_json(root / "configs/future_model_design_LOCKED.json")
    if future["run"]["execute"] is not False or future["run"]["profile"] != "future_model":
        raise PlanError("Future model configuration must remain locked")
    for conf in (fixture,future):
        if any(k > conf["bridge"]["max_slots"] for k in conf["training"]["budget_slots"]):
            raise PlanError("Budget slots exceed maximum")
    auth=read_json(root/'configs/model_authorization_LOCKED.json')
    if auth['authorized'] is not False or auth['allowed_actions'] or auth['max_steps'] != 0:
        raise PlanError("Model authorization was fabricated")
    validate_metric_evidence(read_json(root/'templates/run_manifest.example.json'))
    ok("status_and_future_lock", "no fabricated empirical metrics or authorization")
    # Source bytes preserved.
    for source in read_json(root/'evidence/input_manifest.json')['sources']:
        path=inside(root,'source_archives/'+source['file'])
        if path.stat().st_size != source['bytes'] or sha256_file(path) != source['sha256']:
            raise PlanError("Historical input differs from supplied bytes")
    ok("original_archives_preserved",3)
    # Tiny actual tensor container; no model objects or computations.
    header=read_json(root/'templates/packet_fixture/header.json')
    payload=root/'templates/packet_fixture/payload.safetensors'
    data=payload.read_bytes()
    if len(data)!=header['payload_nbytes'] or sha256_file(payload)!=header['payload_sha256']:
        raise PlanError("Packet fixture size/hash mismatch")
    if len(data)<8: raise PlanError('Invalid safetensors fixture')
    n=struct.unpack('<Q',data[:8])[0]
    from planlib import strict_json_text
    tensor_meta=strict_json_text(data[8:8+n].decode('utf-8'))
    if tensor_meta['latent']['shape']!=header['shape'] or tensor_meta['latent']['dtype']!='F16':
        raise PlanError('Tensor fixture metadata mismatch')
    if len(data)-(8+n) != header['raw_tensor_nbytes']:
        raise PlanError('Tensor fixture raw bytes mismatch')
    ok('packet_fixture_integrity', {'raw_tensor_bytes':header['raw_tensor_nbytes'],'container_bytes':len(data)})
    # Check actual relative Markdown links, excluding historical material and fenced code.
    link_count=0
    for md in root.rglob('*.md'):
        if 'source_archives' in md.parts: continue
        text=re.sub(r'```[\s\S]*?```','',md.read_text(encoding='utf-8'))
        for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)',text):
            if target.startswith(('https://','http://','mailto:','#','sandbox:')):continue
            rel=unquote(target.split('#',1)[0])
            path=(md.parent/rel).resolve()
            if not path.is_relative_to(root) or not path.exists():
                raise PlanError(f'Broken/escaping Markdown link: {md.relative_to(root)} -> {target}')
            link_count+=1
    ok('local_markdown_links',link_count)
    source_ids={x['id'] for x in read_json(root/'evidence/source_register.json')['sources']}
    for md in (root/'docs').glob('*.md'):
        for sid in re.findall(r'R\d{2}',md.read_text(encoding='utf-8')):
            if sid not in source_ids:raise PlanError('Unknown source reference '+sid)
    ok('source_reference_ids',len(source_ids))
    if integrity:ok('manifest_integrity',verify_manifest(root))
    return {'status':'passed','scope':'PLAN_PACKAGE_ONLY_NOT_TARGET_LIBRARY','model_executed':False,
            'target_library_status':'not_implemented_in_this_plan_package','checks':checks,
            'counts':{'documents':len(list((root/'docs').glob('*.md'))),'prompts':len(list((root/'prompts').glob('*.md'))),'task_cards':len(graph['tasks']),'planned_acceptance_cases':len(tests),'schemas':len(list((root/'specs').glob('*.schema.json')))}}

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--integrity',action='store_true')
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    try:
        result=validate(args.root,args.integrity)
    except Exception as exc:
        result={'status':'failed','scope':'PLAN_PACKAGE_ONLY','error_type':type(exc).__name__,'error':str(exc),'model_executed':False}
    text=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(text,encoding='utf-8')
    print(text,end='')
    raise SystemExit(0 if result['status']=='passed' else 1)
if __name__=='__main__':main()
