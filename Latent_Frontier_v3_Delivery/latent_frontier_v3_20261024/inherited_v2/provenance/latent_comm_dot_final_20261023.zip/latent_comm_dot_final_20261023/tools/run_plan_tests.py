"""Run only this package's helper tests and record exact counts; never run a research model."""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import platform
import sys
import time
import unittest

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--report',type=Path)
    parser.add_argument('--log',type=Path)
    args=parser.parse_args()
    suite=unittest.TestLoader().discover(str(args.root/'tests'),pattern='test_plan_tools.py')
    buffer=io.StringIO();start=time.perf_counter()
    result=unittest.TextTestRunner(stream=buffer,verbosity=2).run(suite)
    text=buffer.getvalue();print(text,end='')
    report={'status':'passed' if result.wasSuccessful() else 'failed','scope':'PLAN_HELPER_TESTS_ONLY_NOT_TARGET_LIBRARY',
            'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
            'elapsed_seconds':round(time.perf_counter()-start,3),'python':platform.python_version(),
            'model_executed':False,'target_library_tests_executed':False,
            'details':[{'test':str(t),'traceback':s} for t,s in result.failures+result.errors]}
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if args.log:
        args.log.parent.mkdir(parents=True,exist_ok=True);args.log.write_text(text,encoding='utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
if __name__=='__main__':main()
