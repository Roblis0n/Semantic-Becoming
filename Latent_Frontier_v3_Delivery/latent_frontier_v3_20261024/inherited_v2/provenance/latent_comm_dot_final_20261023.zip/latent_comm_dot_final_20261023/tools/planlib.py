"""Pure-Python helpers for this PLAN package, not the Latent Comm Lab implementation."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Any

class PlanError(ValueError):
    """A structural, policy or integrity check failed."""

def strict_json_text(text: str) -> Any:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in items:
            if key in result:
                raise PlanError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result
    def invalid_constant(value: str) -> None:
        raise PlanError(f"Non-finite JSON value: {value}")
    return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid_constant)

def read_json(path: Path) -> Any:
    return strict_json_text(path.read_text(encoding="utf-8"))

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()

def inside(root: Path, relative: str) -> Path:
    root = root.resolve()
    candidate = (root / relative).resolve()
    if not candidate.is_relative_to(root):
        raise PlanError(f"Path escapes root: {relative}")
    return candidate

def topological_order(tasks: list[dict[str, Any]]) -> list[str]:
    ids = [task["id"] for task in tasks]
    if len(ids) != len(set(ids)):
        raise PlanError("Duplicate task ID")
    by_id = {task["id"]: task for task in tasks}
    for task in tasks:
        deps = task["depends_on"]
        if len(deps) != len(set(deps)):
            raise PlanError(f"Duplicate dependency for {task['id']}")
        for dep in deps:
            if dep not in by_id:
                raise PlanError(f"Unknown dependency: {dep}")
    result: list[str] = []
    visiting: set[str] = set()
    visited: set[str] = set()
    def visit(node: str) -> None:
        if node in visiting:
            raise PlanError(f"Dependency cycle at {node}")
        if node in visited:
            return
        visiting.add(node)
        for dep in by_id[node]["depends_on"]:
            visit(dep)
        visiting.remove(node)
        visited.add(node)
        result.append(node)
    for node in ids:
        visit(node)
    return result

def validate_metric_evidence(record: dict[str, Any]) -> None:
    if record.get("model_executed") is not False:
        raise PlanError("Current scope requires explicit model_executed=false")
    if record.get("model_metrics") is not None:
        raise PlanError("Unmeasured model metrics must remain null, not zero")
    if record.get("evidence_kind") not in {
        "planning_artifact", "static_check", "unit_math", "fixture_pipeline", "media_render"
    }:
        raise PlanError("Unsupported or empirical-model evidence in current scope")
    if record.get("scientific_hypotheses") != "not_tested":
        raise PlanError("Scientific conclusions are not tested in this delivery")
