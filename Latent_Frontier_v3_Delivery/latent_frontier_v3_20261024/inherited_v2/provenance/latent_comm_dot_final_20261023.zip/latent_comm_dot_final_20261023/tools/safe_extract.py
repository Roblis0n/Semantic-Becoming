"""Bounded, no-overwrite ZIP extractor for the supplied planning archives.
No shell execution, no model operations, no third-party code execution.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import unicodedata
import zipfile
from planlib import PlanError

RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}

def safe_member(name: str) -> str:
    if not name or "\\" in name or "\x00" in name or ":" in name:
        raise PlanError(f"Unsafe ZIP path: {name!r}")
    if name.startswith("/"):
        raise PlanError("Absolute ZIP path")
    parts = name.rstrip("/").split("/")
    if any(p in ("", ".", "..") or p.endswith((".", " ")) for p in parts):
        raise PlanError("Ambiguous or traversing ZIP path")
    if any(p.split(".")[0].casefold() in RESERVED for p in parts):
        raise PlanError("Reserved device filename")
    return unicodedata.normalize("NFC", "/".join(parts))

def preflight(zf: zipfile.ZipFile, *, max_total: int = 64 << 20,
              max_file: int = 32 << 20, max_ratio: int = 1000,
              max_entries: int = 10000) -> list[tuple[zipfile.ZipInfo, str]]:
    infos = zf.infolist()
    if len(infos) > max_entries:
        raise PlanError("ZIP entry limit exceeded")
    if max_total < 0 or max_file < 0 or max_ratio < 1:
        raise PlanError("Invalid extraction limits")
    seen: dict[str, bool] = {}
    result: list[tuple[zipfile.ZipInfo, str]] = []
    total = 0
    for info in infos:
        name = safe_member(info.filename)
        key = name.casefold()
        if key in seen:
            raise PlanError("Duplicate/case/Unicode-normalized ZIP destination")
        mode = info.external_attr >> 16
        if stat.S_ISLNK(mode) or (mode and stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
            raise PlanError("ZIP special files are forbidden")
        if info.flag_bits & 1:
            raise PlanError("Encrypted ZIP entries are unsupported")
        total += info.file_size
        if info.file_size > max_file or total > max_total:
            raise PlanError("ZIP decompressed size exceeds budget")
        if info.file_size and info.file_size / max(1, info.compress_size) > max_ratio:
            raise PlanError("ZIP compression ratio exceeds budget")
        seen[key] = info.is_dir()
        result.append((info, name))
    for key in seen:
        parts = key.split("/")
        for n in range(1, len(parts)):
            parent = "/".join(parts[:n])
            if parent in seen and not seen[parent]:
                raise PlanError("ZIP file/directory collision")
    return result

def extract_checked(archive: Path, destination: Path, **limits: int) -> list[str]:
    if destination.exists() or destination.is_symlink():
        raise PlanError("Destination must not exist; no overwrite")
    destination.parent.mkdir(parents=True, exist_ok=True)
    parent = destination.parent.resolve()
    destination = parent / destination.name
    with zipfile.ZipFile(archive) as zf:
        entries = preflight(zf, **limits)
        temp = Path(tempfile.mkdtemp(prefix=".extract-", dir=parent))
        try:
            for info, name in entries:
                out = temp / PurePosixPath(name)
                if info.is_dir():
                    out.mkdir(parents=True, exist_ok=True)
                    continue
                out.parent.mkdir(parents=True, exist_ok=True)
                copied = 0
                with zf.open(info) as src, out.open("xb") as dst:
                    while True:
                        block = src.read(1 << 16)
                        if not block:
                            break
                        copied += len(block)
                        if copied > info.file_size:
                            raise PlanError("ZIP actual size exceeds declared size")
                        dst.write(block)
                if copied != info.file_size:
                    raise PlanError("Truncated ZIP member")
            if destination.exists() or destination.is_symlink():
                raise PlanError("Destination appeared during extraction")
            os.rename(temp, destination)
        except BaseException:
            shutil.rmtree(temp, ignore_errors=True)
            raise
    return [name for _, name in entries]

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    files = extract_checked(args.archive, args.destination)
    print(f"Extracted {len(files)} checked entries; no code executed.")

if __name__ == "__main__":
    main()
