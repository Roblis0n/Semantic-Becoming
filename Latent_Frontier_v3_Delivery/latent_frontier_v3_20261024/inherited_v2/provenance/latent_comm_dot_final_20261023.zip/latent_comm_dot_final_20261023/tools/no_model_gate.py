"""Auditable reference guard. NOT an OS security sandbox or the target project's full policy layer."""
from __future__ import annotations
from types import MappingProxyType
from typing import Any, Mapping
from planlib import PlanError

DENIED_FLAGS = (
    "allow_model_download", "allow_tokenizer_download", "allow_dataset_download",
    "allow_model_load", "allow_model_forward", "allow_model_generate",
    "allow_model_training", "allow_random_transformer", "allow_gpu",
    "allow_public_publish", "allow_remote_write", "allow_purchase",
    "allow_system_changes", "allow_user_private_data_access", "future_model_authorization",
)
KNOWN_ACTIONS = frozenset({
    "public_document_read", "capability_discovery", "workspace_write",
    "isolated_dependency_install", "static_check", "data_fixture",
    "tensor_math_fixture", "mock_contract", "codec_test", "fixture_pipeline",
    "local_build", "media_source", "authorized_media_render", "local_package",
})

def validate_policy(policy: Mapping[str, Any]) -> None:
    if policy.get("mode") != "no_model_execution":
        raise PlanError("Policy mode may not be relaxed")
    if policy.get("immutable_for_this_run") is not True:
        raise PlanError("Policy must be explicitly fixed for this task")
    for key in DENIED_FLAGS:
        if policy.get(key) is not False:
            raise PlanError(f"{key} must be explicitly false")
    for key in ("model_weight_download_bytes", "dataset_download_bytes", "incremental_spend"):
        if type(policy.get(key)) is not int or policy[key] != 0:
            raise PlanError(f"{key} must equal integer zero")
    actions = policy.get("allowed_actions")
    if not isinstance(actions, list) or not actions or any(a not in KNOWN_ACTIONS for a in actions):
        raise PlanError("Unapproved action in allowlist")
    if len(actions) != len(set(actions)):
        raise PlanError("Duplicate allowed action")

class ExecutionGate:
    def __init__(self, policy: Mapping[str, Any]) -> None:
        validate_policy(policy)
        self._mode = "no_model_execution"
        self._actions = frozenset(policy["allowed_actions"])

    def authorize(self, action: str) -> None:
        if action.startswith(("model.", "tokenizer.", "gpu.", "dataset.download")):
            raise PermissionError("E_MODEL_EXECUTION_DISABLED: " + action)
        if action not in self._actions:
            raise PermissionError("E_PERMISSION: " + action)
