"""Build consolidated reading copy, index, integrity manifest and ZIP of this PLAN package."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from urllib.parse import quote
import zipfile
from planlib import sha256_file

def package_files(root: Path):
    return sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')

def assemble(root: Path, output: Path | None) -> None:
    root=root.resolve()
    master=['# Latent Comm Lab｜Dot最终实施方案合订版\n',
      '本合订版汇集41份专项规范与25份提示词。详细工作包见task_cards；全部可机读数据见specs。当前为规划包，目标库由Dot执行实现；模型实测禁止。\n',
      '[执行入口](START_HERE.md) · [文件索引](FILE_INDEX.md) · [一次性总控](prompts/00_Dot一次性总控执行提示词.md)\n']
    for directory in ['docs','prompts']:
        master.append('\n# '+('第一部：专项规范' if directory=='docs' else '第二部：执行提示词')+'\n')
        for p in sorted((root/directory).glob('*.md')):
            rel=p.relative_to(root).as_posix()
            master.append(f'\n---\n\n原分册：[{p.name}]({quote(rel)})\n\n'+p.read_text(encoding='utf-8'))
    (root/'MASTER_PLAN.md').write_text('\n'.join(master),encoding='utf-8')
    index=['# 全部文件索引\n','这份索引列出规划包文件，不表示对应目标工程已实现。source_archives只用于历史溯源，旧prompt不执行。\n']
    files=package_files(root)
    groups={}
    for p in files:
        if p.name in {'MANIFEST.json','FILE_INDEX.md'}:continue
        rel=p.relative_to(root).as_posix();group=rel.split('/')[0] if '/' in rel else '根目录'
        groups.setdefault(group,[]).append((p,rel))
    for group,items in groups.items():
        index.append(f'\n## {group}（{len(items)}项）\n')
        index.append('|文件|字节数|\n|---|---|')
        for p,rel in items:index.append(f'|[{p.name}]({quote(rel)})|{p.stat().st_size}|')
    (root/'FILE_INDEX.md').write_text('\n'.join(index)+'\n',encoding='utf-8')
    files=package_files(root)
    manifest={'scope':'plan_package_integrity_not_authentication','hash':'sha256','excluded':['MANIFEST.json','__pycache__','*.pyc'],
      'files':[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha256_file(p)}for p in files if p.name!='MANIFEST.json']}
    (root/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if output:
        output.parent.mkdir(parents=True,exist_ok=True)
        if output.resolve().is_relative_to(root):raise ValueError('ZIP output must be outside the plan root')
        with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in package_files(root):z.write(p,root.name+'/'+p.relative_to(root).as_posix())
        output.with_suffix(output.suffix+'.sha256').write_text(sha256_file(output)+'  '+output.name+'\n',encoding='ascii')
        print(f'Wrote {output} ({output.stat().st_size} bytes)')
    print(f'Manifest covers {len(manifest["files"])} files; SHA256 checks integrity, not identity.')

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a.add_argument('--zip',type=Path)
    args=a.parse_args();assemble(args.root,args.zip)
if __name__=='__main__':main()
