# 来源索引与事实边界

核验日期：2026-10-23。只使用官方文档、论文摘要与作者仓库；没有运行前作模型。文档内[Rxx]指向本表。公开页面可变，Dot实施时仍需与锁定依赖版本对应。

|ID|来源|链接|日期与支持范围|
|---|---|---|---|
|R01|OpenAI · Introducing dots|[Introducing dots](https://openai.com/index/introducing-dots/)|2026-09-29。官方产品能力：云电脑、浏览器、4,000+应用生态；不证明当前用户具体连接可用。|
|R02|OpenAI · Dots privacy, security, and safety FAQs|[Dots privacy, security, and safety FAQs](https://help.openai.com/en/articles/20001529-dots-privacy-security-and-safety-faqs)|滚动文档；不推定首发日期。共享插件权限、动作审批和自定义规则边界。|
|R03|OpenAI · Getting started with your dot|[Getting started with your dot](https://help.openai.com/en/articles/20001530-getting-started-with-your-dot)|滚动文档；不推定首发日期。云电脑、可选本地电脑授权、实际应用可用性与Codex环境入口。|
|R04|PyTorch · Autograd mechanics|[Autograd mechanics](https://docs.pytorch.org/docs/2.14/notes/autograd.html)|滚动文档；不推定首发日期。冻结参数与no_grad不同；本包据此设计输入梯度边界。未做真实语言模型验证。|
|R05|Hugging Face · Qwen3 model documentation|[Qwen3 model documentation](https://huggingface.co/docs/transformers/en/model_doc/qwen3)|滚动文档；不推定首发日期。模型接口和inputs_embeds/hidden/cache相关参数；需要与实际锁定版本核对。|
|R06|Hugging Face · Caching|[Caching](https://huggingface.co/docs/transformers/en/cache_explanation)|滚动文档；不推定首发日期。prefill/decode与cache使用原则，实际模型仍待验证。|
|R07|Hugging Face · Safetensors|[Safetensors](https://huggingface.co/docs/safetensors/en/index)|滚动文档；不推定首发日期。安全张量容器；不等于身份认证、输入资源限制或数据匿名化。|
|R08|arXiv / authors · Interlat|[Interlat](https://arxiv.org/abs/2511.09149)|2025-11-12。论文摘要级核验：隐状态通信及压缩；非本项目复现。|
|R09|Gen-Verse · LatentMAS official repository|[LatentMAS official repository](https://github.com/Gen-Verse/LatentMAS)|滚动文档；不推定首发日期。作者仓库可见实现与免训练潜空间协作线索；本轮未运行。|
|R10|arXiv / authors · XKV|[XKV](https://arxiv.org/abs/2608.20617)|2026-08-20。异构模型缓存翻译和冻结基础模型的相关研究；非通用兼容证明。|
|R11|arXiv / authors · LatBridge|[LatBridge](https://arxiv.org/abs/2610.27813)|2026-10-20。模型更换和通信接口复用相关研究；非已验证目标库。|
|R12|VectorArc · Agent Vector Protocol Python repository|[Agent Vector Protocol Python repository](https://github.com/VectorArc/avp-python)|滚动文档；不推定首发日期。公开SDK/协议线索；本轮未运行，不复制其能力声明。|
|R13|Hugging Face · Chat templates|[Chat templates](https://huggingface.co/docs/transformers/en/chat_templating)|滚动文档；不推定首发日期。模型聊天模板、角色和生成提示边界；本轮用fixture tokenizer而非下载真实tokenizer。|
|R14|PyTorch · Reproducibility|[Reproducibility](https://docs.pytorch.org/docs/2.14/notes/randomness.html)|滚动文档；不推定首发日期。随机性与确定性限制；跨版本/平台不可保证完全相同。|
|R15|GitHub · Secure use reference|[Secure use reference](https://docs.github.com/en/actions/reference/security/secure-use)|滚动文档；不推定首发日期。最小权限、第三方Action固定与不可信代码边界。|
|R16|PyPA · Writing your pyproject.toml|[Writing your pyproject.toml](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/)|滚动文档；不推定首发日期。构建元数据、project与build-system；本包不臆造用户身份或license。|

## 附件来源

A01为本轮新工程方案，A02为前轮研究计划ZIP，A03为前轮合订版。原始字节封存于source_archives，精确hash见input_manifest.json。旧会话结论只是来源材料，不自动成为本轮已经核验的事实。

## 新增设计

本轮执行policy、任务DAG、媒体方案、版本门槛和训练实现范围都是本包的工程决策，不冒充任何论文结论。论文出现不代表项目无人做过，代码通过fixture不代表语义有效。
