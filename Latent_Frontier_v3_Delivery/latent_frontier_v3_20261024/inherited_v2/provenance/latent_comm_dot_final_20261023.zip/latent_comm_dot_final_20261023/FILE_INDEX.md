# 全部文件索引

这份索引列出规划包文件，不表示对应目标工程已实现。source_archives只用于历史溯源，旧prompt不执行。


## 根目录（4项）

|文件|字节数|
|---|---|
|[MASTER_PLAN.md](MASTER_PLAN.md)|209385|
|[PLAN_DELIVERY_REPORT.md](PLAN_DELIVERY_REPORT.md)|1462|
|[README_先读这里.md](README_%E5%85%88%E8%AF%BB%E8%BF%99%E9%87%8C.md)|2583|
|[START_HERE.md](START_HERE.md)|2991|

## configs（4项）

|文件|字节数|
|---|---|
|[execution_policy.json](configs/execution_policy.json)|1820|
|[fixture_pipeline.json](configs/fixture_pipeline.json)|2034|
|[future_model_design_LOCKED.json](configs/future_model_design_LOCKED.json)|2106|
|[model_authorization_LOCKED.json](configs/model_authorization_LOCKED.json)|316|

## docs（41项）

|文件|字节数|
|---|---|
|[00_最终决策与交付边界.md](docs/00_%E6%9C%80%E7%BB%88%E5%86%B3%E7%AD%96%E4%B8%8E%E4%BA%A4%E4%BB%98%E8%BE%B9%E7%95%8C.md)|4793|
|[01_两套方案合并与冲突裁决.md](docs/01_%E4%B8%A4%E5%A5%97%E6%96%B9%E6%A1%88%E5%90%88%E5%B9%B6%E4%B8%8E%E5%86%B2%E7%AA%81%E8%A3%81%E5%86%B3.md)|4578|
|[02_第一性原则与研究问题.md](docs/02_%E7%AC%AC%E4%B8%80%E6%80%A7%E5%8E%9F%E5%88%99%E4%B8%8E%E7%A0%94%E7%A9%B6%E9%97%AE%E9%A2%98.md)|3705|
|[03_不做模型实测的强制执行策略.md](docs/03_%E4%B8%8D%E5%81%9A%E6%A8%A1%E5%9E%8B%E5%AE%9E%E6%B5%8B%E7%9A%84%E5%BC%BA%E5%88%B6%E6%89%A7%E8%A1%8C%E7%AD%96%E7%95%A5.md)|4492|
|[04_Dot总控章程与一次性执行.md](docs/04_Dot%E6%80%BB%E6%8E%A7%E7%AB%A0%E7%A8%8B%E4%B8%8E%E4%B8%80%E6%AC%A1%E6%80%A7%E6%89%A7%E8%A1%8C.md)|3864|
|[05_Dot浏览器插件与工具能力矩阵.md](docs/05_Dot%E6%B5%8F%E8%A7%88%E5%99%A8%E6%8F%92%E4%BB%B6%E4%B8%8E%E5%B7%A5%E5%85%B7%E8%83%BD%E5%8A%9B%E7%9F%A9%E9%98%B5.md)|4318|
|[06_系统架构与仓库组织.md](docs/06_%E7%B3%BB%E7%BB%9F%E6%9E%B6%E6%9E%84%E4%B8%8E%E4%BB%93%E5%BA%93%E7%BB%84%E7%BB%87.md)|4003|
|[07_类型接口与信息契约.md](docs/07_%E7%B1%BB%E5%9E%8B%E6%8E%A5%E5%8F%A3%E4%B8%8E%E4%BF%A1%E6%81%AF%E5%A5%91%E7%BA%A6.md)|3847|
|[08_配置错误码与默认资源.md](docs/08_%E9%85%8D%E7%BD%AE%E9%94%99%E8%AF%AF%E7%A0%81%E4%B8%8E%E9%BB%98%E8%AE%A4%E8%B5%84%E6%BA%90.md)|4024|
|[09_数据生成划分与泄漏防护.md](docs/09_%E6%95%B0%E6%8D%AE%E7%94%9F%E6%88%90%E5%88%92%E5%88%86%E4%B8%8E%E6%B3%84%E6%BC%8F%E9%98%B2%E6%8A%A4.md)|4326|
|[10_提示格式标签位置与掩码.md](docs/10_%E6%8F%90%E7%A4%BA%E6%A0%BC%E5%BC%8F%E6%A0%87%E7%AD%BE%E4%BD%8D%E7%BD%AE%E4%B8%8E%E6%8E%A9%E7%A0%81.md)|3467|
|[11_HF后端与自由生成完整实现要求.md](docs/11_HF%E5%90%8E%E7%AB%AF%E4%B8%8E%E8%87%AA%E7%94%B1%E7%94%9F%E6%88%90%E5%AE%8C%E6%95%B4%E5%AE%9E%E7%8E%B0%E8%A6%81%E6%B1%82.md)|4031|
|[12_桥接器结构初始化与梯度.md](docs/12_%E6%A1%A5%E6%8E%A5%E5%99%A8%E7%BB%93%E6%9E%84%E5%88%9D%E5%A7%8B%E5%8C%96%E4%B8%8E%E6%A2%AF%E5%BA%A6.md)|3211|
|[13_训练损失监督蒸馏与反事实.md](docs/13_%E8%AE%AD%E7%BB%83%E6%8D%9F%E5%A4%B1%E7%9B%91%E7%9D%A3%E8%92%B8%E9%A6%8F%E4%B8%8E%E5%8F%8D%E4%BA%8B%E5%AE%9E.md)|3661|
|[14_预算控制量化与真实码率.md](docs/14_%E9%A2%84%E7%AE%97%E6%8E%A7%E5%88%B6%E9%87%8F%E5%8C%96%E4%B8%8E%E7%9C%9F%E5%AE%9E%E7%A0%81%E7%8E%87.md)|3316|
|[15_训练循环状态机与恢复.md](docs/15_%E8%AE%AD%E7%BB%83%E5%BE%AA%E7%8E%AF%E7%8A%B6%E6%80%81%E6%9C%BA%E4%B8%8E%E6%81%A2%E5%A4%8D.md)|3293|
|[16_公平基线与对照实现.md](docs/16_%E5%85%AC%E5%B9%B3%E5%9F%BA%E7%BA%BF%E4%B8%8E%E5%AF%B9%E7%85%A7%E5%AE%9E%E7%8E%B0.md)|3519|
|[17_内容审计反事实与统计评估.md](docs/17_%E5%86%85%E5%AE%B9%E5%AE%A1%E8%AE%A1%E5%8F%8D%E4%BA%8B%E5%AE%9E%E4%B8%8E%E7%BB%9F%E8%AE%A1%E8%AF%84%E4%BC%B0.md)|3500|
|[18_成本计量估算与结果账本.md](docs/18_%E6%88%90%E6%9C%AC%E8%AE%A1%E9%87%8F%E4%BC%B0%E7%AE%97%E4%B8%8E%E7%BB%93%E6%9E%9C%E8%B4%A6%E6%9C%AC.md)|3020|
|[19_缓存检查点与可复现证据.md](docs/19_%E7%BC%93%E5%AD%98%E6%A3%80%E6%9F%A5%E7%82%B9%E4%B8%8E%E5%8F%AF%E5%A4%8D%E7%8E%B0%E8%AF%81%E6%8D%AE.md)|3075|
|[20_消息协议兼容性与安全边界.md](docs/20_%E6%B6%88%E6%81%AF%E5%8D%8F%E8%AE%AE%E5%85%BC%E5%AE%B9%E6%80%A7%E4%B8%8E%E5%AE%89%E5%85%A8%E8%BE%B9%E7%95%8C.md)|3061|
|[21_兼容性注册表与能力声明.md](docs/21_%E5%85%BC%E5%AE%B9%E6%80%A7%E6%B3%A8%E5%86%8C%E8%A1%A8%E4%B8%8E%E8%83%BD%E5%8A%9B%E5%A3%B0%E6%98%8E.md)|3768|
|[22_CLI与Python_API逐命令契约.md](docs/22_CLI%E4%B8%8EPython_API%E9%80%90%E5%91%BD%E4%BB%A4%E5%A5%91%E7%BA%A6.md)|4551|
|[23_Pipeline_DAG恢复与幂等.md](docs/23_Pipeline_DAG%E6%81%A2%E5%A4%8D%E4%B8%8E%E5%B9%82%E7%AD%89.md)|4127|
|[24_无模型测试体系与故障注入.md](docs/24_%E6%97%A0%E6%A8%A1%E5%9E%8B%E6%B5%8B%E8%AF%95%E4%BD%93%E7%B3%BB%E4%B8%8E%E6%95%85%E9%9A%9C%E6%B3%A8%E5%85%A5.md)|4279|
|[25_依赖锁定CI与构建发布.md](docs/25_%E4%BE%9D%E8%B5%96%E9%94%81%E5%AE%9ACI%E4%B8%8E%E6%9E%84%E5%BB%BA%E5%8F%91%E5%B8%83.md)|3652|
|[26_安全隐私权限与供应链.md](docs/26_%E5%AE%89%E5%85%A8%E9%9A%90%E7%A7%81%E6%9D%83%E9%99%90%E4%B8%8E%E4%BE%9B%E5%BA%94%E9%93%BE.md)|3418|
|[27_资源Windows与本地部署保护.md](docs/27_%E8%B5%84%E6%BA%90Windows%E4%B8%8E%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2%E4%BF%9D%E6%8A%A4.md)|2780|
|[28_Dot协作上下文管理与恢复.md](docs/28_Dot%E5%8D%8F%E4%BD%9C%E4%B8%8A%E4%B8%8B%E6%96%87%E7%AE%A1%E7%90%86%E4%B8%8E%E6%81%A2%E5%A4%8D.md)|3082|
|[29_文档GitHub交付与发布边界.md](docs/29_%E6%96%87%E6%A1%A3GitHub%E4%BA%A4%E4%BB%98%E4%B8%8E%E5%8F%91%E5%B8%83%E8%BE%B9%E7%95%8C.md)|3006|
|[30_文献核验与证据台账.md](docs/30_%E6%96%87%E7%8C%AE%E6%A0%B8%E9%AA%8C%E4%B8%8E%E8%AF%81%E6%8D%AE%E5%8F%B0%E8%B4%A6.md)|2957|
|[31_媒体交付总方案与素材边界.md](docs/31_%E5%AA%92%E4%BD%93%E4%BA%A4%E4%BB%98%E6%80%BB%E6%96%B9%E6%A1%88%E4%B8%8E%E7%B4%A0%E6%9D%90%E8%BE%B9%E7%95%8C.md)|3728|
|[32_PPT十六页逐页脚本.md](docs/32_PPT%E5%8D%81%E5%85%AD%E9%A1%B5%E9%80%90%E9%A1%B5%E8%84%9A%E6%9C%AC.md)|7200|
|[33_动画视频分镜与渲染流水线.md](docs/33_%E5%8A%A8%E7%94%BB%E8%A7%86%E9%A2%91%E5%88%86%E9%95%9C%E4%B8%8E%E6%B8%B2%E6%9F%93%E6%B5%81%E6%B0%B4%E7%BA%BF.md)|3645|
|[34_中文配音全文字幕与音频.md](docs/34_%E4%B8%AD%E6%96%87%E9%85%8D%E9%9F%B3%E5%85%A8%E6%96%87%E5%AD%97%E5%B9%95%E4%B8%8E%E9%9F%B3%E9%A2%91.md)|6182|
|[35_媒体与代码证据一致性验收.md](docs/35_%E5%AA%92%E4%BD%93%E4%B8%8E%E4%BB%A3%E7%A0%81%E8%AF%81%E6%8D%AE%E4%B8%80%E8%87%B4%E6%80%A7%E9%AA%8C%E6%94%B6.md)|2509|
|[36_执行阶段验收门与自动推进.md](docs/36_%E6%89%A7%E8%A1%8C%E9%98%B6%E6%AE%B5%E9%AA%8C%E6%94%B6%E9%97%A8%E4%B8%8E%E8%87%AA%E5%8A%A8%E6%8E%A8%E8%BF%9B.md)|3242|
|[37_需求追踪Definition_of_Done.md](docs/37_%E9%9C%80%E6%B1%82%E8%BF%BD%E8%B8%AADefinition_of_Done.md)|2804|
|[38_未来模型实验解锁协议.md](docs/38_%E6%9C%AA%E6%9D%A5%E6%A8%A1%E5%9E%8B%E5%AE%9E%E9%AA%8C%E8%A7%A3%E9%94%81%E5%8D%8F%E8%AE%AE.md)|2463|
|[39_后续研究路线与训练探索矩阵.md](docs/39_%E5%90%8E%E7%BB%AD%E7%A0%94%E7%A9%B6%E8%B7%AF%E7%BA%BF%E4%B8%8E%E8%AE%AD%E7%BB%83%E6%8E%A2%E7%B4%A2%E7%9F%A9%E9%98%B5.md)|3668|
|[40_风险ADR与最终交接模板.md](docs/40_%E9%A3%8E%E9%99%A9ADR%E4%B8%8E%E6%9C%80%E7%BB%88%E4%BA%A4%E6%8E%A5%E6%A8%A1%E6%9D%BF.md)|3008|

## evidence（7项）

|文件|字节数|
|---|---|
|[input_manifest.json](evidence/input_manifest.json)|852|
|[plan_environment.json](evidence/plan_environment.json)|463|
|[plan_helper_tests.json](evidence/plan_helper_tests.json)|284|
|[plan_helper_tests.log](evidence/plan_helper_tests.log)|5091|
|[plan_validation.json](evidence/plan_validation.json)|1720|
|[source_register.json](evidence/source_register.json)|6945|
|[sources.md](evidence/sources.md)|4505|

## media（7项）

|文件|字节数|
|---|---|
|[animation_timeline.json](media/animation_timeline.json)|1534|
|[captions.draft.json](media/captions.draft.json)|250|
|[content_manifest.json](media/content_manifest.json)|3084|
|[slides_storyboard.json](media/slides_storyboard.json)|8585|
|[video_timeline.json](media/video_timeline.json)|1475|
|[旁白全文_4分钟.md](media/%E6%97%81%E7%99%BD%E5%85%A8%E6%96%87_4%E5%88%86%E9%92%9F.md)|3593|
|[旁白全文_90秒.md](media/%E6%97%81%E7%99%BD%E5%85%A8%E6%96%87_90%E7%A7%92.md)|880|

## prompts（25项）

|文件|字节数|
|---|---|
|[00_Dot一次性总控执行提示词.md](prompts/00_Dot%E4%B8%80%E6%AC%A1%E6%80%A7%E6%80%BB%E6%8E%A7%E6%89%A7%E8%A1%8C%E6%8F%90%E7%A4%BA%E8%AF%8D.md)|6009|
|[01_接管与能力盘点.md](prompts/01_%E6%8E%A5%E7%AE%A1%E4%B8%8E%E8%83%BD%E5%8A%9B%E7%9B%98%E7%82%B9.md)|1679|
|[02_架构与契约冻结.md](prompts/02_%E6%9E%B6%E6%9E%84%E4%B8%8E%E5%A5%91%E7%BA%A6%E5%86%BB%E7%BB%93.md)|1661|
|[03_数据与反事实实现.md](prompts/03_%E6%95%B0%E6%8D%AE%E4%B8%8E%E5%8F%8D%E4%BA%8B%E5%AE%9E%E5%AE%9E%E7%8E%B0.md)|1583|
|[04_HF后端与生成实现.md](prompts/04_HF%E5%90%8E%E7%AB%AF%E4%B8%8E%E7%94%9F%E6%88%90%E5%AE%9E%E7%8E%B0.md)|1699|
|[05_桥与可微通路.md](prompts/05_%E6%A1%A5%E4%B8%8E%E5%8F%AF%E5%BE%AE%E9%80%9A%E8%B7%AF.md)|1566|
|[06_损失与训练器.md](prompts/06_%E6%8D%9F%E5%A4%B1%E4%B8%8E%E8%AE%AD%E7%BB%83%E5%99%A8.md)|1623|
|[07_消息编码缓存与兼容.md](prompts/07_%E6%B6%88%E6%81%AF%E7%BC%96%E7%A0%81%E7%BC%93%E5%AD%98%E4%B8%8E%E5%85%BC%E5%AE%B9.md)|1623|
|[08_基线审计与统计.md](prompts/08_%E5%9F%BA%E7%BA%BF%E5%AE%A1%E8%AE%A1%E4%B8%8E%E7%BB%9F%E8%AE%A1.md)|1644|
|[09_CLI与流水线整合.md](prompts/09_CLI%E4%B8%8E%E6%B5%81%E6%B0%B4%E7%BA%BF%E6%95%B4%E5%90%88.md)|1608|
|[10_独立代码审查.md](prompts/10_%E7%8B%AC%E7%AB%8B%E4%BB%A3%E7%A0%81%E5%AE%A1%E6%9F%A5.md)|1672|
|[11_测试与变异验证.md](prompts/11_%E6%B5%8B%E8%AF%95%E4%B8%8E%E5%8F%98%E5%BC%82%E9%AA%8C%E8%AF%81.md)|1608|
|[12_安全与权限审查.md](prompts/12_%E5%AE%89%E5%85%A8%E4%B8%8E%E6%9D%83%E9%99%90%E5%AE%A1%E6%9F%A5.md)|1594|
|[13_依赖构建与跨平台.md](prompts/13_%E4%BE%9D%E8%B5%96%E6%9E%84%E5%BB%BA%E4%B8%8E%E8%B7%A8%E5%B9%B3%E5%8F%B0.md)|1547|
|[14_文献与来源核验.md](prompts/14_%E6%96%87%E7%8C%AE%E4%B8%8E%E6%9D%A5%E6%BA%90%E6%A0%B8%E9%AA%8C.md)|1597|
|[15_技术文档与README.md](prompts/15_%E6%8A%80%E6%9C%AF%E6%96%87%E6%A1%A3%E4%B8%8EREADME.md)|1581|
|[16_PPT制作.md](prompts/16_PPT%E5%88%B6%E4%BD%9C.md)|1544|
|[17_机制动画制作.md](prompts/17_%E6%9C%BA%E5%88%B6%E5%8A%A8%E7%94%BB%E5%88%B6%E4%BD%9C.md)|1495|
|[18_配音字幕制作.md](prompts/18_%E9%85%8D%E9%9F%B3%E5%AD%97%E5%B9%95%E5%88%B6%E4%BD%9C.md)|1543|
|[19_视频合成与浏览器回看.md](prompts/19_%E8%A7%86%E9%A2%91%E5%90%88%E6%88%90%E4%B8%8E%E6%B5%8F%E8%A7%88%E5%99%A8%E5%9B%9E%E7%9C%8B.md)|1612|
|[20_最终一致性验收.md](prompts/20_%E6%9C%80%E7%BB%88%E4%B8%80%E8%87%B4%E6%80%A7%E9%AA%8C%E6%94%B6.md)|1624|
|[21_受控修复提示词.md](prompts/21_%E5%8F%97%E6%8E%A7%E4%BF%AE%E5%A4%8D%E6%8F%90%E7%A4%BA%E8%AF%8D.md)|1551|
|[22_上下文恢复提示词.md](prompts/22_%E4%B8%8A%E4%B8%8B%E6%96%87%E6%81%A2%E5%A4%8D%E6%8F%90%E7%A4%BA%E8%AF%8D.md)|1563|
|[23_未来模型解锁审查_本轮禁用.md](prompts/23_%E6%9C%AA%E6%9D%A5%E6%A8%A1%E5%9E%8B%E8%A7%A3%E9%94%81%E5%AE%A1%E6%9F%A5_%E6%9C%AC%E8%BD%AE%E7%A6%81%E7%94%A8.md)|1567|
|[24_模型任务提示模板_仅作为源码数据.md](prompts/24_%E6%A8%A1%E5%9E%8B%E4%BB%BB%E5%8A%A1%E6%8F%90%E7%A4%BA%E6%A8%A1%E6%9D%BF_%E4%BB%85%E4%BD%9C%E4%B8%BA%E6%BA%90%E7%A0%81%E6%95%B0%E6%8D%AE.md)|2686|

## source_archives（3项）

|文件|字节数|
|---|---|
|[latent_comm_project_plan_20261023.zip](source_archives/latent_comm_project_plan_20261023.zip)|189636|
|[latent_communication_master_plan_20261023.md](source_archives/latent_communication_master_plan_20261023.md)|66202|
|[latent_communication_research_pack_20261023.zip](source_archives/latent_communication_research_pack_20261023.zip)|88325|

## specs（17项）

|文件|字节数|
|---|---|
|[capability.schema.json](specs/capability.schema.json)|1437|
|[claim_ledger.json](specs/claim_ledger.json)|1048|
|[compatibility.schema.json](specs/compatibility.schema.json)|1158|
|[dataset_row.schema.json](specs/dataset_row.schema.json)|1942|
|[execution_policy.schema.json](specs/execution_policy.schema.json)|4094|
|[experiment_config.schema.json](specs/experiment_config.schema.json)|11122|
|[media_asset.schema.json](specs/media_asset.schema.json)|1398|
|[packet_header.schema.json](specs/packet_header.schema.json)|2590|
|[prediction.schema.json](specs/prediction.schema.json)|1990|
|[requirements.json](specs/requirements.json)|8213|
|[run_manifest.schema.json](specs/run_manifest.schema.json)|1771|
|[schema_examples.json](specs/schema_examples.json)|1314|
|[source_wbs_crosswalk.json](specs/source_wbs_crosswalk.json)|8673|
|[task_graph.json](specs/task_graph.json)|80635|
|[task_result.schema.json](specs/task_result.schema.json)|1520|
|[task_table.csv](specs/task_table.csv)|11554|
|[test_catalog.json](specs/test_catalog.json)|34011|

## task_cards（64项）

|文件|字节数|
|---|---|
|[D00_输入盘点与历史指令隔离.md](task_cards/D00_%E8%BE%93%E5%85%A5%E7%9B%98%E7%82%B9%E4%B8%8E%E5%8E%86%E5%8F%B2%E6%8C%87%E4%BB%A4%E9%9A%94%E7%A6%BB.md)|2509|
|[D01_真实能力与资源盘点.md](task_cards/D01_%E7%9C%9F%E5%AE%9E%E8%83%BD%E5%8A%9B%E4%B8%8E%E8%B5%84%E6%BA%90%E7%9B%98%E7%82%B9.md)|2457|
|[D02_执行策略与硬守卫.md](task_cards/D02_%E6%89%A7%E8%A1%8C%E7%AD%96%E7%95%A5%E4%B8%8E%E7%A1%AC%E5%AE%88%E5%8D%AB.md)|2478|
|[D03_架构ADR与模块依赖.md](task_cards/D03_%E6%9E%B6%E6%9E%84ADR%E4%B8%8E%E6%A8%A1%E5%9D%97%E4%BE%9D%E8%B5%96.md)|2481|
|[D04_轻量包与版本骨架.md](task_cards/D04_%E8%BD%BB%E9%87%8F%E5%8C%85%E4%B8%8E%E7%89%88%E6%9C%AC%E9%AA%A8%E6%9E%B6.md)|2309|
|[D05_严格配置与错误契约.md](task_cards/D05_%E4%B8%A5%E6%A0%BC%E9%85%8D%E7%BD%AE%E4%B8%8E%E9%94%99%E8%AF%AF%E5%A5%91%E7%BA%A6.md)|2420|
|[D06_证据类型与结果状态.md](task_cards/D06_%E8%AF%81%E6%8D%AE%E7%B1%BB%E5%9E%8B%E4%B8%8E%E7%BB%93%E6%9E%9C%E7%8A%B6%E6%80%81.md)|2425|
|[D07_原子写入路径与manifest.md](task_cards/D07_%E5%8E%9F%E5%AD%90%E5%86%99%E5%85%A5%E8%B7%AF%E5%BE%84%E4%B8%8Emanifest.md)|2382|
|[D08_Canonical world与oracle.md](task_cards/D08_Canonical%20world%E4%B8%8Eoracle.md)|2183|
|[D09_合法反事实与分组划分.md](task_cards/D09_%E5%90%88%E6%B3%95%E5%8F%8D%E4%BA%8B%E5%AE%9E%E4%B8%8E%E5%88%86%E7%BB%84%E5%88%92%E5%88%86.md)|2321|
|[D10_角色视图与数据渲染.md](task_cards/D10_%E8%A7%92%E8%89%B2%E8%A7%86%E5%9B%BE%E4%B8%8E%E6%95%B0%E6%8D%AE%E6%B8%B2%E6%9F%93.md)|2381|
|[D11_开发fixture及可读导出.md](task_cards/D11_%E5%BC%80%E5%8F%91fixture%E5%8F%8A%E5%8F%AF%E8%AF%BB%E5%AF%BC%E5%87%BA.md)|2325|
|[D12_非模型fixture后端与Spy.md](task_cards/D12_%E9%9D%9E%E6%A8%A1%E5%9E%8Bfixture%E5%90%8E%E7%AB%AF%E4%B8%8ESpy.md)|2521|
|[D13_聊天格式与答案span.md](task_cards/D13_%E8%81%8A%E5%A4%A9%E6%A0%BC%E5%BC%8F%E4%B8%8E%E7%AD%94%E6%A1%88span.md)|2381|
|[D14_HF加载源码与候选注册.md](task_cards/D14_HF%E5%8A%A0%E8%BD%BD%E6%BA%90%E7%A0%81%E4%B8%8E%E5%80%99%E9%80%89%E6%B3%A8%E5%86%8C.md)|2443|
|[D15_发送状态提取完整源码.md](task_cards/D15_%E5%8F%91%E9%80%81%E7%8A%B6%E6%80%81%E6%8F%90%E5%8F%96%E5%AE%8C%E6%95%B4%E6%BA%90%E7%A0%81.md)|2414|
|[D16_接收前缀训练前向源码.md](task_cards/D16_%E6%8E%A5%E6%94%B6%E5%89%8D%E7%BC%80%E8%AE%AD%E7%BB%83%E5%89%8D%E5%90%91%E6%BA%90%E7%A0%81.md)|2466|
|[D17_ReferenceGreedy自由生成.md](task_cards/D17_ReferenceGreedy%E8%87%AA%E7%94%B1%E7%94%9F%E6%88%90.md)|2360|
|[D18_CachedGreedy状态机.md](task_cards/D18_CachedGreedy%E7%8A%B6%E6%80%81%E6%9C%BA.md)|2414|
|[D19_MaskedMean与线性桥.md](task_cards/D19_MaskedMean%E4%B8%8E%E7%BA%BF%E6%80%A7%E6%A1%A5.md)|2185|
|[D20_Query压缩器与接收投影.md](task_cards/D20_Query%E5%8E%8B%E7%BC%A9%E5%99%A8%E4%B8%8E%E6%8E%A5%E6%94%B6%E6%8A%95%E5%BD%B1.md)|2300|
|[D21_预算条件化与嵌套前缀.md](task_cards/D21_%E9%A2%84%E7%AE%97%E6%9D%A1%E4%BB%B6%E5%8C%96%E4%B8%8E%E5%B5%8C%E5%A5%97%E5%89%8D%E7%BC%80.md)|2226|
|[D22_CE与合法CF损失.md](task_cards/D22_CE%E4%B8%8E%E5%90%88%E6%B3%95CF%E6%8D%9F%E5%A4%B1.md)|2286|
|[D23_同词表教师KL蒸馏.md](task_cards/D23_%E5%90%8C%E8%AF%8D%E8%A1%A8%E6%95%99%E5%B8%88KL%E8%92%B8%E9%A6%8F.md)|2212|
|[D24_FP16等浮点wire编码.md](task_cards/D24_FP16%E7%AD%89%E6%B5%AE%E7%82%B9wire%E7%BC%96%E7%A0%81.md)|2334|
|[D25_INT8编码与量化仿真.md](task_cards/D25_INT8%E7%BC%96%E7%A0%81%E4%B8%8E%E9%87%8F%E5%8C%96%E4%BB%BF%E7%9C%9F.md)|2370|
|[D26_兼容指纹和注册表.md](task_cards/D26_%E5%85%BC%E5%AE%B9%E6%8C%87%E7%BA%B9%E5%92%8C%E6%B3%A8%E5%86%8C%E8%A1%A8.md)|2427|
|[D27_发送缓存与训练消息隔离.md](task_cards/D27_%E5%8F%91%E9%80%81%E7%BC%93%E5%AD%98%E4%B8%8E%E8%AE%AD%E7%BB%83%E6%B6%88%E6%81%AF%E9%9A%94%E7%A6%BB.md)|2261|
|[D28_检查点与精确恢复状态.md](task_cards/D28_%E6%A3%80%E6%9F%A5%E7%82%B9%E4%B8%8E%E7%B2%BE%E7%A1%AE%E6%81%A2%E5%A4%8D%E7%8A%B6%E6%80%81.md)|2347|
|[D29_有界训练器与梯度累积.md](task_cards/D29_%E6%9C%89%E7%95%8C%E8%AE%AD%E7%BB%83%E5%99%A8%E4%B8%8E%E6%A2%AF%E5%BA%A6%E7%B4%AF%E7%A7%AF.md)|2359|
|[D30_无通信全文与常量基线.md](task_cards/D30_%E6%97%A0%E9%80%9A%E4%BF%A1%E5%85%A8%E6%96%87%E4%B8%8E%E5%B8%B8%E9%87%8F%E5%9F%BA%E7%BA%BF.md)|2228|
|[D31_强文本结构化与抽取基线.md](task_cards/D31_%E5%BC%BA%E6%96%87%E6%9C%AC%E7%BB%93%E6%9E%84%E5%8C%96%E4%B8%8E%E6%8A%BD%E5%8F%96%E5%9F%BA%E7%BA%BF.md)|2265|
|[D32_内容替换与合法反事实审计.md](task_cards/D32_%E5%86%85%E5%AE%B9%E6%9B%BF%E6%8D%A2%E4%B8%8E%E5%90%88%E6%B3%95%E5%8F%8D%E4%BA%8B%E5%AE%9E%E5%AE%A1%E8%AE%A1.md)|2210|
|[D33_评分与组级统计.md](task_cards/D33_%E8%AF%84%E5%88%86%E4%B8%8E%E7%BB%84%E7%BA%A7%E7%BB%9F%E8%AE%A1.md)|2294|
|[D34_真实成本与估算账本.md](task_cards/D34_%E7%9C%9F%E5%AE%9E%E6%88%90%E6%9C%AC%E4%B8%8E%E4%BC%B0%E7%AE%97%E8%B4%A6%E6%9C%AC.md)|2193|
|[D35_可重算报告与主张校验.md](task_cards/D35_%E5%8F%AF%E9%87%8D%E7%AE%97%E6%8A%A5%E5%91%8A%E4%B8%8E%E4%B8%BB%E5%BC%A0%E6%A0%A1%E9%AA%8C.md)|2419|
|[D36_DAG计划器与节点契约.md](task_cards/D36_DAG%E8%AE%A1%E5%88%92%E5%99%A8%E4%B8%8E%E8%8A%82%E7%82%B9%E5%A5%91%E7%BA%A6.md)|2226|
|[D37_执行器journal与恢复.md](task_cards/D37_%E6%89%A7%E8%A1%8C%E5%99%A8journal%E4%B8%8E%E6%81%A2%E5%A4%8D.md)|2337|
|[D38_CLI全命令落地.md](task_cards/D38_CLI%E5%85%A8%E5%91%BD%E4%BB%A4%E8%90%BD%E5%9C%B0.md)|2188|
|[D39_端到端fixture纵向闭环.md](task_cards/D39_%E7%AB%AF%E5%88%B0%E7%AB%AFfixture%E7%BA%B5%E5%90%91%E9%97%AD%E7%8E%AF.md)|2483|
|[D40_安全故障注入与权限测试.md](task_cards/D40_%E5%AE%89%E5%85%A8%E6%95%85%E9%9A%9C%E6%B3%A8%E5%85%A5%E4%B8%8E%E6%9D%83%E9%99%90%E6%B5%8B%E8%AF%95.md)|2356|
|[D41_变异测试与覆盖审计.md](task_cards/D41_%E5%8F%98%E5%BC%82%E6%B5%8B%E8%AF%95%E4%B8%8E%E8%A6%86%E7%9B%96%E5%AE%A1%E8%AE%A1.md)|2219|
|[D42_未来模型测试源码与锁.md](task_cards/D42_%E6%9C%AA%E6%9D%A5%E6%A8%A1%E5%9E%8B%E6%B5%8B%E8%AF%95%E6%BA%90%E7%A0%81%E4%B8%8E%E9%94%81.md)|2456|
|[D43_异构配对与OOD计划生成器.md](task_cards/D43_%E5%BC%82%E6%9E%84%E9%85%8D%E5%AF%B9%E4%B8%8EOOD%E8%AE%A1%E5%88%92%E7%94%9F%E6%88%90%E5%99%A8.md)|2444|
|[D44_预算扫描与Pareto程序.md](task_cards/D44_%E9%A2%84%E7%AE%97%E6%89%AB%E6%8F%8F%E4%B8%8EPareto%E7%A8%8B%E5%BA%8F.md)|2424|
|[D45_依赖锁定与平台脚本.md](task_cards/D45_%E4%BE%9D%E8%B5%96%E9%94%81%E5%AE%9A%E4%B8%8E%E5%B9%B3%E5%8F%B0%E8%84%9A%E6%9C%AC.md)|2276|
|[D46_分层CI与供应链文件.md](task_cards/D46_%E5%88%86%E5%B1%82CI%E4%B8%8E%E4%BE%9B%E5%BA%94%E9%93%BE%E6%96%87%E4%BB%B6.md)|2319|
|[D47_源码审查与受控修复.md](task_cards/D47_%E6%BA%90%E7%A0%81%E5%AE%A1%E6%9F%A5%E4%B8%8E%E5%8F%97%E6%8E%A7%E4%BF%AE%E5%A4%8D.md)|2427|
|[D48_wheel安装与完整工程验收.md](task_cards/D48_wheel%E5%AE%89%E8%A3%85%E4%B8%8E%E5%AE%8C%E6%95%B4%E5%B7%A5%E7%A8%8B%E9%AA%8C%E6%94%B6.md)|2390|
|[D49_文献机制卡与来源账本.md](task_cards/D49_%E6%96%87%E7%8C%AE%E6%9C%BA%E5%88%B6%E5%8D%A1%E4%B8%8E%E6%9D%A5%E6%BA%90%E8%B4%A6%E6%9C%AC.md)|2303|
|[D50_README快速开始与API文档.md](task_cards/D50_README%E5%BF%AB%E9%80%9F%E5%BC%80%E5%A7%8B%E4%B8%8EAPI%E6%96%87%E6%A1%A3.md)|2311|
|[D51_公开发布阻塞与RFC.md](task_cards/D51_%E5%85%AC%E5%BC%80%E5%8F%91%E5%B8%83%E9%98%BB%E5%A1%9E%E4%B8%8ERFC.md)|2516|
|[D52_最终事实与媒体内容锁.md](task_cards/D52_%E6%9C%80%E7%BB%88%E4%BA%8B%E5%AE%9E%E4%B8%8E%E5%AA%92%E4%BD%93%E5%86%85%E5%AE%B9%E9%94%81.md)|2313|
|[D53_PPT源码与讲者备注.md](task_cards/D53_PPT%E6%BA%90%E7%A0%81%E4%B8%8E%E8%AE%B2%E8%80%85%E5%A4%87%E6%B3%A8.md)|2205|
|[D54_PPT渲染与逐页回看.md](task_cards/D54_PPT%E6%B8%B2%E6%9F%93%E4%B8%8E%E9%80%90%E9%A1%B5%E5%9B%9E%E7%9C%8B.md)|2310|
|[D55_动画源与90秒时间线.md](task_cards/D55_%E5%8A%A8%E7%94%BB%E6%BA%90%E4%B8%8E90%E7%A7%92%E6%97%B6%E9%97%B4%E7%BA%BF.md)|2241|
|[D56_动画渲染与帧检查.md](task_cards/D56_%E5%8A%A8%E7%94%BB%E6%B8%B2%E6%9F%93%E4%B8%8E%E5%B8%A7%E6%A3%80%E6%9F%A5.md)|2342|
|[D57_音频全文与字幕制作.md](task_cards/D57_%E9%9F%B3%E9%A2%91%E5%85%A8%E6%96%87%E4%B8%8E%E5%AD%97%E5%B9%95%E5%88%B6%E4%BD%9C.md)|2403|
|[D58_真实fixture演示录制.md](task_cards/D58_%E7%9C%9F%E5%AE%9Efixture%E6%BC%94%E7%A4%BA%E5%BD%95%E5%88%B6.md)|2216|
|[D59_视频合成与完整回看.md](task_cards/D59_%E8%A7%86%E9%A2%91%E5%90%88%E6%88%90%E4%B8%8E%E5%AE%8C%E6%95%B4%E5%9B%9E%E7%9C%8B.md)|2496|
|[D60_跨资产一致性审查.md](task_cards/D60_%E8%B7%A8%E8%B5%84%E4%BA%A7%E4%B8%80%E8%87%B4%E6%80%A7%E5%AE%A1%E6%9F%A5.md)|2411|
|[D61_交付清单与校验打包.md](task_cards/D61_%E4%BA%A4%E4%BB%98%E6%B8%85%E5%8D%95%E4%B8%8E%E6%A0%A1%E9%AA%8C%E6%89%93%E5%8C%85.md)|2442|
|[D62_最终用户交接.md](task_cards/D62_%E6%9C%80%E7%BB%88%E7%94%A8%E6%88%B7%E4%BA%A4%E6%8E%A5.md)|2371|
|[D63_未来实验入口封存.md](task_cards/D63_%E6%9C%AA%E6%9D%A5%E5%AE%9E%E9%AA%8C%E5%85%A5%E5%8F%A3%E5%B0%81%E5%AD%98.md)|2464|

## templates（19项）

|文件|字节数|
|---|---|
|[ADAPTER_CARD.md](templates/ADAPTER_CARD.md)|364|
|[ADR.md](templates/ADR.md)|433|
|[AGENTS.md](templates/AGENTS.md)|595|
|[DELIVERY_REPORT.md](templates/DELIVERY_REPORT.md)|695|
|[HANDOFF.md](templates/HANDOFF.md)|331|
|[MEDIA_REVIEW.md](templates/MEDIA_REVIEW.md)|320|
|[MODEL_TEST_UNLOCK.md](templates/MODEL_TEST_UNLOCK.md)|277|
|[PUBLIC_RELEASE_BLOCKERS.md](templates/PUBLIC_RELEASE_BLOCKERS.md)|312|
|[REVIEW_FINDINGS.md](templates/REVIEW_FINDINGS.md)|332|
|[RUN_STATE.example.json](templates/RUN_STATE.example.json)|274|
|[capability.example.json](templates/capability.example.json)|393|
|[compatibility.example.json](templates/compatibility.example.json)|263|
|[dataset_counterfactual.json](templates/dataset_counterfactual.json)|628|
|[dataset_original.json](templates/dataset_original.json)|610|
|[header.json](templates/packet_fixture/header.json)|745|
|[payload.safetensors](templates/packet_fixture/payload.safetensors)|88|
|[prediction.example.json](templates/prediction.example.json)|464|
|[run_manifest.example.json](templates/run_manifest.example.json)|383|
|[task_result.example.json](templates/task_result.example.json)|219|

## tests（1项）

|文件|字节数|
|---|---|
|[test_plan_tools.py](tests/test_plan_tools.py)|11697|

## tools（7项）

|文件|字节数|
|---|---|
|[assemble_pack.py](tools/assemble_pack.py)|3473|
|[no_model_gate.py](tools/no_model_gate.py)|2434|
|[planlib.py](tools/planlib.py)|3070|
|[requirements.txt](tools/requirements.txt)|103|
|[run_plan_tests.py](tools/run_plan_tests.py)|1701|
|[safe_extract.py](tools/safe_extract.py)|4803|
|[validate_plan.py](tools/validate_plan.py)|10339|
