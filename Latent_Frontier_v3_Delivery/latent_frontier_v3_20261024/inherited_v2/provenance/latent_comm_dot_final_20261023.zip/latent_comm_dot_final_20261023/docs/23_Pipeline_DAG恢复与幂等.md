# 23｜Pipeline DAG、恢复与幂等

## 1. 两个不同的 DAG

工程 DAG 管 Dot 的工作包：阅读→设计→编码→测试→复核→媒体→交付。
研究 DAG 管目标程序：数据→状态提取→训练→通信→预测→审计→统计→报告。本轮研究 DAG 的真实模型节点只规划，fixture DAG 则可以执行。

不得为了“全流程完成”把研究 DAG 的真实模型节点悄悄映射到 mock 后仍写 succeeded。必须输出 profile=fixture，与 future_model 的节点身份分开。

## 2. 节点契约

NodeSpec：node_id、operation、depends_on、inputs、outputs、config_subset_hash、capabilities_required、estimated_limits、retry_policy、cache_policy、evidence_kind。NodeResult：status、start/end、exit_code、artifact_refs、error_code、actual_cost、model_executed。

状态：planned→ready→running→succeeded；或 failed / blocked_policy / blocked_capability / cancelled / not_run_authorized_scope。不存在“没跑但用 passed 抵消”的状态转换。

## 3. 当前研究 fixture DAG

`fixture_data → fixture_validate → feature_fixture → bridge_math → codec_roundtrip → receiver_fixture → audit_logic → metric_fixture → fixture_report → bundle_verify`。

bridge_math 允许有限张量梯度检查，不加载预训练/随机 Transformer。receiver_fixture 是可审计线性或确定性函数，不承担真实语言推理。真实 HF generation 节点另外在 plan 中标 locked。

## 4. 缓存键

至少由 operation version、input content hashes、使用到的 config、schema version、dependency ABI policy 组成；不要只看文件名和修改时间。同一路径内容改变必须失效；输入相同且实现版本改变也应按策略失效。

训练缓存还需消息格式、角色视图、sender revision、抽取层、tokenizer/template、precision；代码实现参考19分册。当前 fixture 缓存和未来真实模型缓存使用不同 namespace。

## 5. 恢复

run_state 采用写前临时文件＋atomic replace。进程启动后只认完整提交的 artifact。running 遗留节点先设 interrupted，再从最近有效 checkpoint 恢复；不因为文件存在就判完成。

恢复前校验 config/dataset/implementation fingerprint。训练恢复还原 RNG、采样游标、optimizer、scheduler、累计步、选优记录；不能只加载 bridge 权重就宣称 exact resume。

## 6. 并发

数据只读节点可以并行；共享写目标用锁。Dot 写代码最多三个工作单元，各自拥有目录范围；同一个文件禁止同时编辑。构建、打包、manifest 生成只允许单个最终整合者。

模型相关节点本轮不能进入调度器 runnable 队列。即使节点有可用缓存，读取真实模型激活作为研究输入也需要模型实验的另行范围审查，不能用“没有 forward”绕过用户本轮边界。

## 7. 预算控制

规划阶段计算理论 payload；执行阶段逐节点更新实际使用。发生磁盘超限、未知付费、网络目标越界或模型调用，立即停止对应节点并记录，不自行扩大上限。不能无限重试依赖安装与浏览器访问。

## 8. 故障注入

模拟中途终止、被删缓存、损坏 manifest、写入空间不足、输出同名、依赖失败、时钟异常、重复任务、错误恢复 fingerprint。至少证明“失败不会被当成功”“恢复不会重复记一份结果”“重新运行不会覆盖旧证据”。

## 9. 验收产物

execution_plan.json、node_results.jsonl、artifact_manifest.json、resume_report.md；普通读者无需读日志就能判断哪些只规划、哪些 fixture 运行、哪些因策略未运行。

## 条件分支的收口规则

核心计算任务要求上游成功；媒体条件项可以在缺工具后进入blocked_external终态。D60–D62是汇总/打包/交接任务，等待上游进入终态而不是要求所有上游成功，因此总能产出诚实的部分交付报告。缺音轨时D59不得生成假配音视频；应保留源时间线并明确阻塞。研究DAG的模型节点仍不能执行。
