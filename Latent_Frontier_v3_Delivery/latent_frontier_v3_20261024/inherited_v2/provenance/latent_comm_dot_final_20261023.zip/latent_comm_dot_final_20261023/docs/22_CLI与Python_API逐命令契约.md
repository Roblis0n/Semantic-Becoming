# 22｜CLI 与 Python API 逐命令契约

## 1. 命名和原则

仓库 latent-comm-lab，Python 包 latent_comm，命令 lcomm。这里列的是 Dot 要实现的目标接口，不表示本计划包已经提供该 CLI。当前计划包工具只能以 `python tools/...` 调用，避免用户误把计划当目标软件。

命令显式区分纯数据操作、fixture 集成和模型操作。`--dry-run` 只解析并输出 ExecutionPlan，不实例化模型、不加载 tokenizer、不“偷偷跑一条”。使用 `--json` 时 stdout 只有一个 JSON 结果；日志写 stderr；退出码见08分册。

## 2. 命令清单

|命令|本轮行为|主要输出|
|---|---|---|
|`lcomm doctor --no-model --json`|读 Python/OS/依赖元数据，不枚举 GPU|doctor.json|
|`lcomm config validate --config PATH --phase design`|schema 和跨字段检查|validation.json|
|`lcomm data build --config PATH --output DIR`|生成小型 fixture|worlds、views、manifest|
|`lcomm data validate --input DIR`|检查 oracle/group/split/权限|data_validation.json|
|`lcomm pipeline plan --config PATH`|生成 DAG，不执行|execution_plan.json|
|`lcomm pipeline run --profile fixture --output DIR`|纯 fixture 全链路|fixture run bundle|
|`lcomm packet inspect --input PATH`|有限长头部解析|packet_summary.json|
|`lcomm packet verify --input PATH --registry PATH`|字节、shape、fingerprint|verification.json|
|`lcomm evaluate --predictions PATH --dataset DIR`|仅对已有离线预测计分|metrics.json|
|`lcomm audit --fixture --input DIR`|替换审计的程序逻辑演示|audit.json|
|`lcomm report --input DIR --output DIR`|已有记录生成表格|Markdown、CSV|
|`lcomm artifacts verify --input DIR`|逐文件 hash 和关联检查|artifact_audit.json|
|`lcomm compatibility list --json`|展示注册矩阵|compatibility.json|
|`lcomm extract/train/infer --config PATH`|本轮必须拒绝|结构化拒绝记录|

命令需有 `--help`、示例与错误行为。`evaluate` 若给真实历史结果，仅重算指标也要用户提供合法来源；不得自行从论文抄结果当本项目预测。

## 3. 无模型完整链路

先 build data，再 data validate，再 pipeline plan，再 fixture run，再 artifacts verify，再 report。fixture 使用 DeterministicFeatureFixture、LinearReceiverFixture、SpyHFBackend 等明确命名的非语言模型对象，不借用真实模型 ID 冒充。

生成报告顶端固定显示：这是软件路径检查，不是模型实验。accuracy 类研究字段默认 null；若 fixture 有匹配结果，字段命名 `fixture_contract_match_count`，不能占用 `model_accuracy`。

## 4. Python API

`build_views(sample) -> (SenderView, ReceiverView, Supervision)`；`encode_train(state, budget) -> TrainMessage`；`pack_inference(message, context) -> WirePacket`；`decode_to_prefix(packet, context) -> PrefixBatch`；`run_reference_decode(backend, prefix, prompt, limits) -> GenerationResult`；`evaluate_predictions(predictions, gold) -> MetricsBundle`。

训练 API 禁止接收 WirePacket；推理 serializer 明确 detach；函数无全局隐式 tokenizer、配置或模型。耗资源函数显式接收 ExecutionContext，context 内 policy 只读，不允许函数自行拓宽权限。

## 5. 文件和幂等性

输出目录不存在时创建；非空时默认拒绝，`--resume` 只恢复匹配 config/data/version 的 run，`--overwrite` 本轮不提供泛化删除语义。想重新跑使用新 run_id。配置内路径相对配置文件解析；CLI路径参数按显式 --project-root 解析，默认使用已确定项目根；不根据任意shell目录猜测。

每个写操作先临时文件后原子提交，失败留 forensic log 而不是半成品伪成功。目录 symlink 指出根目录时拒绝。输入输出同一路径应拒绝，避免覆盖研究原始数据。

## 6. 错误响应实例

```json
{"ok":false,"error":{"code":"E_MODEL_EXECUTION_DISABLED","operation":"model.load","message":"当前交付策略禁止模型加载。源码与无模型验证可继续。"},"model_executed":false}
```

报错不输出密钥、全文证据、绝对私人目录或 token。CLI 返回 policy deny 不代表工程任务中断：总控应将该负面测试记录为 expected rejection，继续其他允许任务。

## 7. 验收

subprocess 测 help 与 JSON；从空目录运行 installed wheel；非法参数不返回0；dry-run 不加载依赖模型；并发重复 run_id 拒绝；Ctrl-C 正常收尾；Windows 路径带空格；Unicode 文件名；日志与 JSON 不串流。
