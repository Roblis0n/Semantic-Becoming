# 37｜需求追踪与最终 Definition of Done

## 1. 追踪链

用户要求→REQ→文档→TASK→目标文件→TEST→执行证据→最终主张。任何一环缺失都应可见。机器清单存 specs/requirements.json、task_graph.json、test_catalog.json；每个task有独立Markdown卡。

## 2. 需求层级

Must-core：代码、数据、训练、推理、通信、审计、统计、成本、CLI、恢复、禁跑、测试、文档、包。
Must-source-media：PPT脚本、分镜、旁白、字幕源、渲染程序。
Conditional-render：实际PPTX/视频/音频在可用授权能力下生成；不能捏造结果。
Future-only：真实模型执行、公开发布、外部服务购买、RPC/KV/RL扩展。

## 3. 代码完成不是“文件存在”

每个核心模块包含真实逻辑、边界错误、类型、测试、文档与至少一个上层调用。抽象Protocol方法体允许作为接口声明；核心实现里的pass、NotImplementedError、无条件返回固定“成功”、万能mock则不允许。

源代码静态搜索只是风险检查：测试里有NotImplementedError样例不是缺实现；反过来没有TODO也不保证正确。Reviewer要按调用链阅读。

## 4. 必需证据

命令清单及退出码、测试report、环境lock、源码revision/hash、数据manifest、fixture run manifest、artifact校验、禁止模型入口的负向证据、安装验证、文档链接检查、媒体实际状态。

缺某项证据时，用not_verified或blocked，不靠文字描述“应该没问题”。单元测试与统计fixture的数字不能用于主张模型能力。

## 5. 状态聚合

core_complete=true仅当全部Must-core工作项实现且其无模型验证完成。media_complete=true仅当所请求实际资产确已渲染并回看；source_media_complete另列。model_validation=false且status=not_run_policy是本轮正确结果，不让其参与core_complete否决。

overall_status：completed_in_scope、partial_external_blockers、partial_core、failed_policy。许可证/发布未授权不等于工程失败，但必须禁止public_release_ready=true。

## 6. 用户最终应收到

源码包、构建包、可读README、最短fixture运行方式、完整测试证据、分层验证矩阵、媒体成品与源文件、当前限制、未来模型解锁清单、checksum。

最终消息必须直接给链接，说明完成了什么、未做什么、实际测试数和外部阻塞；不能只给一句“全部已完成”。也不追加一堆需要用户重新分派的普通编码事项。

## 7. 本计划包验收

本计划包的结构校验工具只验证任务引用、文档链接、policy、schemas、状态和文件完整性。其测试通过不等于Dot目标repo已实现。README和最终说明必须区分这个层次。
