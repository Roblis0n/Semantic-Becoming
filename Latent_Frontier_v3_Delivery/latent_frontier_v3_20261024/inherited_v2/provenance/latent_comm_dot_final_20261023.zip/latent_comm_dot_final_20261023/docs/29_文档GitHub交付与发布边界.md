# 29｜文档、GitHub交付与发布边界

## 1. 本轮目标

准备好可审查、可安装、可扩展的工程预发布，不发布未经验证的科研结果。GitHub-ready不是已经GitHub-published。

## 2. README 必需内容

一句话项目定位；明确状态；最短无模型安装与运行路径；系统数据流；支持范围矩阵；fixture和真实模型区别；实验解锁入口；核心假设与非目标；文档导航；许可证/作者未决项。

首页状态语句建议：`Engineering preview. No pretrained model execution or empirical model validation has been performed for this delivery.` 中文同义并列。将其放首页显眼位置，不埋在页尾。

## 3. 文档集

INSTALL、QUICKSTART_NO_MODEL、ARCHITECTURE、DATA_CONTRACT、TRAINING_DESIGN、WIRE_PROTOCOL、EVALUATION、SECURITY、CONTRIBUTING、TESTING、MODEL_VALIDATION_NOT_RUN、REPRODUCIBILITY、LIMITATIONS、RELEASE_NOTES。

每份命令示例注明目标项目已实现后可运行；本轮目标项目交付时应由实际CLI help同步，不能保留不存在的参数。

## 4. 研究表达

允许“提供研究某问题的基础设施”“实现可训练通信桥与审计路径”。禁止“已证明潜空间优于文本”“降低成本X%”“支持所有模型”“首次/唯一”而没有证据。

不生成虚假论文主表、排名、收敛曲线、显著性、GPU吞吐。架构示意和理论payload可以展示，但标设计/推导。

## 5. Git操作

本地 git init、分阶段commit在已授权工作区可以；无真实作者配置时不编造用户身份，使用工具已有可追溯配置或仅生成patch/源码包并记录。不要设置全局git config。

远程repo创建、push、发release、issue、discussion、社交帖均默认关闭。给出发布草稿及具体未来人工动作清单，不能调用已连接GitHub自动公开。

## 6. 许可与引用

新写代码license pending；依赖许可证分别记录；引用前作只说明借鉴机制，不复制作者图表/视频当自己素材。参考文献记录题名、URL、首次提交/修订日期、核验日期、证据范围。

论文方法不是软件许可证；仓库公开不等于可任意商用。若确需复制前作代码，先审许可、保留notice，并在change ledger注明。

## 7. 最终包

`source/`或repo根、`dist/`、`docs/`、`configs/`、`fixtures/`、`tests/`、`evidence/`、`media/`、`MANIFEST.sha256`、`DELIVERY_REPORT.md`。对源附件只保留来源清单，目标repo不携带本计划原档以减少体积与旧prompt混淆。

## 8. 读者验收

新的读者十分钟内应能知道项目解决什么、现在能跑什么、哪些未测、如何复算fixture、将来如何安全解锁。十分钟是阅读设计目标，不是执行时间承诺。

文档所有链接存在，跨平台命令无模型下载；“下一步”不能只有“自行补代码”，核心实现缺口必须在issue里清楚标记并使完整交付状态降级。
