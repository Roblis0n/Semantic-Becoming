"""Tests of the delivered PLAN helpers. No target-library or research-model execution."""
from __future__ import annotations
import copy
import io
import json
from pathlib import Path
import stat
import sys
import tempfile
import unittest
import warnings
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from planlib import PlanError, strict_json_text, read_json, inside, topological_order, validate_metric_evidence, sha256_file
from no_model_gate import ExecutionGate, validate_policy, DENIED_FLAGS
from safe_extract import safe_member, preflight, extract_checked
from validate_plan import validate, verify_manifest
from jsonschema import Draft202012Validator, ValidationError

class PlanToolsTests(unittest.TestCase):
    def setUp(self):
        self.policy=read_json(ROOT/'configs/execution_policy.json')
        self.tasks=read_json(ROOT/'specs/task_graph.json')['tasks']
    def schema(self,name):return Draft202012Validator(read_json(ROOT/'specs'/name))
    def zip_stream(self,entries):
        b=io.BytesIO()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
                for n,data in entries:z.writestr(n,data)
        b.seek(0);return zipfile.ZipFile(b)
    def test_strict_json_valid(self):self.assertEqual(strict_json_text('{"x":1}'),{'x':1})
    def test_duplicate_json_rejected(self):
        with self.assertRaises(PlanError):strict_json_text('{"x":1,"x":2}')
    def test_nonfinite_json_rejected(self):
        for v in ['NaN','Infinity','-Infinity']:
            with self.subTest(v=v),self.assertRaises(PlanError):strict_json_text('{"x":'+v+'}')
    def test_policy_accepts_current(self):validate_policy(self.policy)
    def test_policy_rejects_every_relaxed_flag(self):
        for key in DENIED_FLAGS:
            p=copy.deepcopy(self.policy);p[key]=True
            with self.subTest(key=key),self.assertRaises(PlanError):validate_policy(p)
    def test_policy_missing_flag_denied(self):
        del self.policy['allow_model_load']
        with self.assertRaises(PlanError):validate_policy(self.policy)
    def test_policy_new_spend_denied(self):
        self.policy['incremental_spend']=1
        with self.assertRaises(PlanError):validate_policy(self.policy)
    def test_policy_unknown_allow_action_denied(self):
        self.policy['allowed_actions'].append('shell.anything')
        with self.assertRaises(PlanError):validate_policy(self.policy)
    def test_policy_duplicate_action_denied(self):
        self.policy['allowed_actions'].append('static_check')
        with self.assertRaises(PlanError):validate_policy(self.policy)
    def test_gate_allows_fixture(self):ExecutionGate(self.policy).authorize('fixture_pipeline')
    def test_gate_denies_model_actions(self):
        gate=ExecutionGate(self.policy)
        for a in ['model.load','model.forward','model.from_config','tokenizer.load','gpu.initialize','dataset.download']:
            with self.subTest(action=a),self.assertRaises(PermissionError):gate.authorize(a)
    def test_gate_unknown_action_denied(self):
        with self.assertRaises(PermissionError):ExecutionGate(self.policy).authorize('remote.push')
    def test_gate_copies_allowlist(self):
        gate=ExecutionGate(self.policy);self.policy['allowed_actions'].append('remote.push')
        with self.assertRaises(PermissionError):gate.authorize('remote.push')
    def test_valid_dag(self):
        order=topological_order(self.tasks);self.assertEqual(len(order),64)
        ranks={t:i for i,t in enumerate(order)}
        for t in self.tasks:
            for d in t['depends_on']:self.assertLess(ranks[d],ranks[t['id']])
    def test_cycle_detected(self):
        self.tasks[0]['depends_on']=['D62']
        with self.assertRaises(PlanError):topological_order(self.tasks)
    def test_unknown_dependency_detected(self):
        self.tasks[0]['depends_on']=['NO_SUCH_TASK']
        with self.assertRaises(PlanError):topological_order(self.tasks)
    def test_duplicate_task_detected(self):
        self.tasks.append(copy.deepcopy(self.tasks[0]))
        with self.assertRaises(PlanError):topological_order(self.tasks)
    def test_duplicate_dep_detected(self):
        self.tasks[1]['depends_on']=['D00','D00']
        with self.assertRaises(PlanError):topological_order(self.tasks)
    def test_path_escape_detected(self):
        with self.assertRaises(PlanError):inside(ROOT,'../secret.txt')
    def test_inside_path(self):self.assertEqual(inside(ROOT,'configs/execution_policy.json').name,'execution_policy.json')
    def test_evidence_valid(self):validate_metric_evidence(read_json(ROOT/'templates/run_manifest.example.json'))
    def test_fixture_model_upgrade_denied(self):
        d=read_json(ROOT/'templates/run_manifest.example.json');d['evidence_kind']='model_experiment'
        with self.assertRaises(PlanError):validate_metric_evidence(d)
    def test_unknown_model_metric_not_zero(self):
        d=read_json(ROOT/'templates/run_manifest.example.json');d['model_metrics']={'accuracy':0}
        with self.assertRaises(PlanError):validate_metric_evidence(d)
    def test_actual_model_flag_denied(self):
        d=read_json(ROOT/'templates/run_manifest.example.json');d['model_executed']=True
        with self.assertRaises(PlanError):validate_metric_evidence(d)
    def test_unfounded_hypothesis_denied(self):
        d=read_json(ROOT/'templates/run_manifest.example.json');d['scientific_hypotheses']='confirmed'
        with self.assertRaises(PlanError):validate_metric_evidence(d)
    def test_config_unknown_key_rejected(self):
        d=read_json(ROOT/'configs/fixture_pipeline.json');d['run']['secret_model_load']=True
        with self.assertRaises(ValidationError):self.schema('experiment_config.schema.json').validate(d)
    def test_config_wrong_placement_rejected(self):
        d=read_json(ROOT/'configs/fixture_pipeline.json');d['injection']['placement']='before_assistant'
        with self.assertRaises(ValidationError):self.schema('experiment_config.schema.json').validate(d)
    def test_future_config_unresolved_is_design_only(self):
        d=read_json(ROOT/'configs/future_model_design_LOCKED.json')
        self.schema('experiment_config.schema.json').validate(d)
        self.assertFalse(d['run']['execute']);self.assertIsNone(d['models']['sender']['revision'])
    def test_counterfactual_fixture_rules(self):
        a=read_json(ROOT/'templates/dataset_original.json');b=read_json(ROOT/'templates/dataset_counterfactual.json')
        self.assertEqual(a['question'],b['question']);self.assertEqual(a['receiver_evidence'],b['receiver_evidence'])
        self.assertEqual(a['cf_group_id'],b['cf_group_id']);self.assertNotEqual(a['answer'],b['answer'])
    def test_packet_hash_and_size(self):
        h=read_json(ROOT/'templates/packet_fixture/header.json');p=ROOT/'templates/packet_fixture/payload.safetensors'
        self.assertEqual(h['payload_sha256'],sha256_file(p));self.assertEqual(h['payload_nbytes'],p.stat().st_size)
        self.assertEqual(h['raw_tensor_nbytes'],16)
    def test_packet_gold_field_forbidden(self):
        h=read_json(ROOT/'templates/packet_fixture/header.json');h['gold']='mango'
        with self.assertRaises(ValidationError):self.schema('packet_header.schema.json').validate(h)
    def test_zip_path_traversal_denied(self):
        for n in ['../x','a/../../x','/root','C:/x','a\\b','a//b','./a','a/../b']:
            with self.subTest(n=n),self.assertRaises(PlanError):safe_member(n)
    def test_zip_windows_reserved_denied(self):
        for n in ['CON','x/NUL.txt','com1','a.','folder /x']:
            with self.subTest(n=n),self.assertRaises(PlanError):safe_member(n)
    def test_zip_valid_unicode(self):self.assertEqual(safe_member('文档/计划.md'),'文档/计划.md')
    def test_zip_duplicate_path_denied(self):
        with self.zip_stream([('a','1'),('a','2')]) as z:
            with self.assertRaises(PlanError):preflight(z)
    def test_zip_case_collision_denied(self):
        with self.zip_stream([('A.txt','1'),('a.txt','2')]) as z:
            with self.assertRaises(PlanError):preflight(z)
    def test_zip_unicode_collision_denied(self):
        with self.zip_stream([('é.txt','1'),('e\u0301.txt','2')]) as z:
            with self.assertRaises(PlanError):preflight(z)
    def test_zip_file_directory_collision_denied(self):
        with self.zip_stream([('a','1'),('a/b','2')]) as z:
            with self.assertRaises(PlanError):preflight(z)
    def test_zip_size_limit(self):
        with self.zip_stream([('a','123456')]) as z:
            with self.assertRaises(PlanError):preflight(z,max_total=5)
    def test_zip_ratio_limit(self):
        with self.zip_stream([('a','0'*10000)]) as z:
            with self.assertRaises(PlanError):preflight(z,max_ratio=2)
    def test_zip_symlink_denied(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            info=zipfile.ZipInfo('link');info.create_system=3;info.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(info,'../x')
        b.seek(0)
        with zipfile.ZipFile(b) as z:
            with self.assertRaises(PlanError):preflight(z)
    def test_safe_extraction_no_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);p=td/'a.zip'
            with zipfile.ZipFile(p,'w') as z:z.writestr('文档/a.txt','ok')
            out=td/'out';extract_checked(p,out);self.assertEqual((out/'文档/a.txt').read_text(),'ok')
            with self.assertRaises(PlanError):extract_checked(p,out)
    def test_bad_zip_no_partial_destination(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);p=td/'a.zip'
            with zipfile.ZipFile(p,'w') as z:z.writestr('good','ok');z.writestr('../bad','no')
            out=td/'out'
            with self.assertRaises(PlanError):extract_checked(p,out)
            self.assertFalse(out.exists())
    def test_manifest_tamper_detected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p=root/'a.txt';p.write_text('ok')
            (root/'MANIFEST.json').write_text(json.dumps({'files':[{'path':'a.txt','bytes':2,'sha256':sha256_file(p)}]}))
            self.assertEqual(verify_manifest(root),1);p.write_text('no')
            with self.assertRaises(PlanError):verify_manifest(root)
    def test_manifest_unlisted_file_detected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'MANIFEST.json').write_text('{"files":[]}');(root/'extra.txt').write_text('x')
            with self.assertRaises(PlanError):verify_manifest(root)
    def test_media_stays_planned(self):
        for a in read_json(ROOT/'media/content_manifest.json')['assets']:
            self.assertFalse(a['rendered']);self.assertEqual(a['status'],'planned')
    def test_storyboard_16_slides(self):self.assertEqual(len(read_json(ROOT/'media/slides_storyboard.json')['slides']),16)
    def test_animation_timeline_contiguous(self):
        scenes=read_json(ROOT/'media/animation_timeline.json')['scenes'];self.assertEqual(scenes[0]['start'],0);self.assertEqual(scenes[-1]['end'],90)
        for a,b in zip(scenes,scenes[1:]):self.assertEqual(a['end'],b['start'])
    def test_full_plan_validator(self):
        result=validate(ROOT);self.assertEqual(result['status'],'passed');self.assertFalse(result['model_executed'])
    def test_original_inputs_unchanged(self):
        for item in read_json(ROOT/'evidence/input_manifest.json')['sources']:
            self.assertEqual(sha256_file(ROOT/'source_archives'/item['file']),item['sha256'])

if __name__=='__main__':unittest.main()
