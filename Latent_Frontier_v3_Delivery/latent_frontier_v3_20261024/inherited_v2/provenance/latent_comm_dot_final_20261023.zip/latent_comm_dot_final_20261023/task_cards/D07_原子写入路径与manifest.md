# D07｜原子写入路径与manifest

## 目标与交付性质

实现根目录限制、临时写后replace、内容hash、文件清单；拒绝symlink越界；断写不成功。这是Dot后续目标仓库中的工作包，本计划包里status=planned不表示已实现。当前任务禁止研究模型执行。

## 前置条件

前置任务：D02, D05。前置证据满足后才推进；条件媒体分支缺权限可降级交源稿并明确blocked，不能伪成功。

## 必读资料

- [19_缓存检查点与可复现证据.md](../docs/19_缓存检查点与可复现证据.md)
- [26_安全隐私权限与供应链.md](../docs/26_安全隐私权限与供应链.md)

执行提示词：[对应角色prompt](../prompts/07_消息编码缓存与兼容.md)。它由总控自动选择，不要求用户逐卡复制。

## 文件归属

`src/latent_comm/artifacts/writer.py`、`src/latent_comm/artifacts/manifest.py`、`src/latent_comm/artifacts/integrity.py`。以上是目标工程路径，不是本计划包已经包含的成品。仅修改这些文件及直接相关测试；跨目录接口变化先更新ADR并通知总控。

## 具体步骤

1. 实现根目录限制、临时写后replace、内容hash、文件清单。
2. 拒绝symlink越界。
3. 断写不成功。

## 必测行为

**TC-D07-01：**完整产物校验和可重算。保存实际输入、命令或检查方式、输出、退出状态。

**TC-D07-02：**半写文件、篡改hash和输入输出同路径被拒绝。构造最小反例，在副作用发生之前拒绝或在验证器中检出；不能为了测试拒绝而先执行被禁止动作。

## 完成标准

主线逻辑不是占位；公开接口与输入文档一致；相关正负测试实际执行；失败和未测分开；产物hash与证据可查。纯文档/媒体任务按内容和真实渲染验收，不伪造代码测试。核心实现未完成不能用外部能力解释代替。

## 证据与状态更新

写入 `evidence/tasks/D07/result.json` 和 `evidence/tasks/D07/checks.md`。记录task_id、status、files、tests、commands、evidence_kind、blocked_reason、model_executed=false、next_ready。实现证明、工程验证、真实模型验证分别记录。此计划包不预置任何假通过日志。

需求映射：RQ11。完成后只推进满足全部依赖的任务，不自动打开未来模型实验或公开发布。
