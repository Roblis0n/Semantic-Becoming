# D46｜分层CI与供应链文件

## 目标与交付性质

实现离线测试阶段、最小权限、锁定actions；default无model suite；包内容排除；SBOM。这是Dot后续目标仓库中的工作包，本计划包里status=planned不表示已实现。当前任务禁止研究模型执行。

## 前置条件

前置任务：D40, D41, D45。前置证据满足后才推进；条件媒体分支缺权限可降级交源稿并明确blocked，不能伪成功。

## 必读资料

- [25_依赖锁定CI与构建发布.md](../docs/25_依赖锁定CI与构建发布.md)
- [26_安全隐私权限与供应链.md](../docs/26_安全隐私权限与供应链.md)

执行提示词：[对应角色prompt](../prompts/13_依赖构建与跨平台.md)。它由总控自动选择，不要求用户逐卡复制。

## 文件归属

`.github/workflows/`、`pyproject.toml`、`THIRD_PARTY_NOTICES.md`。以上是目标工程路径，不是本计划包已经包含的成品。仅修改这些文件及直接相关测试；跨目录接口变化先更新ADR并通知总控。

## 具体步骤

1. 实现离线测试阶段、最小权限、锁定actions。
2. default无model suite。
3. 包内容排除。
4. SBOM。

## 必测行为

**TC-D46-01：**CI YAML可解析且各job范围明确。保存实际输入、命令或检查方式、输出、退出状态。

**TC-D46-02：**未授权secret/publish/model job默认自动触发必须拒绝。构造最小反例，在副作用发生之前拒绝或在验证器中检出；不能为了测试拒绝而先执行被禁止动作。

## 完成标准

主线逻辑不是占位；公开接口与输入文档一致；相关正负测试实际执行；失败和未测分开；产物hash与证据可查。纯文档/媒体任务按内容和真实渲染验收，不伪造代码测试。核心实现未完成不能用外部能力解释代替。

## 证据与状态更新

写入 `evidence/tasks/D46/result.json` 和 `evidence/tasks/D46/checks.md`。记录task_id、status、files、tests、commands、evidence_kind、blocked_reason、model_executed=false、next_ready。实现证明、工程验证、真实模型验证分别记录。此计划包不预置任何假通过日志。

需求映射：RQ12。完成后只推进满足全部依赖的任务，不自动打开未来模型实验或公开发布。
