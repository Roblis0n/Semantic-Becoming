# D11｜开发fixture及可读导出

## 目标与交付性质

生成train16/val8/test_fixture8组；输出worlds/samples JSONL和CSV；清楚标合成；生成manifest与data card。这是Dot后续目标仓库中的工作包，本计划包里status=planned不表示已实现。当前任务禁止研究模型执行。

## 前置条件

前置任务：D07, D09, D10。前置证据满足后才推进；条件媒体分支缺权限可降级交源稿并明确blocked，不能伪成功。

## 必读资料

- [09_数据生成划分与泄漏防护.md](../docs/09_数据生成划分与泄漏防护.md)
- [27_资源Windows与本地部署保护.md](../docs/27_资源Windows与本地部署保护.md)

执行提示词：[对应角色prompt](../prompts/03_数据与反事实实现.md)。它由总控自动选择，不要求用户逐卡复制。

## 文件归属

`fixtures/`、`docs/data_card.md`。以上是目标工程路径，不是本计划包已经包含的成品。仅修改这些文件及直接相关测试；跨目录接口变化先更新ADR并通知总控。

## 具体步骤

1. 生成train16/val8/test_fixture8组。
2. 输出worlds/samples JSONL和CSV。
3. 清楚标合成。
4. 生成manifest与data card。

## 必测行为

**TC-D11-01：**重复seed导出字节一致且总组数32。保存实际输入、命令或检查方式、输出、退出状态。

**TC-D11-02：**CSV公式注入字符安全且不称科研sealed test。构造最小反例，在副作用发生之前拒绝或在验证器中检出；不能为了测试拒绝而先执行被禁止动作。

## 完成标准

主线逻辑不是占位；公开接口与输入文档一致；相关正负测试实际执行；失败和未测分开；产物hash与证据可查。纯文档/媒体任务按内容和真实渲染验收，不伪造代码测试。核心实现未完成不能用外部能力解释代替。

## 证据与状态更新

写入 `evidence/tasks/D11/result.json` 和 `evidence/tasks/D11/checks.md`。记录task_id、status、files、tests、commands、evidence_kind、blocked_reason、model_executed=false、next_ready。实现证明、工程验证、真实模型验证分别记录。此计划包不预置任何假通过日志。

需求映射：RQ05。完成后只推进满足全部依赖的任务，不自动打开未来模型实验或公开发布。
