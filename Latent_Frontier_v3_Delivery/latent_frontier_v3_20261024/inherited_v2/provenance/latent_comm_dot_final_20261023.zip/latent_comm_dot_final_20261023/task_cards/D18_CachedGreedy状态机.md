# D18｜CachedGreedy状态机

## 目标与交付性质

prefill一次注入P；后续单token；正确cache_position和mask增长；与reference在spy上对照。这是Dot后续目标仓库中的工作包，本计划包里status=planned不表示已实现。当前任务禁止研究模型执行。

## 前置条件

前置任务：D17。前置证据满足后才推进；条件媒体分支缺权限可降级交源稿并明确blocked，不能伪成功。

## 必读资料

- [11_HF后端与自由生成完整实现要求.md](../docs/11_HF后端与自由生成完整实现要求.md)
- [21_兼容性注册表与能力声明.md](../docs/21_兼容性注册表与能力声明.md)
- [24_无模型测试体系与故障注入.md](../docs/24_无模型测试体系与故障注入.md)

执行提示词：[对应角色prompt](../prompts/04_HF后端与生成实现.md)。它由总控自动选择，不要求用户逐卡复制。

## 文件归属

`src/latent_comm/backends/generation.py`、`tests/contract/test_cached_decode.py`。以上是目标工程路径，不是本计划包已经包含的成品。仅修改这些文件及直接相关测试；跨目录接口变化先更新ADR并通知总控。

## 具体步骤

1. prefill一次注入P。
2. 后续单token。
3. 正确cache_position和mask增长。
4. 与reference在spy上对照。

## 必测行为

**TC-D18-01：**spy两路线token/stop一致。保存实际输入、命令或检查方式、输出、退出状态。

**TC-D18-02：**重复prefix或旧position必触发反例。构造最小反例，在副作用发生之前拒绝或在验证器中检出；不能为了测试拒绝而先执行被禁止动作。

## 完成标准

主线逻辑不是占位；公开接口与输入文档一致；相关正负测试实际执行；失败和未测分开；产物hash与证据可查。纯文档/媒体任务按内容和真实渲染验收，不伪造代码测试。核心实现未完成不能用外部能力解释代替。

## 证据与状态更新

写入 `evidence/tasks/D18/result.json` 和 `evidence/tasks/D18/checks.md`。记录task_id、status、files、tests、commands、evidence_kind、blocked_reason、model_executed=false、next_ready。实现证明、工程验证、真实模型验证分别记录。此计划包不预置任何假通过日志。

需求映射：RQ04。完成后只推进满足全部依赖的任务，不自动打开未来模型实验或公开发布。
