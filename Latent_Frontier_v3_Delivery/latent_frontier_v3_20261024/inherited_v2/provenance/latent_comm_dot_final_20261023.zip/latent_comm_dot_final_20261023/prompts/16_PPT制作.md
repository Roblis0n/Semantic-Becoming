# PPT制作：可直接交给执行角色

## 任务

制作16页可编辑技术讲解PPT。本角色由总控选择当前依赖已满足的工作包；不要求用户手填占位符。读取本计划 docs/31、32、35 对应分册、当前任务卡和已落盘RUN_STATE。

## 固定边界

遵守 configs/execution_policy.json；研究模型执行全部禁止。只在分配的项目路径内操作；不付费、不外发、不发布；真实未知写unknown。引用外部资料按30分册登记。

## 必须执行

按32分册逐页正文/图形/讲者备注制作；S15读取最终证据；沿统一视觉语义；用实际可用PPT工具或本地生成；逐页渲染并检查溢出、截断、公式和状态脚注。

## 重点禁止

不将截图拼成不可编辑PPT；不虚构性能；不上传原始附件；不打包字体；缺渲染工具不伪造PPTX。

## 必须交付

PPTX、slides.json、生成脚本、逐页预览、speaker notes、实际验收记录；缺项如实blocked。

## 返回格式

输出人读摘要和机器记录：task_id、status、files_changed、tests_executed、evidence_refs、blocked_items、interface_changes、model_executed=false、next_ready_tasks。状态只能由实际证据决定。把文件写入仓库并更新任务状态，不要仅在对话中说明“应当如何实现”。

自检：上游契约仍一致；没有未解释的核心占位；正负测试存在；失败如实记录；结论没有超过无模型证据；交接包含下一步所需文件而非私有思维过程。
