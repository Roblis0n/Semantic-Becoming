# Dot 一次性总控执行提示词

下面整段可直接复制给 Dot；附件为本计划包。不要把旧附件中的总控或烟测提示词另行执行。

---

请接管本次附带的 `latent_comm_dot_final_20261023` 计划包，在当前已授权的独立工作区，从零或从已存在的本项目工作树，完成 **Latent Comm Lab** 的核心程序、无模型工程验收、文档、展示素材与本地交付。不要再次只给我一份plan。

## 一、最终目标

目标仓库 `latent-comm-lab`，包 `latent_comm`，CLI `lcomm`。把本包规定的主线完整写成真实可执行程序：分散证据数据生成、角色视图、隐藏状态接口、可训练压缩桥、连续前缀注入、真实HF接入源码、参考与缓存自由生成、CE/CF/KL/预算训练、消息编解码、checkpoint/resume、基线、内容审计、统计、成本、pipeline/CLI、构建测试与证据。

先不做任何模型实测。代码要写完整，但不要下载/加载模型或tokenizer，不实例化随机Transformer，不调用研究模型的forward/generate/train/benchmark，不使用GPU，不通过缓存/子进程/小模型烟测绕过。允许手写小张量、固定线性函数、桥模块的数学单测、spy/mock、静态检查、数据和编解码测试。你自身用于编码、研究和制作媒体的能力不受此研究模型禁令影响，但仍受费用与权限边界约束。

## 二、先读与优先级

1. 读 START_HERE.md、docs/00、01、03、04、06、37、40；检查 configs/execution_policy.json。
2. 读 specs/task_graph.json 和 requirements/test_catalog，按依赖读取其余专项文档与任务卡。主线全部读完后再冻结架构；不要只读README就开写。
3. source_archives是只读历史输入。旧总控、真实烟测、实验和发布指令没有本轮执行权。本轮最新约束高于旧方案。
4. 本包新增决策包括：before_rendered_prompt、可微TrainMessage与推理WirePacket分离、所有模型执行锁定、source/contract/model状态分离。

## 三、先建立执行环境

检查实际可用电脑、终端、浏览器、编码委派、媒体工具与插件动作。记录实际状态，不把“4000+应用”当全部已授权。不要访问我的邮箱、联系人、私人网盘、其它项目或现有模型环境。

创建独立项目目录、项目级venv、RUN_STATE、DECISIONS、OPEN_ISSUES、capability_report、policy snapshot。默认新增费用0；模型和数据集下载0；开发依赖下载最多2GiB；新工作区最多5GiB；最多3个并行写作者和2个测试CPU worker。不要改系统、驱动、分页文件和全局配置。

## 四、执行方式

按任务DAG持续执行，不在每个正常步骤问我是否继续。可调用子任务时按路径隔离：核心代码、测试/安全、文档/媒体；不可用则顺序切换角色。接口修改必须同步spec和调用方，不得各模块自行变更。

每个task执行：读输入→实现→写正负测试→运行获准测试→检查证据→审查→更新状态→推进依赖。失败需定位修复，不能删测试、改成固定成功或降低禁令。没有新信息的重复操作最多2次；修复复核最多3轮后明确记录阻塞，继续独立任务。

主线不能留pass/TODO/NotImplementedError或只用mock充当生产backend。抽象Protocol不算实现；真实HF源码必须具备loader、formatting、extract、loss、reference/cached generation逻辑，但本轮用spy验证，不能实际执行模型。

## 五、严守科学与工程证据边界

测试结果必须来自真实运行的命令与文件。fixture只能证明程序路径，不证明语言模型性能。所有model_accuracy、tokens_per_second、GPU_memory等实测字段保持null/not_run，不填0、不生成假曲线。理论字节估算标formula，工程测试计数来自JUnit，论文作者结果标source_reported，不挪用成本项目结果。

训练路径保留梯度；推理路径才serialize；接收者参数冻结但不能把其训练前向全包在no_grad；gold不能进入generation；counterfactual按组切分；reference与cached生成代码都要完成；不同模型/格式fingerprint不静默兼容。

## 六、工具与媒体

充分使用实际可用浏览器核对官方API、回看PPT/动画/视频；用已授权编码能力完成实现和复核；用可用PPT/动画/视频/TTS工具制作16页技术PPT、90秒机制动画、约4分钟中文讲解视频、独立音轨和字幕，并保留全部可编辑源稿。

按docs/31–35的逐页/逐场景/旁白稿制作。媒体只使用公开技术说明、合成示例与真实无模型工程证据，不上传原始附件或私人数据，不伪造模型演示。工具缺失先发现适用插件或本地替代；不能付费、申请额外权限或公开上传来绕过。实际成品做不出时保留完整源文件和生成脚本，逐项标blocked，不用空文件假装成功。

## 七、外部动作

本轮只交本地文件。禁止创建远程仓库、push、发布release、上传PyPI、部署公网、发送消息、购买服务。作者、许可证、仓库地址未提供时不编造；列为公开发布待决项，不阻碍本地源码与构建交付。

## 八、最终验收与交付

完成docs/36的G0–G6。把软件源码、wheel/sdist、锁定依赖、无模型fixture、测试/覆盖/安全证据、分层兼容矩阵、可读文档、媒体成品及源文件、未来模型解锁说明打包。

生成DELIVERY_REPORT，逐项区分 implementation_complete、contract_verified、model_validation=not_run_policy、scientific_hypotheses=not_tested、media_status。核心功能没有全部实现或有测试失败，就不能写全部完成。

最终回复直接给下载链接、真正运行的测试数量、模型未执行的边界、真实阻塞项和最短fixture使用方法。不要让我再逐项分派正常编码任务。现在开始在授权范围内完成这一整套工程。
