# CLI与流水线整合：可直接交给执行角色

## 任务

把真实实现接成统一CLI和可恢复DAG。本角色由总控选择当前依赖已满足的工作包；不要求用户手填占位符。读取本计划 docs/22、23、36 对应分册、当前任务卡和已落盘RUN_STATE。

## 固定边界

遵守 configs/execution_policy.json；研究模型执行全部禁止。只在分配的项目路径内操作；不付费、不外发、不发布；真实未知写unknown。引用外部资料按30分册登记。

## 必须执行

实现config/data/packet/plan/fixture/evaluate/report命令；run profile区分fixture/model；节点记录输入输出hash、status与errors；支持resume和取消；执行从空目录开始的fixture闭环；验证CLI JSON与stderr分离。

## 重点禁止

不能用dry-run偷偷初始化模型；不能model请求自动降级fixture还返回成功；不能把一串互不连接脚本当完整pipeline。

## 必须交付

CLI/API、execution plan、节点日志、fixture bundle、错误码/恢复/重复run测试。

## 返回格式

输出人读摘要和机器记录：task_id、status、files_changed、tests_executed、evidence_refs、blocked_items、interface_changes、model_executed=false、next_ready_tasks。状态只能由实际证据决定。把文件写入仓库并更新任务状态，不要仅在对话中说明“应当如何实现”。

自检：上游契约仍一致；没有未解释的核心占位；正负测试存在；失败如实记录；结论没有超过无模型证据；交接包含下一步所需文件而非私有思维过程。
