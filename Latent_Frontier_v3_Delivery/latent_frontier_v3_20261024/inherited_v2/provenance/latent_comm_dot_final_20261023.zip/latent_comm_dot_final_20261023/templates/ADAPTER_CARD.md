# Adapter卡

记录候选model_id、revision（未定null）、家族、hidden语义、tokenizer/template、prefix位置、cache策略、支持batch、library版本、dtype、源码状态、合约测试状态、模型验证状态、已知限制。

真实模型所有行为本轮not_run；mock契约单列。不能因为相同hidden维度就升级兼容状态。
