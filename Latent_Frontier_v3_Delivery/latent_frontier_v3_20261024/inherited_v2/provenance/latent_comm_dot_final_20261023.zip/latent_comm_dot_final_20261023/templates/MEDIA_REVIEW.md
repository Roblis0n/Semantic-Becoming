# 媒体验收规范

按asset记录source_ready/rendered/opened/visually_reviewed/claim_checked/hash_verified；保存实际截图、probe和检查备注。

PPT逐页检查；视频完整回看并抽查切点；音轨审听；字幕时间与语义检查。缺工具写blocked，不能用空文件或假截图代替。
