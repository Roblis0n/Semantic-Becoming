# 最终交付报告填写规范

这个文件是模板，不是已经完成的报告。Dot最终从实际证据生成。

## 当前状态

分别列core_complete、contract_tests、model_validation=not_run_policy、scientific_hypotheses=not_tested、source_media_complete、rendered_media_complete、public_release=not_authorized。

## 必填证据

源码revision、构建包、命令/退出码、测试实际数量、JUnit、fixture产物、政策拒绝记录、媒体probe/回看、hash。无证据不能写passed。

## 用户操作

提供实际可运行的最短fixture命令和下载链接。列真实阻塞及未来解锁。不能把计划包验证结果填成目标项目测试数。
