# 本轮参考组件测试记录

执行日期：2026-10-23。

环境：Python 3.13.5；PyTorch 2.10.0+cpu；pytest 9.0.2；CUDA available = False。

执行命令（项目目录）：

```bash
python -m reference_code.make_private_data --outdir examples
python -m reference_code.costs
python -m pytest -q --disable-warnings
```

实际结果：8项测试通过。原始输出见evidence/pytest_output.txt。生成演示数据：demo_train 64行、demo_validation 16行、demo_test 32行，全部为合成任务，不是封存的真实研究测试集。

通过范围：桥接模块的形状、通过冻结接收器回传桥梯度、padding屏蔽、可变槽数、无效mask报错、反事实数据完整性、确定性与分组、CSV输出/不静默覆盖、载荷算术（部分项目同一测试覆盖）。

未执行：预训练LLM下载/加载、GPU训练、真实模型推理、论文仓库复现、公开问答集评测、网络/显存性能测试。本环境无GPU。因此本记录不能支持模型准确率、加速或节约显存的结论。

测试用的冻结接收器是线性层，用于验证autograd；不是语言模型。完整LLM训练器仍需按计划实现和验证。
