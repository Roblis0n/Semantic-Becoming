# 一手来源登记表

核查日期：2026-10-23。以下是选题与方法依据，不是本项目复现结果。论文日期除另注明外均指 arXiv 首次提交日期；修订版不冒充首次发表。仓库“可见”不等于已经安装或复现。URL 以代码形式保留，便于核查。

| 编号 | 来源与日期 | 本计划使用的事实 / 边界 | 原始来源 |
|---|---|---|---|
| S01 | Interlat；2025-11-12；所读 v5 为 2026-07-13 | 隐状态通信、接收适配与压缩训练；并非任意模型即插即用；其常规消息构造也可能依赖先生成计划 | `https://arxiv.org/abs/2511.09149`；`https://arxiv.org/html/2511.09149v5`；`https://github.com/XiaoDu-flying/Interlat` |
| S02 | LatentMAS；2025-11-25；v4 为 2026-08-03 | 免训练潜在协作与工作记忆传递；不把仓库兼容声明外推为所有异构模型可直接交换缓存 | `https://arxiv.org/abs/2511.20639`；`https://github.com/Gen-Verse/LatentMAS` |
| S03 | C2C；2025-10-03 | 学习投影、融合 KV 缓存；官方仓库可见；其原设定与私有分散上下文实验不能直接等同 | `https://arxiv.org/abs/2510.03215`；`https://github.com/thu-nics/C2C` |
| S04 | KVComm；2025-10-02；v3 为 2026-02-22 | 选择层的 KV 共享；适合作为 KV 路线的选择基线 | `https://arxiv.org/abs/2510.03346` |
| S05 | StateBridge；2026-08-13 | 闭式隐状态对齐、尺度校准、词表锚定；维度、对应关系仍需成立；免梯度训练不等于零校准或零计算 | `https://arxiv.org/abs/2608.13317`；`https://github.com/YanwenPneg/StateBridge` |
| S06 | XKV；2026-08-20 | 冻结两个基础模型、训练双缓存翻译器；研究异构模型和分散上下文；本轮未确认完整官方运行仓库 | `https://arxiv.org/abs/2608.20617`；`https://arxiv.org/html/2608.20617` |
| S07 | CacheBack；2026-09-25；实验室介绍为 2026-10-19 | 接收者请求引导状态选择，免训练；已有官方代码；不是任意异构模型通用翻译器 | `https://arxiv.org/abs/2609.32046`；`https://github.com/agentcacheback/cacheback`；`https://daplab.cs.columbia.edu/projects/cacheback/` |
| S08 | Do Latent Channels Actually Communicate?；2026-07-29 | 用消息替换区分消息存在、内容以及其他 Agent 所提供的信息 | `https://arxiv.org/abs/2607.26773` |
| S09 | When Does Latent Communication Pay?；2026-08-05；v2 为 2026-08-27 | 私有信息必要性、错配缓存、零缓存与匹配矩随机缓存；仅在所审计配置内支持结论 | `https://arxiv.org/abs/2608.04893`；`https://arxiv.org/html/2608.04893v2` |
| S10 | OBF；2026-04-14；v3 为 2026-08-22 | 面向中继的 KV 压缩与丢弃信息补偿；不能把缓存压缩本身写成新贡献 | `https://arxiv.org/abs/2604.13349` |
| S11 | CacheFuse；2026-10-12 | 免训练缓存插值；论文要求缓存几何匹配且双方预填相同提示；不适合原样充当任意分散证据基线 | `https://arxiv.org/abs/2610.16165`；`https://github.com/rishiskhare/CacheFuse` |
| S12 | Thought Blocks；2026-10-16 | 一次构建固定大小的 KV 延续状态；“不自回归地生成潜消息”已有直接前作；本轮未确认完整官方运行仓库 | `https://arxiv.org/abs/2610.23056`；`https://arxiv.org/html/2610.23056v1` |
| S13 | LatBridge；2026-10-20 | 共享 Bridge、可复用接口和模型替换；“共享中间语言 / O(N) 接口”不能直接宣称首创；本轮未确认完整官方运行仓库 | `https://arxiv.org/abs/2610.27813`；`https://arxiv.org/html/2610.27813` |
| S14 | Hidden Messages；2026-10-20 | 扩散模型间紧凑隐消息；有反事实与通信时机实验；论文链接代码；本轮未执行代码 | `https://arxiv.org/abs/2610.28905`；`https://arxiv.org/html/2610.28905v1`；`https://github.com/alanrbtx/hidden-messages-diffusion-agents` |
| S15 | LCGuard；2026-05-21 | 潜缓存可能泄露输入；学习变换降低其定义下的重构风险，不等于密码学保密 | `https://arxiv.org/abs/2605.22786` |
| S16 | Safety of Latent Communication；2026-09-30 | 固定基础模型不保证加入通信桥后的系统保留原有安全性质；本计划只借鉴防御评价 | `https://arxiv.org/abs/2609.39788` |
| S17 | CommNet；2016-05-25 | 可学习连续通信有更早基础；本项目新意须落到语言模型接口及实证问题，而非“首次连续通信” | `https://arxiv.org/abs/1605.07736` |
| S18 | HotpotQA；2018-09-25 | 多跳问答及句级支撑事实，可用于构造分散证据；数据本身不保证模型没有记忆或单跳捷径 | `https://arxiv.org/abs/1809.09600`；`https://hotpotqa.github.io/` |
| S19 | Qwen3-0.6B 官方模型卡 | 小模型候选及 thinking 开关；不是最强模型排名，也不是 8GB 训练成功证明 | `https://huggingface.co/Qwen/Qwen3-0.6B` |
| S20 | SmolLM2-360M-Instruct 官方模型卡 | 跨家族的小模型候选；先测任务能力，再选用 | `https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct` |
| S21 | Transformers Qwen3 文档 | hidden states、inputs_embeds、模型前向等接口依据；具体支持随锁定版本验证 | `https://huggingface.co/docs/transformers/en/model_doc/qwen3` |
| S22 | Transformers cache 文档 | cache、mask 与位置状态必须一致；缓存通常为推理机制，训练路径需单独验证 | `https://huggingface.co/docs/transformers/en/cache_explanation` |
| S23 | PyTorch Autograd 文档 | 冻结参数不同于关闭自动求导；桥接层可通过固定接收模型获得输入梯度 | `https://docs.pytorch.org/docs/2.14/notes/autograd.html` |

## 使用规则

1. [Sxx] 支持邻近的既有研究事实；本计划的阈值、超参数、路线排序与新研究问题均是方案建议。
2. 不复用论文的最高提升值作为本项目预计收益；不跨设备、跨数据集直接比较论文倍数。
3. 未找到代码入口只记录为“本次未确认”，不得改写成“作者未开源”。
4. 新论文可能影响优先级，但不撤销已经完成的测量：明确增加哪个基线、补哪个实验即可。
5. 用户附件仅作为选题历史背景：其中“潜空间中的学习与模拟”仍是预测，并不提供本计划的技术验证。原始附件未重新分发进本包。
