"""Generate explicitly synthetic two-party lookup tasks with counterfactual pairs.

This is channel calibration data, not evidence of an LLM's performance.
A sender knows entity -> key; a receiver knows key -> item. Public question names
one entity. The counterfactual changes only the sender's map. Gold is for the
loss/evaluator only and MUST NOT enter sender or receiver encoding inputs.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import random
from pathlib import Path
from typing import Any

FIELDS = ['example_id', 'group_id', 'split', 'variant', 'query_entity',
          'public_query', 'sender_context', 'receiver_context', 'gold_answer']
ITEMS = ['mango', 'cedar', 'pearl', 'violet', 'copper', 'willow', 'amber', 'coral']


def parse_map(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in text.splitlines():
        a, b = line.split(' -> ')
        if a in result:
            raise ValueError('duplicate key')
        result[a] = b
    return result


def solve(row: dict[str, Any]) -> str:
    sender = parse_map(row['sender_context'])
    receiver = parse_map(row['receiver_context'])
    return receiver[sender[row['query_entity']]]


def generate_groups(groups: int, seed: int, split: str) -> list[dict[str, Any]]:
    if groups <= 0 or not split:
        raise ValueError('groups must be positive and split nonempty')
    rng = random.Random(seed)
    rows: list[dict[str, Any]] = []
    for index in range(groups):
        entities = [f'entity_{i}' for i in range(8)]
        keys = [f'key_{i}' for i in range(8)]
        sender_keys = rng.sample(keys, len(keys))
        item_perm = rng.sample(ITEMS, len(ITEMS))
        sender = dict(zip(entities, sender_keys))
        receiver = dict(zip(keys, item_perm))
        query = rng.choice(entities)
        other = rng.choice([e for e in entities if e != query])
        cf_sender = dict(sender)
        cf_sender[query], cf_sender[other] = cf_sender[other], cf_sender[query]
        # Permutation stays fixed within a pair; no length/position signal of variant.
        sender_order = rng.sample(entities, len(entities))
        receiver_order = rng.sample(keys, len(keys))
        rx = '\n'.join(f'{key} -> {receiver[key]}' for key in receiver_order)
        group_id = f'{split}-{index:06d}'
        for variant, mapping in [('original', sender), ('counterfactual', cf_sender)]:
            row = dict(example_id=f'{group_id}-{variant}', group_id=group_id,
                       split=split, variant=variant, query_entity=query,
                       public_query=f'What item belongs to {query}?',
                       sender_context='\n'.join(f'{e} -> {mapping[e]}' for e in sender_order),
                       receiver_context=rx, gold_answer=receiver[mapping[query]])
            assert solve(row) == row['gold_answer']
            rows.append(row)
    return rows


def write_dataset(outdir: Path, seed: int, counts: dict[str, int],
                  overwrite: bool = False) -> dict[str, Any]:
    outdir.mkdir(parents=True, exist_ok=True)
    targets = [outdir/f'{split}.csv' for split in counts] + [outdir/'data_manifest.json']
    if not overwrite and any(p.exists() for p in targets):
        raise FileExistsError('Output files exist; use a new directory or explicit --overwrite')
    manifest: dict[str, Any] = {'synthetic': True, 'schema': 'private_lookup_v1',
                                'purpose': 'demonstration/channel calibration; no model results',
                                'seed': seed, 'files': {}}
    for i, (split, groups) in enumerate(counts.items()):
        rows = generate_groups(groups, seed + i * 100003, split)
        path = outdir/f'{split}.csv'
        with path.open('w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        manifest['files'][split] = {'groups': groups, 'rows': len(rows),
                                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    (outdir/'data_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    return manifest


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--train-groups', type=int, default=32)
    p.add_argument('--validation-groups', type=int, default=8)
    p.add_argument('--test-groups', type=int, default=16)
    p.add_argument('--overwrite', action='store_true')
    args = p.parse_args()
    m = write_dataset(args.outdir, args.seed,
                      {'demo_train': args.train_groups,
                       'demo_validation': args.validation_groups,
                       'demo_test': args.test_groups}, args.overwrite)
    print(f'Synthetic examples written to {args.outdir}; no model inference was performed.')
    print({k: v['rows'] for k, v in m['files'].items()})


if __name__ == '__main__':
    main()
