"""Arithmetic payload estimates, NOT measured latency or GPU memory usage."""
from __future__ import annotations
import argparse
import math


def dense_payload_bytes(slots: int, width: int, bits: int,
                        metadata_bytes: int = 0) -> int:
    if min(slots, width, bits) <= 0 or metadata_bytes < 0:
        raise ValueError('positive dimensions/bits and nonnegative metadata required')
    # Assumes actual packed representation. Float storage of quantized values
    # does not meet this assumption. Scales/indices belong in metadata_bytes.
    return math.ceil(slots * width * bits / 8) + metadata_bytes


def kv_payload_bytes(layers: int, kv_heads: int, head_dim: int,
                     positions: int, bits: int, metadata_bytes: int = 0) -> int:
    if min(layers, kv_heads, head_dim, positions, bits) <= 0:
        raise ValueError('all dimensions/bits must be positive')
    return dense_payload_bytes(2 * layers * kv_heads * positions,
                               head_dim, bits, metadata_bytes)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--slots', type=int, default=16)
    parser.add_argument('--width', type=int, default=256)
    parser.add_argument('--bits', type=int, default=16)
    parser.add_argument('--metadata-bytes', type=int, default=0)
    args = parser.parse_args()
    n = dense_payload_bytes(args.slots, args.width, args.bits, args.metadata_bytes)
    print(f'Packed-payload arithmetic: {n:,} bytes ({n/1024:.3f} KiB)')
    print('This excludes any overhead not explicitly included in --metadata-bytes.')


if __name__ == '__main__':
    main()
