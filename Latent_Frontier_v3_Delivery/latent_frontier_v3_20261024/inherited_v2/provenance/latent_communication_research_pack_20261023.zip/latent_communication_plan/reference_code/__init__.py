"""Reference components only; not a complete pretrained-LLM trainer."""
