"""Small latent codec for shape/gradient prototyping.

No pretrained models are loaded here. In a real experiment, freeze sender and
receiver parameters, but retain autograd through the receiver to this prefix.
The wire object is z, NOT the expanded receiver prefix.
"""
from dataclasses import dataclass
import math
import torch
from torch import Tensor, nn


@dataclass(frozen=True)
class BridgeConfig:
    sender_dim: int
    receiver_dim: int
    wire_dim: int = 256
    slots: int = 16
    target_embedding_rms: float = 1.0  # Toy default; measure on the real receiver.

    def __post_init__(self) -> None:
        for name in ('sender_dim', 'receiver_dim', 'wire_dim', 'slots'):
            if getattr(self, name) <= 0:
                raise ValueError(f'{name} must be positive')
        if self.target_embedding_rms <= 0:
            raise ValueError('target_embedding_rms must be positive')


class LatentCodec(nn.Module):
    """Query-conditioned attention pooling, wire bottleneck, input projection."""
    def __init__(self, config: BridgeConfig) -> None:
        super().__init__()
        self.config = config
        ds, dr, r, m = (config.sender_dim, config.receiver_dim,
                         config.wire_dim, config.slots)
        self.source_norm = nn.LayerNorm(ds)
        self.key = nn.Linear(ds, r, bias=False)
        self.value = nn.Linear(ds, r, bias=False)
        self.query_projection = nn.Linear(ds, r, bias=False)
        self.slot_queries = nn.Parameter(torch.randn(m, r) / math.sqrt(r))
        self.wire_mlp = nn.Sequential(nn.Linear(r, 2*r), nn.GELU(), nn.Linear(2*r, r))
        self.wire_norm = nn.LayerNorm(r)
        self.output_projection = nn.Linear(r, dr)

    def encode(self, hidden: Tensor, valid_mask: Tensor,
               public_query_state: Tensor | None = None,
               slots: int | None = None) -> Tensor:
        if hidden.ndim != 3 or hidden.shape[-1] != self.config.sender_dim:
            raise ValueError('hidden must have shape [batch, source_length, sender_dim]')
        if valid_mask.shape != hidden.shape[:2] or valid_mask.dtype != torch.bool:
            raise ValueError('valid_mask must be bool [batch, source_length]')
        if not bool(valid_mask.any(dim=1).all()):
            raise ValueError('every sample must contain at least one valid source position')
        k = self.config.slots if slots is None else slots
        if not 1 <= k <= self.config.slots:
            raise ValueError('slots must be in [1, configured slots]')
        h = self.source_norm(hidden)
        keys, values = self.key(h), self.value(h)
        queries = self.slot_queries[:k].unsqueeze(0).expand(hidden.shape[0], -1, -1)
        if public_query_state is not None:
            if public_query_state.shape != (hidden.shape[0], self.config.sender_dim):
                raise ValueError('public query must be [batch, sender_dim]')
            queries = queries + self.query_projection(public_query_state).unsqueeze(1)
        scores = torch.matmul(queries, keys.transpose(-1, -2)) / math.sqrt(self.config.wire_dim)
        scores = scores.masked_fill(~valid_mask[:, None, :], float('-inf'))
        pooled = torch.matmul(scores.softmax(dim=-1), values)
        return self.wire_norm(pooled + self.wire_mlp(pooled))

    def decode(self, wire: Tensor) -> Tensor:
        if wire.ndim != 3 or wire.shape[-1] != self.config.wire_dim:
            raise ValueError('wire must be [batch, slots, wire_dim]')
        prefix = self.output_projection(wire)
        rms = prefix.float().square().mean(dim=-1, keepdim=True).add(1e-6).sqrt()
        scale = (self.config.target_embedding_rms / rms).to(prefix.dtype)
        return prefix * scale

    def forward(self, hidden: Tensor, valid_mask: Tensor,
                public_query_state: Tensor | None = None,
                slots: int | None = None) -> tuple[Tensor, Tensor]:
        wire = self.encode(hidden, valid_mask, public_query_state, slots)
        return wire, self.decode(wire)
