# 潜空间通信研究计划包

日期：2026-10-23。推荐主线：**面向分散证据推理的预算约束潜空间通信**。

## 阅读方式

先读docs/00研究总纲；需要直接开工，读06阶段计划与10检查单；要落实训练，读02接口、03数据、04训练、05评估、11伪代码。08是后续扩展方向，09是可交给研究/编码Agent的执行提示词。原始来源在evidence/sources.md。

完整合订版另见压缩包外的`latent_communication_master_plan_20261023.md`。

## 内容

- 12份Markdown分册：问题定义、文献、架构、数据、训练、评估、路线、算力、扩展、Agent提示词、开工检查、入门与伪代码。
- 一手来源登记表，区分论文事实、方案建议与未验证事项。
- 2个YAML配置规格；它们不是已经实现的训练命令。
- 3个参考Python模块：通信桥、合成反事实数据生成、载荷计算；不包含完整LLM训练器。
- 8项已运行的单元测试；可读CSV演示数据与数据manifest。

## 本地检查

需要Python 3.10+，以及PyTorch、pytest；本轮已测试版本见TEST_REPORT.md。建议独立环境，不覆盖现有推理部署。此处没有自动安装、自动下载、云资源创建或私有数据上传脚本。

```bash
cd latent_communication_plan
python -m pytest -q
python -m reference_code.costs --slots 16 --width 256 --bits 16
python -m reference_code.make_private_data --outdir my_synthetic_demo
```

`examples/`已经包含演示文件，默认命令不会静默覆盖同名文件。使用新的输出目录即可。

## 状态与边界

已经做：一手文献核查、方案设计、参考组件编写与CPU单元测试。

尚未做：真实模型训练、论文复现、实际任务性能验证。所有收益假设、超参数、门槛、扩展方案均需通过计划中的实验检验。不将8项组件测试写成模型实验成功。

模型revision故意保留`MUST_PIN_BEFORE_RUN`；正式实验前必须登记真实值。任何真实来源文档、私有数据和付费算力使用均需有授权。
