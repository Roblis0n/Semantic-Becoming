import csv
import torch
from torch import nn
import pytest
from reference_code.bridge import BridgeConfig, LatentCodec
from reference_code.costs import dense_payload_bytes, kv_payload_bytes
from reference_code.make_private_data import generate_groups, solve, write_dataset


def test_bridge_shapes_and_frozen_receiver_gradient():
    torch.manual_seed(42)
    bridge = LatentCodec(BridgeConfig(32, 48, wire_dim=16, slots=4))
    source = torch.randn(2, 10, 32)  # Cached, not trainable.
    mask = torch.ones(2, 10, dtype=torch.bool)
    mask[0, -2:] = False
    wire, prefix = bridge(source, mask, torch.randn(2, 32))
    assert wire.shape == (2, 4, 16)
    assert prefix.shape == (2, 4, 48)
    receiver = nn.Linear(48, 8)
    receiver.requires_grad_(False)
    before = {k: v.detach().clone() for k, v in receiver.state_dict().items()}
    loss = nn.CrossEntropyLoss()(receiver(prefix.mean(1)), torch.tensor([1, 2]))
    loss.backward()  # Receiver is NOT inside torch.no_grad().
    assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in bridge.parameters())
    assert all(p.grad is None for p in receiver.parameters())
    assert all(torch.equal(before[k], v) for k, v in receiver.state_dict().items())


def test_padding_invariance():
    torch.manual_seed(43)
    b = LatentCodec(BridgeConfig(8, 12, 4, 3)).eval()
    h = torch.randn(1, 6, 8)
    mask = torch.tensor([[True, True, True, False, False, False]])
    altered = h.clone()
    altered[:, 3:] = 1000 * torch.randn_like(altered[:, 3:])
    assert torch.allclose(b.encode(h, mask), b.encode(altered, mask))


def test_smaller_budget():
    b = LatentCodec(BridgeConfig(8, 12, 4, 3))
    h = torch.randn(1, 6, 8)
    m = torch.ones(1, 6, dtype=torch.bool)
    assert b.encode(h, m, slots=1).shape == (1, 1, 4)
    with pytest.raises(ValueError):
        b.encode(h, m, slots=4)


def test_invalid_mask():
    b = LatentCodec(BridgeConfig(8, 12, 4, 3))
    with pytest.raises(ValueError):
        b.encode(torch.randn(1, 6, 8), torch.zeros(1, 6, dtype=torch.bool))


def test_counterfactual_integrity():
    rows = generate_groups(100, 42, 'train')
    for a, b in zip(rows[::2], rows[1::2]):
        assert a['group_id'] == b['group_id']
        assert a['public_query'] == b['public_query']
        assert a['receiver_context'] == b['receiver_context']
        assert a['sender_context'] != b['sender_context']
        assert a['gold_answer'] != b['gold_answer']
        assert solve(a) == a['gold_answer'] and solve(b) == b['gold_answer']
        assert a['gold_answer'] not in a['sender_context']


def test_determinism_and_split_groups():
    train = generate_groups(10, 42, 'train')
    again = generate_groups(10, 42, 'train')
    test = generate_groups(10, 100045, 'test')
    assert train == again
    assert {r['group_id'] for r in train}.isdisjoint(r['group_id'] for r in test)


def test_csv_and_no_silent_overwrite(tmp_path):
    m = write_dataset(tmp_path, 42, {'demo_train': 3, 'demo_validation': 2})
    assert m['files']['demo_train']['rows'] == 6
    with (tmp_path/'demo_train.csv').open(encoding='utf-8', newline='') as f:
        assert len(list(csv.DictReader(f))) == 6
    with pytest.raises(FileExistsError):
        write_dataset(tmp_path, 42, {'demo_train': 3})


def test_payload_math():
    assert dense_payload_bytes(16, 2048, 16) == 65536
    assert dense_payload_bytes(16, 256, 16) == 8192
    assert dense_payload_bytes(3, 1, 4) == 2
    assert kv_payload_bytes(24, 8, 128, 128, 16) == 12 * 1024**2
    assert dense_payload_bytes(16, 256, 8, 12) == 4108
    with pytest.raises(ValueError):
        dense_payload_bytes(0, 256, 8)
